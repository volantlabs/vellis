# Contributing

## Setup

```sh
./bootstrap
```

## Before a change

- identify whether the change belongs to language foundation, model engineering, projection, realization, assurance, or explicit evolution;
- preserve exclusive mutation boundaries;
- update the canonical manifest/schema/skill rather than a generated provider copy;
- keep official resource changes explicit and immutable;
- add or update a behavioral test for every material contract change.

## Required checks

```sh
.venv/bin/mbswe core sync
.venv/bin/mbswe core check
.venv/bin/python -m pytest
.venv/bin/mbswe core manifest
```

For resource-lane changes, also synchronize a test project, rebuild the corpus, run retrieval evaluations, validate the bundled model library, and run the validator negative self-test.

For layer changes, export and bootstrap all affected profiles.

## Generated files

Provider manifests and `MANIFEST.sha256` are generated. Target-project managed assets carry `.mbswe-managed`. Do not hand-edit generated copies when their source manifest or canonical skill can be changed.

## Pull-request focus

Keep changes narrow. Do not combine a resource-lane upgrade, model-method change, skill reorganization, and CLI redesign in one patch unless the compatibility boundary makes them inseparable.
