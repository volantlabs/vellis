# Security

The portable core downloads and executes an official SysML validator and, when needed, a Java runtime. Resource locks pin exact commits and SHA-256 digests. Downloads are staged, verified before publication, and extracted with path-traversal checks.

Review any new resource lane carefully. Do not accept mutable branch references, unverified binary URLs, or silent lock regeneration.

The CLI never reads project secrets by design. Target-project gates run exactly the command arrays configured by that project; inspect them before enabling unattended execution.

Report security issues privately to the maintainers of the repository in which this core is published.
