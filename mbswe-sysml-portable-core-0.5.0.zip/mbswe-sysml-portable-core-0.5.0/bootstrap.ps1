$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Python = if ($env:PYTHON) { $env:PYTHON } else { "python" }

$DependencyCheck = @'
import os
import tomllib
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
import setuptools, wheel
from packaging.requirements import Requirement
from packaging.version import Version
root = Path(os.environ["MBSWE_BOOTSTRAP_ROOT"])
project = tomllib.loads((root / "pyproject.toml").read_text(encoding="utf-8"))["project"]
requirements = [*project.get("dependencies", []), *project.get("optional-dependencies", {}).get("dev", [])]
for raw in requirements:
    requirement = Requirement(raw)
    if requirement.marker is not None and not requirement.marker.evaluate():
        continue
    try:
        installed = Version(version(requirement.name))
    except PackageNotFoundError:
        raise SystemExit(1)
    if requirement.specifier and installed not in requirement.specifier:
        raise SystemExit(1)
'@
$env:MBSWE_BOOTSTRAP_ROOT = $Root
$DependencyCheck | & $Python - 2>$null
$HaveHostDeps = ($LASTEXITCODE -eq 0)
Remove-Item Env:MBSWE_BOOTSTRAP_ROOT
if (Test-Path "$Root/.venv") { Remove-Item -Recurse -Force "$Root/.venv" }

if (Get-Command uv -ErrorAction SilentlyContinue) {
    uv venv "$Root/.venv" --python $Python
} else {
    & $Python -m venv "$Root/.venv"
}
$TargetPython = "$Root/.venv/Scripts/python.exe"

if ($HaveHostDeps) {
    $TargetSite = & $TargetPython -c "import site; print(site.getsitepackages()[0])"
    $HostSites = & $Python -c "import site; print([char]10.join(site.getsitepackages()))"
    Set-Content -Path "$TargetSite/mbswe-host-dependencies.pth" -Value $HostSites
    if (Get-Command uv -ErrorAction SilentlyContinue) {
        uv pip install --python $TargetPython --no-deps --no-build-isolation -e $Root
    } else {
        & $TargetPython -m pip install --no-deps --no-build-isolation -e $Root
    }
} else {
    if (Get-Command uv -ErrorAction SilentlyContinue) {
        uv pip install --python $TargetPython -e "$Root[dev]"
    } else {
        & $TargetPython -m pip install --upgrade pip
        & $TargetPython -m pip install -e "$Root[dev]"
    }
}

& "$Root/.venv/Scripts/mbswe.exe" core check
& $TargetPython -m pytest "$Root/tests" -q
$ProfileFile = Join-Path $Root "EXPORTED_PROFILE"
$DefaultProfile = if (Test-Path $ProfileFile) { (Get-Content $ProfileFile -Raw).Trim() } else { "full" }
Write-Host "MBSwE portable core is ready."
Write-Host ""
Write-Host "  $Root/.venv/Scripts/mbswe.exe layer list"
Write-Host "  $Root/.venv/Scripts/mbswe.exe layer archive $DefaultProfile <destination.zip>"
Write-Host "  $Root/.venv/Scripts/mbswe.exe project init <repository> --profile $DefaultProfile"
