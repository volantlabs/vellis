## Model-based engineering

Read `mbswe.yaml` and the generated `.mbswe/generated/project-guidance.md` before consequential model
or implementation work. Textual SysML v2 identified by the manifest is product, system, and selected
architecture authority. Use the installed `sysml-*` skills. Do not perform autonomous implementation
without a current validated execution slice.
