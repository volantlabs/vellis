"""Run target-project gates without inventing project commands."""

from __future__ import annotations

import subprocess
from dataclasses import dataclass

from .config import ProjectConfig
from .errors import MBSwEError


@dataclass(frozen=True)
class GateResult:
    name: str
    command: tuple[str, ...]
    returncode: int
    stdout: str
    stderr: str

    @property
    def passed(self) -> bool:
        return self.returncode == 0


def run_gate(project: ProjectConfig, name: str) -> GateResult:
    gates = project.command_gates
    if name not in gates or not gates[name]:
        raise MBSwEError(
            f"project gate {name!r} is not configured in mbswe.yaml; the portable core will not guess it"
        )
    command = gates[name]
    completed = subprocess.run(
        command,
        cwd=project.root,
        capture_output=True,
        text=True,
        check=False,
    )
    return GateResult(
        name=name,
        command=tuple(command),
        returncode=completed.returncode,
        stdout=completed.stdout,
        stderr=completed.stderr,
    )
