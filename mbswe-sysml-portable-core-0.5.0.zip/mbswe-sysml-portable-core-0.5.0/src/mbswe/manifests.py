"""Generate provider manifests from the neutral portable-package manifest."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .io import load_yaml
from .paths import core_root


def expected_manifests(root: Path | None = None) -> dict[Path, dict[str, Any]]:
    root = (root or core_root()).resolve()
    package = load_yaml(root / "package.yaml")
    interface = package["interface"]
    common: dict[str, Any] = {
        "name": package["name"],
        "version": str(package["version"]),
        "description": package["description"],
        "author": package["author"],
    }
    claude = dict(common)
    codex = {
        **common,
        "skills": "./skills/",
        "interface": {
            "displayName": interface["display_name"],
            "shortDescription": interface["short_description"],
            "longDescription": interface["long_description"],
            "developerName": interface["developer_name"],
            "category": interface["category"],
            "capabilities": interface["capabilities"],
        },
    }
    return {
        root / ".claude-plugin" / "plugin.json": claude,
        root / ".codex-plugin" / "plugin.json": codex,
    }


def sync_provider_manifests(root: Path | None = None, *, check: bool = False) -> list[str]:
    errors: list[str] = []
    for path, expected in expected_manifests(root).items():
        if path.is_file():
            try:
                actual = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as error:
                actual = None
                errors.append(f"{path}: cannot read manifest: {error}")
            if actual == expected:
                continue
            if check:
                errors.append(f"{path}: generated provider manifest is stale")
                continue
        elif check:
            errors.append(f"{path}: missing generated provider manifest")
            continue
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(expected, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return errors
