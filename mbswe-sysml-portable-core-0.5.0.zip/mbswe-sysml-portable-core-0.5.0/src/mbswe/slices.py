"""Generate and validate decision-complete execution slices."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .artifacts import load_artifact, validate_artifact
from .config import ProjectConfig
from .errors import MBSwEError
from .io import dump_yaml, sha256_file
from .model import model_digest
from .paths import require_within


def _by_id(values: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    return {str(item["id"]): item for item in values}


def _by_ref(values: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    return {str(item["ref"]): item for item in values}


def _unique(values: list[str]) -> list[str]:
    return list(dict.fromkeys(value for value in values if value))


def generate_execution_slice(
    project: ProjectConfig,
    *,
    index_path: Path,
    operation_ref: str,
    destination: Path,
    slice_id: str,
    title: str,
    implementation_checkpoint: str,
    mode: str = "copilot",
    approval_status: str = "pending",
    approval_artifact: str | None = None,
) -> Path:
    """Project one indexed operation into a bounded realization packet.

    The semantic adapter remains responsible for producing a complete model index.
    This function never invents missing responsibilities, interactions, decisions,
    scale drivers, or evidence.
    """

    index_path = require_within(
        index_path, project.allowed_generated_roots, label="semantic model index"
    )
    destination = require_within(
        destination, [project.artifact_root("slices")], label="execution-slice output"
    )
    value = load_artifact(index_path)
    if not isinstance(value, dict):
        raise MBSwEError(f"{index_path} must contain a model-index mapping")
    errors = validate_artifact("model-index", index_path)
    if errors:
        raise MBSwEError("model index is invalid:\n" + "\n".join(errors))
    current_digest = model_digest(project)
    if value["baseline"]["model_digest"] != current_digest:
        raise MBSwEError(
            f"model index is stale: {value['baseline']['model_digest']} != {current_digest}"
        )
    if value["baseline"]["language_lane"] != project.lane:
        raise MBSwEError(
            f"model index lane {value['baseline']['language_lane']!r} "
            f"does not match project lane {project.lane!r}"
        )

    operation_map = _by_ref(value["operations"])
    operation = operation_map.get(operation_ref)
    if operation is None:
        raise MBSwEError(f"operation {operation_ref!r} not found in {index_path}")

    claims = [item for item in value["claims"] if item["subject_ref"] == operation_ref]
    if not claims:
        raise MBSwEError(
            f"operation {operation_ref!r} has no indexed claim carrying outcome/counterexample meaning"
        )
    primary = next(
        (
            item
            for item in claims
            if item.get("architecture_critical") and item.get("nearest_wrong_system")
        ),
        next((item for item in claims if item.get("nearest_wrong_system")), None),
    )
    if primary is None:
        raise MBSwEError(
            f"operation {operation_ref!r} has no claim with nearest_wrong_system"
        )
    wrong = str(primary["nearest_wrong_system"]).strip()

    responsibility_map = _by_ref(value["responsibilities"])
    state_map = _by_ref(value["states"])
    interaction_map = _by_ref(value["interactions"])
    boundary_map = _by_ref(value["boundaries"])
    decision_map = _by_id(value["decisions"])
    evidence_map = _by_id(value["evidence"])

    relevant_state_refs = set(operation.get("reads", [])) | set(operation.get("writes", []))
    relevant_states = [state_map[ref] for ref in relevant_state_refs if ref in state_map]

    responsibility_refs = {operation["owner_ref"]}
    for state in relevant_states:
        responsibility_refs.update(
            ref for ref in state.get("owner_refs", []) if ref in responsibility_map
        )

    # Include declared dependencies transitively so the packet carries the complete
    # governed collaboration closure rather than only the first coordinator.
    changed = True
    while changed:
        changed = False
        for ref in tuple(responsibility_refs):
            responsibility = responsibility_map.get(ref)
            if responsibility is None:
                continue
            for dependency in responsibility.get("depends_on_refs", []):
                if dependency not in responsibility_refs:
                    responsibility_refs.add(dependency)
                    changed = True

    boundary_refs: set[str] = set()
    for ref in responsibility_refs:
        boundary_refs.update(responsibility_map.get(ref, {}).get("boundary_refs", []))

    interaction_refs: set[str] = set()
    for boundary_ref in boundary_refs:
        interaction_refs.update(boundary_map.get(boundary_ref, {}).get("interaction_refs", []))
    for interaction in value["interactions"]:
        if (
            interaction["source_ref"] in responsibility_refs
            and interaction["target_ref"] in responsibility_refs
        ):
            interaction_refs.add(interaction["ref"])
    relevant_interactions = [
        interaction_map[ref] for ref in sorted(interaction_refs) if ref in interaction_map
    ]

    decision_ids = list(operation.get("decision_refs", []))
    for interaction in relevant_interactions:
        decision_ids.extend(interaction.get("decision_refs", []))
    decisions = []
    for identifier in _unique(decision_ids):
        item = decision_map[identifier]
        decisions.append(
            {
                "id": item["id"],
                "kind": item["kind"],
                "disposition": item["disposition"],
                "impact": item["impact"],
                "model_ref": item["model_ref"],
                "reconsider_when": item.get("reconsider_when", ""),
                "rationale": item.get("rationale_summary")
                or ", ".join(item.get("rationale_refs", [])),
            }
        )

    state_owners = []
    for state in relevant_states:
        for owner_ref in state.get("owner_refs", []):
            access = []
            if state["ref"] in operation.get("reads", []):
                access.append("read")
            if state["ref"] in operation.get("writes", []):
                access.append("write")
            state_owners.append(
                {"state": state["ref"], "owner_ref": owner_ref, "access": access}
            )

    evidence_ids: list[str] = []
    for claim in claims:
        evidence_ids.extend(claim.get("evidence_refs", []))
    for decision in decisions:
        source_decision = decision_map.get(decision["id"], {})
        evidence_ids.extend(source_decision.get("evidence_refs", []))
    evidence = [
        {
            "id": item["id"],
            "kind": item["kind"],
            "reference": item["reference"],
            "excludes": item["excludes"],
        }
        for identifier in _unique(evidence_ids)
        if (item := evidence_map.get(identifier)) is not None
    ]

    authority: list[dict[str, Any]] = [
        {"ref": operation_ref, "role": "behavior", "coverage": "full", "remaining": "none"}
    ]
    for claim in claims:
        for carrier_ref in claim.get("carrier_refs", []):
            authority.append(
                {
                    "ref": carrier_ref,
                    "role": "requirement",
                    "coverage": "full",
                    "remaining": "none",
                }
            )
    for ref in sorted(responsibility_refs):
        authority.append(
            {"ref": ref, "role": "responsibility", "coverage": "full", "remaining": "none"}
        )
    for state in relevant_states:
        authority.append(
            {"ref": state["ref"], "role": "state", "coverage": "full", "remaining": "none"}
        )
    for interaction in relevant_interactions:
        if interface_ref := interaction.get("interface_ref"):
            authority.append(
                {
                    "ref": interface_ref,
                    "role": "interface",
                    "coverage": "full",
                    "remaining": "none",
                }
            )
    for decision in decisions:
        authority.append(
            {
                "ref": decision["model_ref"],
                "role": "decision",
                "coverage": "full",
                "remaining": "none",
            }
        )
    deduplicated_authority: list[dict[str, Any]] = []
    seen_authority: set[tuple[str, str]] = set()
    for item in authority:
        key = (item["ref"], item["role"])
        if key not in seen_authority:
            seen_authority.add(key)
            deduplicated_authority.append(item)

    autonomy = project.raw.get("autonomy", {})
    forbidden = list(autonomy.get("stop_on", []))
    for boundary_ref in sorted(boundary_refs):
        forbidden.extend(boundary_map.get(boundary_ref, {}).get("excludes", []))

    observable = "; ".join(
        _unique([str(claim["statement"]).strip() for claim in claims])
    )
    alternate_or_failure = _unique(
        [
            str(item).strip()
            for claim in claims
            for item in claim.get("alternate_or_failure", [])
        ]
    )
    required_non_effects = _unique(
        [
            str(item).strip()
            for claim in claims
            for item in claim.get("required_non_effects", [])
        ]
    )
    source_roots = list(project.raw.get("implementation", {}).get("source_roots", []))
    evidence_roots = list(project.raw.get("implementation", {}).get("evidence_roots", []))

    packet = {
        "schema_version": "1.0",
        "slice": {"id": slice_id, "title": title, "mode": mode},
        "baseline": {
            "model_digest": value["baseline"]["model_digest"],
            "language_lane": value["baseline"]["language_lane"],
            "implementation_checkpoint": implementation_checkpoint,
            "resource_lock_digest": "sha256:" + sha256_file(project.resource_lock_path),
        },
        "outcome": {
            "observable_distinction": observable,
            "nominal": primary.get("nominal") or primary["statement"],
            "alternate_or_failure": alternate_or_failure,
            "nearest_wrong_system": wrong,
            "required_non_effects": required_non_effects,
        },
        "authority": deduplicated_authority,
        "architecture": {
            "responsibilities": [
                {
                    "ref": ref,
                    "responsibility": responsibility_map[ref]["description"],
                }
                for ref in sorted(responsibility_refs)
            ],
            "state_owners": state_owners,
            "interactions": [
                {
                    "source_ref": item["source_ref"],
                    "target_ref": item["target_ref"],
                    **(
                        {"interface_ref": item["interface_ref"]}
                        if item.get("interface_ref")
                        else {}
                    ),
                    "meaning": item["meaning"],
                }
                for item in relevant_interactions
            ],
            "decisions": decisions,
        },
        "delegation": {
            "permitted_local_choices": [
                f"choices classified as {kind} within one governed responsibility"
                for kind in autonomy.get("permitted_delegated_decision_kinds", [])
            ],
            "forbidden_changes": _unique(forbidden),
            "stop_conditions": list(autonomy.get("stop_on", [])),
        },
        "resource_bounds": {
            "work_may_scale_with": operation["work_may_scale_with"],
            "work_must_not_scale_with": operation["work_must_not_scale_with"],
            "materialization_permitted": operation["materialization_permitted"],
            "materialization_forbidden": operation["materialization_forbidden"],
            "transient_lifetimes": [
                f"{item['ref']}: {item['lifetime']}" for item in operation["transient_state"]
            ],
        },
        "change_surface": {
            "responsibilities": sorted(responsibility_refs),
            "source_paths": source_roots,
            "evidence_paths": evidence_roots,
            "public_contract_change": False,
        },
        "evidence": evidence,
        "approval": {"status": approval_status, "artifact": approval_artifact},
    }
    destination.parent.mkdir(parents=True, exist_ok=True)
    dump_yaml(destination, packet)
    errors = validate_artifact("execution-slice", destination)
    if errors:
        destination.unlink(missing_ok=True)
        raise MBSwEError("generated execution slice is incomplete:\n" + "\n".join(errors))
    return destination
