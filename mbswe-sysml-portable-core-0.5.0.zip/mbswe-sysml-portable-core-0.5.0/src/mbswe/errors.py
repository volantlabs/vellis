"""Shared exceptions."""

from __future__ import annotations


class MBSwEError(RuntimeError):
    """A user-actionable portable-core failure."""
