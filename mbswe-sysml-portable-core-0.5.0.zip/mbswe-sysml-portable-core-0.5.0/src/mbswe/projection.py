"""Deterministic projections from accepted model source and generated indexes."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import yaml

from .artifacts import load_artifact, validate_artifact
from .config import ProjectConfig
from .errors import MBSwEError
from .io import dump_json, sha256_file
from .model import model_digest, source_inventory
from .paths import require_within


def project_source_inventory(project: ProjectConfig, destination: Path) -> Path:
    value = source_inventory(project)
    dump_json(destination, value)
    return destination


def project_model_brief(project: ProjectConfig, destination: Path) -> Path:
    inventory = source_inventory(project)
    lines = [
        f"# Model brief: {project.project_id}",
        "",
        f"- Model digest: `{inventory['model_digest']}`",
        f"- Language lane: `{project.lane}`",
        f"- Model files: {len(inventory['files'])}",
        f"- Packages: {len(inventory['packages'])}",
        f"- Lexically visible declarations: {len(inventory['declarations'])}",
        "",
        "> Generated source inventory only. It does not prove semantic completeness or conformance.",
        "",
        "## Files",
        "",
    ]
    for item in inventory["files"]:
        lines.append(f"- `{item['path']}` — {item['lines']} lines, `{item['sha256'][:16]}…`")
    lines.extend(["", "## Packages", ""])
    for item in inventory["packages"]:
        lines.append(f"- `{item['name']}` — `{item['path']}`")
    lines.extend(["", "## Declarations", ""])
    for item in inventory["declarations"]:
        marker = "definition" if item["definition"] else "usage"
        lines.append(
            f"- `{item['kind']}` {marker} `{item['name']}` — "
            f"`{item['path']}:{item['line']}`"
        )
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return destination


def project_decision_report(
    project: ProjectConfig, index_path: Path, destination: Path
) -> Path:
    value = load_artifact(index_path)
    if not isinstance(value, dict):
        raise MBSwEError(f"{index_path} must contain a model-index mapping")
    errors = validate_artifact("model-index", index_path)
    if errors:
        raise MBSwEError("model index is invalid:\n" + "\n".join(errors))
    current_digest = model_digest(project)
    if value["baseline"]["model_digest"] != current_digest:
        raise MBSwEError(
            f"model index is stale: {value['baseline']['model_digest']} != {current_digest}"
        )
    if value["baseline"]["language_lane"] != project.lane:
        raise MBSwEError(
            f"model index lane {value['baseline']['language_lane']!r} "
            f"does not match project lane {project.lane!r}"
        )
    decisions = value.get("decisions", [])
    lines = ["# Model decision report", "", f"Model digest: `{value['baseline']['model_digest']}`", ""]
    for decision in decisions:
        lines.extend(
            [
                f"## {decision['id']}: {decision['kind']}",
                "",
                f"- Model element: `{decision['model_ref']}`",
                f"- Impact: `{decision['impact']}`",
                f"- Disposition: `{decision['disposition']}`",
                f"- Reconsider when: {decision.get('reconsider_when') or 'not recorded'}",
                "",
            ]
        )
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return destination


def projection_result(
    project: ProjectConfig,
    *,
    projector: str,
    destination: Path,
    index: Path | None = None,
) -> dict[str, Any]:
    destination = require_within(
        destination, [project.artifact_root("projections")], label="projection output"
    )
    if index is not None:
        index = require_within(
            index, project.allowed_generated_roots, label="projection model index"
        )
    if projector == "source-inventory":
        project_source_inventory(project, destination)
    elif projector == "model-brief":
        project_model_brief(project, destination)
    elif projector == "decision-report":
        if index is None:
            raise MBSwEError("decision-report requires --index")
        project_decision_report(project, index, destination)
    else:
        raise MBSwEError(
            f"unknown projector {projector!r}; available: source-inventory, model-brief, decision-report"
        )
    return {
        "schema_version": "1.0",
        "projection": {
            "projector": projector,
            "model_digest": model_digest(project),
            "resource_lane": project.lane,
            "output": destination.relative_to(project.root).as_posix()
            if destination.is_relative_to(project.root)
            else str(destination),
            "output_sha256": "sha256:" + sha256_file(destination),
            "deterministic": True,
        },
        "status": "produced",
        "warnings": [],
    }
