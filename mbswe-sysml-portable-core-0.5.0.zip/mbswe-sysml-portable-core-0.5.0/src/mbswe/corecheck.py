"""Self-validation for the portable repository and exported profiles."""

from __future__ import annotations

import hashlib
import json
import re
import tomllib
from pathlib import Path
from typing import Any

import yaml
from jsonschema import Draft202012Validator

from .artifacts import schema_errors, validate_artifact
from .config import load_layers
from .errors import MBSwEError
from .io import load_json, load_yaml, sha256_file
from .manifests import sync_provider_manifests
from .paths import core_root

FRONTMATTER = re.compile(r"\A---\n(?P<body>.*?)\n---\n", re.DOTALL)
LINK = re.compile(r"\[[^]]+]\(([^)]+)\)")

TEMPLATE_BY_KIND = {
    "project": "mbswe.project.yaml",
    "model-index": "model-index.example.yaml",
    "execution-slice": "execution-slice.yaml",
    "projection-request": "projection-request.yaml",
    "projection-result": "projection-result.yaml",
    "realization-result": "realization-result.yaml",
    "model-feedback": "model-feedback.yaml",
    "change-note": "change-note.yaml",
    "domain-pack": "domain-pack.yaml",
}


def _validate_yaml_schema(path: Path, schema: Path) -> list[str]:
    try:
        value = yaml.safe_load(path.read_text(encoding="utf-8"))
    except Exception as error:
        return [f"{path}: cannot load YAML: {error}"]
    return [f"{path}: {item}" for item in schema_errors(value, schema)]


def _validate_json_schema(path: Path, schema: Path) -> list[str]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except Exception as error:
        return [f"{path}: cannot load JSON: {error}"]
    return [f"{path}: {item}" for item in schema_errors(value, schema)]


def _validate_schema_files(root: Path) -> list[str]:
    errors: list[str] = []
    for path in sorted((root / "schemas").glob("*.json")):
        try:
            schema = json.loads(path.read_text(encoding="utf-8"))
            Draft202012Validator.check_schema(schema)
        except Exception as error:
            errors.append(f"{path}: invalid JSON Schema: {error}")
    if not list((root / "schemas").glob("*.json")):
        errors.append(f"{root / 'schemas'}: no schemas found")
    return errors




def _documentation_errors(root: Path) -> list[str]:
    errors: list[str] = []
    markdown_files = [
        path
        for path in [root / "README.md", root / "CONTRIBUTING.md", root / "SECURITY.md"]
        if path.is_file()
    ]
    markdown_files.extend(sorted((root / "docs").rglob("*.md")) if (root / "docs").is_dir() else [])
    if not (root / "README.md").is_file():
        errors.append(f"{root / 'README.md'}: missing package README")
    for markdown in markdown_files:
        text = markdown.read_text(encoding="utf-8")
        for target in LINK.findall(text):
            target = target.split("#", 1)[0].strip()
            if not target or "://" in target or target.startswith("#"):
                continue
            resolved = (markdown.parent / target).resolve()
            try:
                resolved.relative_to(root.resolve())
            except ValueError:
                errors.append(f"{markdown}: local link escapes repository: {target}")
                continue
            if not resolved.exists():
                errors.append(f"{markdown}: missing linked resource: {target}")
    return errors

def _validate_skill(path: Path) -> list[str]:
    errors: list[str] = []
    skill = path / "SKILL.md"
    if not skill.is_file():
        return [f"{path}: missing SKILL.md"]
    source = skill.read_text(encoding="utf-8")
    match = FRONTMATTER.match(source)
    if match is None:
        return [f"{skill}: missing frontmatter"]
    try:
        metadata = yaml.safe_load(match.group("body"))
    except Exception as error:
        return [f"{skill}: invalid frontmatter: {error}"]
    if not isinstance(metadata, dict) or metadata.get("name") != path.name:
        errors.append(f"{skill}: frontmatter name must equal {path.name}")
    description = metadata.get("description") if isinstance(metadata, dict) else None
    if not isinstance(description, str) or not description.strip():
        errors.append(f"{skill}: frontmatter description must be non-empty")
    for markdown in path.rglob("*.md"):
        text = markdown.read_text(encoding="utf-8")
        for target in LINK.findall(text):
            target = target.split("#", 1)[0].strip()
            if not target or "://" in target or target.startswith("#"):
                continue
            resolved = (markdown.parent / target).resolve()
            try:
                resolved.relative_to(path.resolve())
            except ValueError:
                errors.append(f"{markdown}: link escapes skill: {target}")
                continue
            if not resolved.exists():
                errors.append(f"{markdown}: missing linked resource: {target}")
    return errors


def _canonical_lane_digest(record: dict[str, Any]) -> str:
    payload = {key: value for key, value in record.items() if key != "catalog_digest"}
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return "sha256:" + hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _resource_errors(root: Path) -> list[str]:
    errors: list[str] = []
    catalog_path = root / "resources" / "catalog.yaml"
    catalog = load_yaml(catalog_path)
    lanes = catalog.get("lanes", {})
    if not isinstance(lanes, dict) or not lanes:
        return [f"{catalog_path}: no resource lanes"]
    default = catalog.get("default_lane")
    if default not in lanes:
        errors.append(f"{catalog_path}: default_lane {default!r} is not defined")
    for name, lane in lanes.items():
        if not isinstance(lane, dict):
            errors.append(f"{catalog_path}: lane {name!r} must be a mapping")
            continue
        actual_digest = _canonical_lane_digest(lane)
        if lane.get("catalog_digest") != actual_digest:
            errors.append(
                f"{catalog_path}: lane {name!r} digest is stale; expected {actual_digest}"
            )
        lock_path = root / "resources" / "locks" / f"{name}.json"
        if not lock_path.is_file():
            errors.append(f"{lock_path}: missing lock for resource lane {name!r}")
            continue
        try:
            lock = load_json(lock_path)
        except MBSwEError as error:
            errors.append(str(error))
            continue
        expected_lock = {
            "schema_version": "2.0",
            "lane": name,
            **{key: value for key, value in lane.items() if key not in {"status", "label"}},
        }
        if lock != expected_lock:
            errors.append(f"{lock_path}: lock does not exactly match resources/catalog.yaml")
    extra_locks = {
        path.stem for path in (root / "resources" / "locks").glob("*.json")
    } - set(lanes)
    if extra_locks:
        errors.append(f"resources/locks contains unknown lanes: {sorted(extra_locks)}")
    return errors


def _layer_errors(root: Path, manifest: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    layers = manifest.get("layers", {})
    extras = manifest.get("extras", {})
    profiles = manifest.get("profiles", {})
    exported = (root / "EXPORTED_PROFILE").is_file()
    if not exported and set(layers) != {"reference", "modeling", "realization"}:
        errors.append(
            "full portable core must define exactly the reference, modeling, and realization layers"
        )
    all_records = {**layers, **extras}
    for name, record in all_records.items():
        for dependency in record.get("dependencies", []):
            if dependency not in all_records:
                errors.append(f"layer/extra {name!r} has unavailable dependency {dependency!r}")
        for schema in record.get("schemas", []):
            if not (root / "schemas" / schema).is_file():
                errors.append(f"layers.yaml references missing schema {schema}")
        for template in record.get("templates", []):
            if not (root / "templates" / template).is_file():
                errors.append(f"layers.yaml references missing template {template}")
        for library in record.get("model_libraries", []):
            if not (root / "model-libraries" / library).is_dir():
                errors.append(f"layers.yaml references missing model library {library}")
    for name, record in profiles.items():
        layer_set = set(record.get("layers", []))
        extra_set = set(record.get("extras", []))
        missing_layers = layer_set - set(layers)
        missing_extras = extra_set - set(extras)
        if missing_layers or missing_extras:
            errors.append(
                f"profile {name!r} references unavailable layers/extras: "
                f"{sorted(missing_layers | missing_extras)}"
            )
        for layer in layer_set:
            unresolved = set(layers[layer].get("dependencies", [])) - layer_set - extra_set
            if unresolved:
                errors.append(
                    f"profile {name!r} omits dependencies {sorted(unresolved)} for layer {layer!r}"
                )
        for extra in extra_set:
            unresolved = set(extras[extra].get("dependencies", [])) - layer_set - extra_set
            if unresolved:
                errors.append(
                    f"profile {name!r} omits dependencies {sorted(unresolved)} for extra {extra!r}"
                )
    return errors


def _package_errors(root: Path) -> list[str]:
    errors: list[str] = []
    package = load_yaml(root / "package.yaml")
    try:
        pyproject = tomllib.loads((root / "pyproject.toml").read_text(encoding="utf-8"))
        project = pyproject["project"]
    except Exception as error:
        return [f"{root / 'pyproject.toml'}: cannot load project metadata: {error}"]
    if str(project.get("version")) != str(package.get("version")):
        errors.append("pyproject.toml and package.yaml versions differ")
    if project.get("name") != "mbswe-portable-core":
        # Exported profiles retain the Python distribution name intentionally so the
        # CLI and import path are stable; the provider package identity may differ.
        errors.append("pyproject.toml project name must remain mbswe-portable-core")
    errors.extend(sync_provider_manifests(root, check=True))
    return errors


def core_errors() -> list[str]:
    root = core_root()
    errors: list[str] = []
    required = [
        "package.yaml",
        "layers.yaml",
        "skill-catalog.yaml",
        "resources/catalog.yaml",
        "pyproject.toml",
        "bootstrap",
        "bootstrap.ps1",
    ]
    for relative in required:
        if not (root / relative).is_file():
            errors.append(f"{root / relative}: required file is missing")
    if errors:
        return errors

    errors += _validate_schema_files(root)
    errors += _validate_yaml_schema(
        root / "package.yaml", root / "schemas" / "package.schema.json"
    )
    errors += _validate_yaml_schema(
        root / "layers.yaml", root / "schemas" / "layer-catalog.schema.json"
    )
    errors += _validate_yaml_schema(
        root / "skill-catalog.yaml", root / "schemas" / "skill-catalog.schema.json"
    )
    errors += _validate_yaml_schema(
        root / "resources" / "catalog.yaml",
        root / "schemas" / "resource-catalog.schema.json",
    )
    resource_schema = root / "schemas" / "resource-lock.schema.json"
    for lock in sorted((root / "resources" / "locks").glob("*.json")):
        errors += _validate_json_schema(lock, resource_schema)

    for kind, filename in TEMPLATE_BY_KIND.items():
        path = root / "templates" / filename
        if not path.is_file():
            # Exported subsets deliberately omit contracts from unavailable layers.
            continue
        for error in validate_artifact(kind, path):
            errors.append(f"{path}: {error}")

    skill_root = root / "skills"
    actual_skills = {path.name for path in skill_root.iterdir() if path.is_dir()}
    if not actual_skills:
        errors.append(f"{skill_root}: no skills found")
    for skill in sorted(path for path in skill_root.iterdir() if path.is_dir()):
        errors += _validate_skill(skill)

    manifest = load_layers()
    errors += _layer_errors(root, manifest)
    referenced_skills = {
        skill
        for record in [*manifest["layers"].values(), *manifest.get("extras", {}).values()]
        for skill in record.get("skills", [])
    }
    if referenced_skills != actual_skills:
        errors.append(
            f"layers.yaml skill inventory {sorted(referenced_skills)} differs from "
            f"skills/ {sorted(actual_skills)}"
        )

    catalog = load_yaml(root / "skill-catalog.yaml")
    catalog_skills = {item["id"] for item in catalog.get("skills", [])}
    if catalog_skills != actual_skills:
        errors.append(
            f"skill-catalog.yaml inventory {sorted(catalog_skills)} differs from "
            f"skills/ {sorted(actual_skills)}"
        )
    eval_schema = root / "schemas" / "eval-suite.schema.json"
    for item in catalog.get("skills", []):
        for relative in (item.get("entry"), item.get("eval")):
            if relative and not (root / relative).is_file():
                errors.append(f"skill catalog references missing file {relative}")
        eval_relative = item.get("eval")
        if eval_relative and (root / eval_relative).is_file():
            eval_path = root / eval_relative
            errors += _validate_yaml_schema(eval_path, eval_schema)
            try:
                suite = load_yaml(eval_path)
                identifiers = [str(case.get("id", "")) for case in suite.get("scenarios", [])]
                if len(identifiers) != len(set(identifiers)):
                    errors.append(f"{eval_path}: duplicate scenario id")
            except MBSwEError as error:
                errors.append(str(error))

    errors += _resource_errors(root)
    errors += _package_errors(root)
    errors += _documentation_errors(root)
    return errors


def write_manifest(destination: Path | None = None) -> Path:
    root = core_root()
    destination = destination or root / "MANIFEST.sha256"
    excluded = {destination.resolve(), (root / ".venv").resolve()}
    files = [
        path
        for path in root.rglob("*")
        if path.is_file()
        and path.resolve() not in excluded
        and ".git" not in path.parts
        and ".venv" not in path.parts
        and "__pycache__" not in path.parts
        and ".pytest_cache" not in path.parts
    ]
    lines = [
        f"{sha256_file(path)}  {path.relative_to(root).as_posix()}" for path in sorted(files)
    ]
    destination.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return destination
