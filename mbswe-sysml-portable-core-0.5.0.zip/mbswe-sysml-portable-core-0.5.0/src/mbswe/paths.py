"""Portable-core and project path discovery."""

from __future__ import annotations

import os
from pathlib import Path

from .errors import MBSwEError


def core_root() -> Path:
    """Return the portable-core checkout root.

    The distributed repository is intended to be installed editable.  An explicit
    MBSWE_CORE_ROOT keeps vendored and linked project integrations deterministic.
    """

    override = os.environ.get("MBSWE_CORE_ROOT")
    if override:
        root = Path(override).expanduser().resolve()
    else:
        root = Path(__file__).resolve().parents[2]
    if not (root / "package.yaml").is_file():
        raise MBSwEError(
            f"portable-core root not found at {root}; set MBSWE_CORE_ROOT to the checkout"
        )
    return root


def find_project_root(start: Path | None = None) -> Path:
    """Find the nearest ancestor containing mbswe.yaml."""

    current = (start or Path.cwd()).expanduser().resolve()
    if current.is_file():
        current = current.parent
    for candidate in (current, *current.parents):
        if (candidate / "mbswe.yaml").is_file():
            return candidate
    raise MBSwEError(
        f"no mbswe.yaml found from {current}; run 'mbswe project init <target>' first"
    )


def default_cache_root() -> Path:
    override = os.environ.get("MBSWE_CACHE_HOME")
    if override:
        return Path(override).expanduser().resolve()
    return (Path.home() / ".cache" / "mbswe").resolve()


def require_within(path: Path, roots: list[Path], *, label: str) -> Path:
    """Require a path to remain inside one explicitly configured authority-safe root."""

    resolved = path.expanduser().resolve()
    for root in roots:
        try:
            resolved.relative_to(root.expanduser().resolve())
            return resolved
        except ValueError:
            continue
    allowed = ", ".join(str(root) for root in roots)
    raise MBSwEError(f"{label} must be under one of: {allowed}; found {resolved}")
