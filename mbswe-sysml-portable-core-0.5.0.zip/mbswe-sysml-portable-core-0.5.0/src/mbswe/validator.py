"""Adapter for the checksum-pinned official SysML v2 Jupyter kernel."""

from __future__ import annotations

import os
import re
import subprocess
import tempfile
import time
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

from jupyter_client.blocking.client import BlockingKernelClient
from jupyter_client.connect import write_connection_file

from .config import ProjectConfig
from .errors import MBSwEError
from .resources import ResourcePaths, resolved_resources

DIAGNOSTIC = re.compile(
    r"(?P<level>ERROR|WARNING):(?P<message>.*?)"
    r"\((?P<cell>\d+)\.sysml line : (?P<line>\d+) column : (?P<column>\d+)\)"
)
QUALIFIED_REFERENCE = re.compile(
    r"(?:[A-Za-z_]\w*|'[^'\r\n]+')(?:\s*::\s*(?:[A-Za-z_]\w*|'[^'\r\n]+'))+\Z"
)


@dataclass(frozen=True)
class SourceSpan:
    path: Path
    first_line: int
    last_line: int


@dataclass(frozen=True)
class ValidationDiagnostic:
    level: str
    message: str
    path: str
    line: int
    column: int
    raw: str


@dataclass(frozen=True)
class ValidationResult:
    diagnostics: tuple[ValidationDiagnostic, ...]
    raw_unmapped: tuple[str, ...]

    @property
    def failed(self) -> bool:
        return any(item.level == "ERROR" for item in self.diagnostics) or bool(self.raw_unmapped)


@contextmanager
def kernel_session(resources: ResourcePaths) -> Iterator[BlockingKernelClient]:
    with tempfile.TemporaryDirectory(prefix="mbswe-sysml-") as temporary:
        root = Path(temporary)
        connection_file = root / "kernel.json"
        write_connection_file(str(connection_file))
        environment = os.environ.copy()
        environment["ISYSML_LIBRARY_PATH"] = str(resources.model_library)
        log_path = root / "kernel.log"
        with log_path.open("w", encoding="utf-8") as log:
            process = subprocess.Popen(
                [
                    str(resources.java),
                    "-cp",
                    str(resources.validator_jar),
                    "org.omg.sysml.jupyter.kernel.ISysML",
                    str(connection_file),
                ],
                cwd=resources.validator_jar.parent,
                env=environment,
                stdout=log,
                stderr=subprocess.STDOUT,
                text=True,
            )
        client = BlockingKernelClient(connection_file=str(connection_file))
        try:
            client.load_connection_file()
            client.start_channels()
            deadline = time.monotonic() + 90
            while not connection_file.exists() and time.monotonic() < deadline:
                if process.poll() is not None:
                    raise MBSwEError(
                        "official SysML kernel exited during startup:\n"
                        + log_path.read_text(encoding="utf-8", errors="replace")
                    )
                time.sleep(0.1)
            client.kernel_info()
            client.get_shell_msg(timeout=90)
            yield client
        except Exception as error:
            detail = log_path.read_text(encoding="utf-8", errors="replace")
            if isinstance(error, MBSwEError):
                raise
            raise MBSwEError(f"official SysML kernel failed: {error}\n{detail}") from error
        finally:
            client.stop_channels()
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)


def execute_source(client: BlockingKernelClient, source: str) -> list[str]:
    diagnostics: list[str] = []
    message_id = client.execute(source)
    while True:
        message = client.get_iopub_msg(timeout=180)
        if message["parent_header"].get("msg_id") != message_id:
            continue
        content = message["content"]
        msg_type = message["msg_type"]
        if msg_type == "stream":
            lines = str(content.get("text", "")).splitlines()
            if content.get("name") == "stderr":
                diagnostics.extend(lines)
            else:
                diagnostics.extend(line for line in lines if DIAGNOSTIC.search(line))
        elif msg_type == "error":
            diagnostics.extend(str(line) for line in content.get("traceback", []))
        elif msg_type == "status" and content.get("execution_state") == "idle":
            break
    return diagnostics


def combine_sources(project: ProjectConfig) -> tuple[str, list[SourceSpan]]:
    chunks: list[str] = []
    spans: list[SourceSpan] = []
    first_line = 1
    for path in project.model_files:
        source = path.read_text(encoding="utf-8")
        if not source.endswith("\n"):
            source += "\n"
        count = source.count("\n")
        spans.append(SourceSpan(path, first_line, first_line + count - 1))
        chunks.append(source)
        first_line += count
    return "".join(chunks), spans


def _source_location(project: ProjectConfig, spans: list[SourceSpan], line: int) -> tuple[str, int]:
    for span in spans:
        if span.first_line <= line <= span.last_line:
            return span.path.relative_to(project.root).as_posix(), line - span.first_line + 1
    return "<combined-model>", line


def map_diagnostics(
    project: ProjectConfig, raw: list[str], spans: list[SourceSpan]
) -> ValidationResult:
    mapped: list[ValidationDiagnostic] = []
    unmapped: list[str] = []
    for line in raw:
        match = DIAGNOSTIC.search(line)
        if match is None:
            if line.strip():
                unmapped.append(line.strip())
            continue
        combined_line = int(match.group("line"))
        path, local_line = _source_location(project, spans, combined_line)
        mapped.append(
            ValidationDiagnostic(
                level=match.group("level"),
                message=match.group("message").strip(),
                path=path,
                line=local_line,
                column=int(match.group("column")),
                raw=line,
            )
        )
    return ValidationResult(tuple(mapped), tuple(unmapped))


def validate_project_model(project: ProjectConfig, *, self_test: bool = False) -> ValidationResult:
    resources = resolved_resources(project)
    source, spans = combine_sources(project)
    with kernel_session(resources) as client:
        raw = execute_source(client, source)
    result = map_diagnostics(project, raw, spans)
    if self_test:
        with kernel_session(resources) as client:
            negative = execute_source(
                client,
                "package MBSwEValidatorNegative_7F3A { "
                "part def Broken :> MissingType_7F3A; }",
            )
        if not any(
            (match := DIAGNOSTIC.search(line)) and match.group("level") == "ERROR"
            for line in negative
        ):
            raise MBSwEError("official validator negative self-test accepted an unresolved type")
    return result


def probe(project: ProjectConfig, snippet: str) -> list[str]:
    if not snippet.strip():
        raise MBSwEError("probe requires a non-empty SysML/KerML snippet")
    resources = resolved_resources(project)
    with kernel_session(resources) as client:
        return execute_source(client, snippet)


def unresolved_references(project: ProjectConfig, references: list[str]) -> list[str]:
    unique = list(dict.fromkeys(references))
    malformed = [ref for ref in unique if QUALIFIED_REFERENCE.fullmatch(ref) is None]
    valid = [ref for ref in unique if ref not in malformed]
    if not valid:
        return malformed
    source, _ = combine_sources(project)
    first_alias_line = source.count("\n") + 2
    aliases = [
        f"    private alias reference{index:04d} for {reference};"
        for index, reference in enumerate(valid, start=1)
    ]
    source += "package 'MBSwE Reference Validation' {\n"
    source += "\n".join(aliases)
    source += "\n}\n"
    resources = resolved_resources(project)
    with kernel_session(resources) as client:
        raw = execute_source(client, source)
    unresolved = set(malformed)
    unrelated: list[str] = []
    for diagnostic in raw:
        match = DIAGNOSTIC.search(diagnostic)
        if match is None or match.group("level") != "ERROR":
            continue
        index = int(match.group("line")) - first_alias_line
        if 0 <= index < len(valid):
            unresolved.add(valid[index])
        else:
            unrelated.append(diagnostic)
    if unrelated:
        raise MBSwEError(
            "model failed outside generated reference probes:\n" + "\n".join(unrelated)
        )
    return [ref for ref in unique if ref in unresolved]
