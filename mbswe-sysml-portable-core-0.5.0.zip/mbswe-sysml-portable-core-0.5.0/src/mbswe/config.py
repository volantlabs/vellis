"""Project and portable-core manifest loading."""

from __future__ import annotations

import glob
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .errors import MBSwEError
from .io import load_yaml
from .paths import core_root, default_cache_root, find_project_root


@dataclass(frozen=True)
class ProjectConfig:
    root: Path
    raw: dict[str, Any]

    @property
    def project_id(self) -> str:
        return str(self.raw["project"]["id"])

    @property
    def profile(self) -> str:
        return str(self.raw["core"]["profile"])

    @property
    def lane(self) -> str:
        return str(self.raw["resources"]["lane"])

    @property
    def resource_lock_path(self) -> Path:
        return self.root / str(self.raw["resources"]["lock"])

    @property
    def resource_cache_root(self) -> Path:
        mode = str(self.raw["resources"].get("cache", "user"))
        if mode == "project":
            return self.root / ".mbswe" / "cache"
        if mode == "user":
            return default_cache_root()
        raise MBSwEError(f"unsupported resources.cache value {mode!r}")

    @property
    def generated_root(self) -> Path:
        return self.root / str(self.raw["model"]["generated_root"])

    @property
    def model_files(self) -> list[Path]:
        entries = self.raw["model"].get("entries", [])
        files: list[Path] = []
        for entry in entries:
            if isinstance(entry, str):
                pattern = entry
            elif isinstance(entry, dict):
                pattern = str(entry["path"])
            else:
                raise MBSwEError("model.entries items must be paths or mappings")
            matches = [Path(value) for value in glob.glob(str(self.root / pattern), recursive=True)]
            if not matches and not any(char in pattern for char in "*?["):
                matches = [self.root / pattern]
            for match in sorted(matches):
                if match.is_file() and match.suffix in {".sysml", ".kerml"} and match not in files:
                    files.append(match)
        if not files:
            raise MBSwEError(f"{self.root / 'mbswe.yaml'} selects no model files")
        missing = [path for path in files if not path.is_file()]
        if missing:
            raise MBSwEError("missing model files: " + ", ".join(str(path) for path in missing))
        return files

    def artifact_root(self, kind: str) -> Path:
        artifacts = self.raw.get("artifacts", {})
        if kind not in artifacts:
            raise MBSwEError(f"project manifest has no artifacts.{kind} path")
        return (self.root / str(artifacts[kind])).resolve()

    @property
    def allowed_generated_roots(self) -> list[Path]:
        roots = [self.generated_root.resolve()]
        for value in self.raw.get("implementation", {}).get("generated_roots", []):
            candidate = (self.root / str(value)).resolve()
            if candidate not in roots:
                roots.append(candidate)
        return roots

    @property
    def command_gates(self) -> dict[str, list[str]]:
        gates = self.raw.get("gates", {})
        result: dict[str, list[str]] = {}
        for name, command in gates.items():
            if command is None:
                continue
            if not isinstance(command, list) or not all(isinstance(item, str) for item in command):
                raise MBSwEError(f"gates.{name} must be a command argument list")
            result[str(name)] = list(command)
        return result


def load_project(root: Path | None = None) -> ProjectConfig:
    project_root = find_project_root(root)
    raw = load_yaml(project_root / "mbswe.yaml")
    try:
        schema_version = str(raw["schema_version"])
        _ = raw["project"]["id"]
        _ = raw["core"]["profile"]
        _ = raw["resources"]["lane"]
        _ = raw["resources"]["lock"]
        _ = raw["model"]["entries"]
    except (KeyError, TypeError) as error:
        raise MBSwEError(f"invalid project manifest {project_root / 'mbswe.yaml'}: {error}") from error
    if schema_version != "2.0":
        raise MBSwEError(f"unsupported mbswe.yaml schema_version {schema_version!r}")
    return ProjectConfig(project_root, raw)


def load_core_catalog() -> dict[str, Any]:
    return load_yaml(core_root() / "resources" / "catalog.yaml")


def load_layers() -> dict[str, Any]:
    return load_yaml(core_root() / "layers.yaml")
