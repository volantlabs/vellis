"""Build and query a source-labelled local index of official SysML resources."""

from __future__ import annotations

import json
import re
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Iterator

from pypdf import PdfReader

from .config import ProjectConfig
from .errors import MBSwEError
from .resources import ResourcePaths, resolved_resources
from .io import sha256_file, sha256_text

WORD = re.compile(r"[A-Za-z0-9_]+")
SEARCH_STOP_WORDS = {
    "a", "an", "and", "are", "as", "be", "between", "by", "can", "difference",
    "do", "does", "for", "from", "how", "i", "if", "in", "instead", "is", "it",
    "mean", "means", "my", "need", "not", "of", "on", "or", "other", "rather",
    "should", "that", "the", "their", "them", "there", "these", "they", "this",
    "those", "to", "use", "used", "using", "versus", "vs", "want", "what", "when",
    "which", "while", "who", "why", "with", "would", "write", "you", "your",
}
MAX_SOURCE_CHARS = 12_000
SOURCE_OVERLAP = 500
REFERENCE_INDEX_VERSION = 2


@dataclass(frozen=True)
class ReferenceHit:
    corpus: str
    title: str
    citation: str
    path: str
    snippet: str
    score: float


def _database_path(resources: ResourcePaths) -> Path:
    return resources.root / "reference.sqlite3"


def _index_fingerprint(project: ProjectConfig) -> str:
    payload = (
        f"version={REFERENCE_INDEX_VERSION}\n"
        f"lane={project.lane}\n"
        f"lock={sha256_file(project.resource_lock_path)}\n"
    )
    return "sha256:" + sha256_text(payload)


def _index_is_current(path: Path, fingerprint: str) -> bool:
    if not path.is_file():
        return False
    try:
        connection = sqlite3.connect(path)
        row = connection.execute(
            "SELECT value FROM metadata WHERE key = 'fingerprint'"
        ).fetchone()
        connection.close()
    except sqlite3.Error:
        return False
    return row is not None and str(row[0]) == fingerprint


def _chunks(text: str, *, size: int = MAX_SOURCE_CHARS, overlap: int = SOURCE_OVERLAP) -> Iterator[str]:
    text = text.strip()
    if not text:
        return
    start = 0
    while start < len(text):
        end = min(len(text), start + size)
        if end < len(text):
            newline = text.rfind("\n", start + size // 2, end)
            if newline > start:
                end = newline
        chunk = text[start:end].strip()
        if chunk:
            yield chunk
        if end >= len(text):
            break
        start = max(start + 1, end - overlap)


def _pdf_documents(path: Path, corpus: str, relative: str) -> Iterator[tuple[str, str, str, str]]:
    try:
        reader = PdfReader(str(path))
    except Exception as error:
        raise MBSwEError(f"cannot read official PDF {path}: {error}") from error
    title = str((reader.metadata.title if reader.metadata else None) or path.stem)
    for page_number, page in enumerate(reader.pages, start=1):
        try:
            text = page.extract_text() or ""
        except Exception:
            text = ""
        for chunk_number, chunk in enumerate(_chunks(text), start=1):
            identifier = f"{relative}#page={page_number}&chunk={chunk_number}"
            citation = f"{title}, physical PDF page {page_number}"
            yield title, identifier, citation, chunk


def _notebook_text(path: Path) -> str:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return path.read_text(encoding="utf-8", errors="replace")
    cells = value.get("cells", []) if isinstance(value, dict) else []
    parts: list[str] = []
    for cell in cells:
        if not isinstance(cell, dict):
            continue
        source = cell.get("source", [])
        if isinstance(source, list):
            parts.append("".join(str(item) for item in source))
        elif isinstance(source, str):
            parts.append(source)
    return "\n\n".join(parts)


def _text_documents(
    path: Path, corpus: str, relative: str
) -> Iterator[tuple[str, str, str, str]]:
    if path.suffix == ".ipynb":
        text = _notebook_text(path)
    else:
        text = path.read_text(encoding="utf-8", errors="replace")
    title = relative
    for index, chunk in enumerate(_chunks(text), start=1):
        identifier = f"{relative}#chunk={index}"
        yield title, identifier, relative, chunk


def _classify_release_file(relative: str) -> str | None:
    lowered = relative.lower()
    name = Path(relative).name
    if lowered.startswith("doc/changes/") and lowered.endswith(".pdf"):
        return "changes"
    if name == "1-Kernel_Modeling_Language.pdf" or name == "2a-OMG_Systems_Modeling_Language.pdf":
        return "language"
    if name == "2b-SysML_v1_to_v2_Transformation.pdf":
        return "migration"
    if name == "3-Systems_Modeling_API_and_Services.pdf":
        return "api"
    if name.startswith("Intro to the SysML v2 Language") and lowered.endswith(".pdf"):
        return "intro"
    if lowered.startswith("bnf/") and path_is_text(relative):
        return "grammar"
    if lowered.startswith("sysml.library/") and path_is_text(relative):
        return "library"
    if (lowered.startswith("sysml/src/") or lowered.startswith("kerml/src/")) and path_is_text(relative):
        if "/validation/" in lowered:
            return "validation-models"
        if "/training/" in lowered or "/examples/" in lowered:
            return "examples"
        return "official-models"
    return None


def path_is_text(path: str) -> bool:
    return Path(path).suffix.lower() in {
        ".sysml",
        ".kerml",
        ".kebnf",
        ".kgbnf",
        ".md",
        ".txt",
        ".html",
        ".json",
        ".yaml",
        ".yml",
        ".py",
        ".ipynb",
    }


def _iter_documents(resources: ResourcePaths) -> Iterator[tuple[str, str, str, str, str]]:
    root = resources.release_checkout
    for path in sorted(item for item in root.rglob("*") if item.is_file()):
        relative = path.relative_to(root).as_posix()
        corpus = _classify_release_file(relative)
        if corpus is None:
            continue
        if path.suffix.lower() == ".pdf":
            for title, identifier, citation, body in _pdf_documents(path, corpus, relative):
                yield corpus, title, identifier, citation, body
        else:
            for title, identifier, citation, body in _text_documents(path, corpus, relative):
                yield corpus, title, identifier, citation, body
    if resources.cookbook_checkout is not None:
        root = resources.cookbook_checkout
        for path in sorted(item for item in root.rglob("*") if item.is_file() and path_is_text(item.name)):
            if ".git" in path.parts:
                continue
            relative = path.relative_to(root).as_posix()
            for title, identifier, citation, body in _text_documents(
                path, "api-cookbook", relative
            ):
                yield "api-cookbook", title, identifier, citation, body


def build_reference_index(project: ProjectConfig, *, force: bool = False) -> Path:
    resources = resolved_resources(project)
    destination = _database_path(resources)
    fingerprint = _index_fingerprint(project)
    if not force and _index_is_current(destination, fingerprint):
        return destination
    staged = destination.with_suffix(".partial.sqlite3")
    staged.unlink(missing_ok=True)
    connection = sqlite3.connect(staged)
    try:
        connection.executescript(
            """
            PRAGMA journal_mode = OFF;
            CREATE TABLE metadata(key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE documents(
                id INTEGER PRIMARY KEY,
                corpus TEXT NOT NULL,
                title TEXT NOT NULL,
                identifier TEXT NOT NULL,
                citation TEXT NOT NULL,
                body TEXT NOT NULL
            );
            CREATE VIRTUAL TABLE documents_fts USING fts5(
                title, body, content='documents', content_rowid='id', tokenize='unicode61'
            );
            """
        )
        connection.execute(
            "INSERT INTO metadata(key,value) VALUES ('fingerprint', ?)", (fingerprint,)
        )
        connection.execute(
            "INSERT INTO metadata(key,value) VALUES ('index_version', ?)",
            (str(REFERENCE_INDEX_VERSION),),
        )
        rows = 0
        for corpus, title, identifier, citation, body in _iter_documents(resources):
            cursor = connection.execute(
                "INSERT INTO documents(corpus,title,identifier,citation,body) VALUES (?,?,?,?,?)",
                (corpus, title, identifier, citation, body),
            )
            rowid = int(cursor.lastrowid)
            connection.execute(
                "INSERT INTO documents_fts(rowid,title,body) VALUES (?,?,?)",
                (rowid, title, body),
            )
            rows += 1
        if rows == 0:
            raise MBSwEError("reference build produced no documents")
        connection.execute("CREATE INDEX documents_corpus ON documents(corpus)")
        connection.commit()
    finally:
        connection.close()
    staged.replace(destination)
    return destination


def _fts_query(text: str) -> str:
    raw = [term.lower() for term in WORD.findall(text) if len(term) > 1]
    terms = list(dict.fromkeys(term for term in raw if term not in SEARCH_STOP_WORDS))
    if not terms:
        terms = list(dict.fromkeys(raw))
    if not terms:
        raise MBSwEError("reference search requires at least one alphanumeric term")
    return " OR ".join(f'"{term.replace(chr(34), chr(34) * 2)}"' for term in terms)


def _snippet(text: str, terms: Iterable[str], limit: int = 360) -> str:
    flat = " ".join(text.split())
    positions = [flat.lower().find(term.lower()) for term in terms]
    positions = [position for position in positions if position >= 0]
    center = min(positions) if positions else 0
    start = max(0, center - limit // 3)
    end = min(len(flat), start + limit)
    value = flat[start:end]
    if start:
        value = "…" + value
    if end < len(flat):
        value += "…"
    return value


def search_reference(
    project: ProjectConfig,
    query: str,
    *,
    corpora: list[str] | None = None,
    limit: int = 10,
) -> list[ReferenceHit]:
    resources = resolved_resources(project)
    database = build_reference_index(project)
    match = _fts_query(query)
    connection = sqlite3.connect(database)
    connection.row_factory = sqlite3.Row
    try:
        clauses = ["documents_fts MATCH ?"]
        params: list[object] = [match]
        if corpora:
            placeholders = ",".join("?" for _ in corpora)
            clauses.append(f"documents.corpus IN ({placeholders})")
            params.extend(corpora)
        params.append(limit)
        sql = f"""
            SELECT documents.corpus, documents.title, documents.identifier,
                   documents.citation, documents.body,
                   bm25(documents_fts, 4.0, 1.0) AS score
            FROM documents_fts
            JOIN documents ON documents.id = documents_fts.rowid
            WHERE {' AND '.join(clauses)}
            ORDER BY score, documents.corpus, documents.identifier
            LIMIT ?
        """
        rows = connection.execute(sql, params).fetchall()
    except sqlite3.OperationalError as error:
        raise MBSwEError(f"reference search failed: {error}") from error
    finally:
        connection.close()
    terms = WORD.findall(query)
    return [
        ReferenceHit(
            corpus=str(row["corpus"]),
            title=str(row["title"]),
            citation=str(row["citation"]),
            path=str(row["identifier"]),
            snippet=_snippet(str(row["body"]), terms),
            score=float(row["score"]),
        )
        for row in rows
    ]


def available_corpora(project: ProjectConfig) -> list[str]:
    resources = resolved_resources(project)
    database = build_reference_index(project)
    connection = sqlite3.connect(database)
    try:
        return [
            str(row[0])
            for row in connection.execute("SELECT DISTINCT corpus FROM documents ORDER BY corpus")
        ]
    finally:
        connection.close()
