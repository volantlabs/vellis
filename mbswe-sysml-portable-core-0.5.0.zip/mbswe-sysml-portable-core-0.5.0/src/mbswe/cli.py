"""Command-line interface for the portable SysML experience."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import yaml

from . import __version__
from .artifacts import SCHEMA_BY_KIND, validate_artifact
from .checks import run_gate
from .config import load_core_catalog, load_layers, load_project
from .corecheck import core_errors, write_manifest
from .errors import MBSwEError
from .layers import archive_profile, export_profile
from .manifests import sync_provider_manifests
from .model import model_digest, source_inventory
from .paths import core_root, require_within
from .project import (
    init_project,
    project_errors,
    project_status,
    sync_project,
    upgrade_resources,
)
from .projection import projection_result
from .reference import available_corpora, build_reference_index, search_reference
from .resources import resource_status, sync_resources
from .slices import generate_execution_slice
from .validator import probe, unresolved_references, validate_project_model

def _project(args: argparse.Namespace):
    return load_project(Path(args.project) if getattr(args, "project", None) else None)


def _project_root(args: argparse.Namespace) -> Path:
    return _project(args).root


def _json(value: object) -> None:
    print(json.dumps(value, indent=2, sort_keys=True, default=str))


def _add_project(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--project", help="project directory; otherwise search upward for mbswe.yaml")


def _add_projection_arguments(parser: argparse.ArgumentParser) -> None:
    _add_project(parser)
    parser.add_argument(
        "projector", choices=("source-inventory", "model-brief", "decision-report")
    )
    parser.add_argument("output", type=Path)
    parser.add_argument("--index", type=Path)
    parser.add_argument("--result", type=Path)


def build_parser() -> argparse.ArgumentParser:
    layer_manifest = load_layers()
    available_profiles = tuple(layer_manifest["profiles"])
    default_profile = available_profiles[-1]
    has_realization = "realization" in layer_manifest.get("layers", {})
    available_artifact_kinds = tuple(
        kind
        for kind, schema in SCHEMA_BY_KIND.items()
        if (core_root() / "schemas" / schema).is_file()
    )
    if has_realization:
        description = (
            "Portable SysML v2 language-reference, model-engineering, projection, "
            "and bounded-realization stack."
        )
    elif "modeling" in layer_manifest.get("layers", {}):
        description = "Portable SysML v2 language-reference and model-engineering stack."
    else:
        description = "Portable checksum-pinned SysML v2 language-reference foundation."
    parser = argparse.ArgumentParser(prog="mbswe", description=description)
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    core = sub.add_parser("core", help="validate and maintain the portable-core checkout")
    core_sub = core.add_subparsers(dest="core_command", required=True)
    core_sub.add_parser("check", help="run offline structural and contract checks")
    core_sub.add_parser("sync", help="regenerate provider manifests from package.yaml")
    core_sub.add_parser("manifest", help="write MANIFEST.sha256")

    layer = sub.add_parser("layer", help="list, export, or archive cumulative profiles")
    layer_sub = layer.add_subparsers(dest="layer_command", required=True)
    layer_sub.add_parser("list")
    export = layer_sub.add_parser("export", help="write a standalone profile repository")
    export.add_argument("profile", choices=available_profiles)
    export.add_argument("destination", type=Path)
    export.add_argument("--force", action="store_true")
    archive = layer_sub.add_parser("archive", help="write a standalone profile ZIP")
    archive.add_argument("profile", choices=available_profiles)
    archive.add_argument("destination", type=Path)
    archive.add_argument("--force", action="store_true")

    project = sub.add_parser("project", help="initialize, synchronize, or inspect a target repository")
    project_sub = project.add_subparsers(dest="project_command", required=True)
    init = project_sub.add_parser("init")
    init.add_argument("target", type=Path)
    init.add_argument("--profile", choices=available_profiles, default=default_profile)
    init.add_argument("--lane", default="stable-2.0")
    init.add_argument("--id")
    init.add_argument("--providers", default="claude,codex")
    init.add_argument("--install-mode", choices=("external", "vendored"), default="external")
    init.add_argument("--force", action="store_true")
    for name in ("status", "check", "sync"):
        command = project_sub.add_parser(name)
        _add_project(command)
    upgrade = project_sub.add_parser(
        "upgrade-resources", help="explicitly replace the selected official resource lane"
    )
    _add_project(upgrade)
    upgrade.add_argument("lane")

    resources = sub.add_parser("resources", help="manage checksum-pinned official resource lanes")
    resources_sub = resources.add_subparsers(dest="resources_command", required=True)
    resources_sub.add_parser("list")
    sync = resources_sub.add_parser("sync")
    _add_project(sync)
    sync.add_argument("--bundled-java", action="store_true")
    status_resources = resources_sub.add_parser("status")
    _add_project(status_resources)

    reference = sub.add_parser("reference", help="build and query the source-labelled official corpus")
    reference_sub = reference.add_subparsers(dest="reference_command", required=True)
    build = reference_sub.add_parser("build")
    _add_project(build)
    build.add_argument("--force", action="store_true")
    corpora = reference_sub.add_parser("corpora")
    _add_project(corpora)
    search = reference_sub.add_parser("search")
    _add_project(search)
    search.add_argument("query")
    search.add_argument("--corpus", action="append", default=[])
    search.add_argument("--limit", type=int, default=10)
    search.add_argument("--json", action="store_true")

    model = sub.add_parser("model", help="validate, probe, resolve, digest, or inventory model source")
    model_sub = model.add_subparsers(dest="model_command", required=True)
    validate = model_sub.add_parser("validate")
    _add_project(validate)
    validate.add_argument("--self-test", action="store_true")
    probe_parser = model_sub.add_parser("probe")
    _add_project(probe_parser)
    probe_parser.add_argument("source", nargs="?")
    resolve = model_sub.add_parser("resolve")
    _add_project(resolve)
    resolve.add_argument("references", nargs="+")
    digest = model_sub.add_parser("digest")
    _add_project(digest)
    inventory = model_sub.add_parser("inventory")
    _add_project(inventory)
    inventory.add_argument("--output", type=Path)

    if has_realization:
        projection = sub.add_parser(
            "projection", help="create deterministic, disposable artifacts without design authority"
        )
        projection_sub = projection.add_subparsers(dest="projection_command", required=True)
        create = projection_sub.add_parser("create")
        _add_projection_arguments(create)

    artifact = sub.add_parser("artifact", help="validate portable generated-artifact contracts")
    artifact_sub = artifact.add_subparsers(dest="artifact_command", required=True)
    artifact_validate = artifact_sub.add_parser("validate")
    artifact_validate.add_argument("kind", choices=available_artifact_kinds)
    artifact_validate.add_argument("path", type=Path)

    if has_realization:
        slice_parser = sub.add_parser(
            "slice", help="generate or validate decision-complete execution slices"
        )
        slice_sub = slice_parser.add_subparsers(dest="slice_command", required=True)
        slice_validate = slice_sub.add_parser("validate")
        slice_validate.add_argument("path", type=Path)
        slice_generate = slice_sub.add_parser("from-index")
        _add_project(slice_generate)
        slice_generate.add_argument("--index", type=Path, required=True)
        slice_generate.add_argument("--operation", required=True)
        slice_generate.add_argument("--output", type=Path, required=True)
        slice_generate.add_argument("--id", required=True)
        slice_generate.add_argument("--title", required=True)
        slice_generate.add_argument("--checkpoint", required=True)
        slice_generate.add_argument("--mode", choices=("copilot", "autonomous"), default="copilot")
        slice_generate.add_argument(
            "--approval", choices=("pending", "accepted", "not-required"), default="pending"
        )
        slice_generate.add_argument("--approval-artifact")

    gate = sub.add_parser("gate", help="run one explicitly configured target-project gate")
    _add_project(gate)
    gate.add_argument("name")
    return parser


def _create_projection(args: argparse.Namespace) -> int:
    project = _project(args)
    output = args.output if args.output.is_absolute() else project.root / args.output
    index = args.index
    if index is not None and not index.is_absolute():
        index = project.root / index
    result = projection_result(
        project,
        projector=args.projector,
        destination=output,
        index=index,
    )
    if args.result:
        result_path = args.result if args.result.is_absolute() else project.root / args.result
        result_path = require_within(
            result_path, [project.artifact_root("projections")], label="projection result"
        )
        result_path.parent.mkdir(parents=True, exist_ok=True)
        result_path.write_text(yaml.safe_dump(result, sort_keys=False), encoding="utf-8")
    _json(result)
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.command == "core":
            if args.core_command == "check":
                errors = core_errors()
                if errors:
                    print("\n".join(f"ERROR {item}" for item in errors))
                    return 1
                print("portable-core self-check passed")
                return 0
            if args.core_command == "sync":
                errors = sync_provider_manifests()
                if errors:
                    print("\n".join(f"ERROR {item}" for item in errors))
                    return 1
                print("provider manifests synchronized")
                return 0
            path = write_manifest()
            print(path)
            return 0

        if args.command == "layer":
            if args.layer_command == "list":
                manifest = load_layers()
                for name, record in manifest["layers"].items():
                    print(f"{record['ordinal']}. {name}: {record['title']} — {record['description']}")
                print("profiles:")
                for name, record in manifest["profiles"].items():
                    print(f"  {name}: layers={record['layers']} extras={record['extras']}")
                return 0
            if args.layer_command == "archive":
                print(archive_profile(args.profile, args.destination, force=args.force))
            else:
                print(export_profile(args.profile, args.destination, force=args.force))
            return 0

        if args.command == "project":
            if args.project_command == "init":
                providers = [item.strip() for item in args.providers.split(",") if item.strip()]
                print(
                    init_project(
                        args.target,
                        profile=args.profile,
                        lane=args.lane,
                        project_id=args.id,
                        providers=providers,
                        install_mode=args.install_mode,
                        force=args.force,
                    )
                )
                return 0
            if args.project_command == "sync":
                print(sync_project(_project_root(args)))
                return 0
            if args.project_command == "upgrade-resources":
                print(upgrade_resources(_project_root(args), args.lane))
                return 0
            if args.project_command == "check":
                errors = project_errors(_project_root(args))
                if errors:
                    print("\n".join(f"ERROR {item}" for item in errors))
                    return 1
                print("project integration check passed")
                return 0
            _json(project_status(_project_root(args)))
            return 0

        if args.command == "resources":
            if args.resources_command == "list":
                catalog = load_core_catalog()
                for name, record in catalog["lanes"].items():
                    print(f"{name}: {record['status']} — {record['label']}")
                return 0
            project = _project(args)
            if args.resources_command == "status":
                _json(resource_status(project))
                return 0
            paths = sync_resources(project, prefer_system_java=not args.bundled_java)
            _json(
                {
                    "lane": paths.lane,
                    "release": paths.release_checkout,
                    "validator": paths.validator_jar,
                    "library": paths.model_library,
                    "java": paths.java,
                    "api_cookbook": paths.cookbook_checkout,
                }
            )
            return 0

        if args.command == "reference":
            project = _project(args)
            if args.reference_command == "build":
                print(build_reference_index(project, force=args.force))
                return 0
            if args.reference_command == "corpora":
                print("\n".join(available_corpora(project)))
                return 0
            hits = search_reference(project, args.query, corpora=args.corpus or None, limit=args.limit)
            if args.json:
                _json([hit.__dict__ for hit in hits])
            else:
                for index, hit in enumerate(hits, start=1):
                    print(f"{index}. [{hit.corpus}] {hit.title}")
                    print(f"   {hit.citation} — {hit.path}")
                    print(f"   {hit.snippet}")
            return 0

        if args.command == "model":
            project = _project(args)
            if args.model_command == "validate":
                result = validate_project_model(project, self_test=args.self_test)
                for item in result.diagnostics:
                    print(f"{item.level} {item.path}:{item.line}:{item.column}: {item.message}")
                for item in result.raw_unmapped:
                    print(f"ERROR {item}")
                if result.failed:
                    return 1
                print(f"formal model validation passed for {len(project.model_files)} files")
                return 0
            if args.model_command == "probe":
                source = args.source if args.source is not None else sys.stdin.read()
                raw = probe(project, source)
                print("\n".join(raw))
                if any("ERROR:" in item for item in raw):
                    return 1
                print("snippet accepted; parser acceptance is not semantic adequacy")
                return 0
            if args.model_command == "resolve":
                unresolved = unresolved_references(project, args.references)
                if unresolved:
                    print("\n".join(unresolved))
                    return 1
                print("all references resolved")
                return 0
            if args.model_command == "digest":
                print(model_digest(project))
                return 0
            value = source_inventory(project)
            if args.output:
                output = args.output if args.output.is_absolute() else project.root / args.output
                output = require_within(
                    output, [project.generated_root], label="model inventory output"
                )
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
            else:
                _json(value)
            return 0

        if args.command == "projection":
            return _create_projection(args)

        if args.command == "artifact":
            errors = validate_artifact(args.kind, args.path)
            if errors:
                print("\n".join(f"ERROR {item}" for item in errors))
                return 1
            print(f"{args.kind} validation passed: {args.path}")
            return 0

        if args.command == "slice":
            if args.slice_command == "validate":
                errors = validate_artifact("execution-slice", args.path)
                if errors:
                    print("\n".join(f"ERROR {item}" for item in errors))
                    return 1
                print(f"execution-slice validation passed: {args.path}")
                return 0
            project = _project(args)
            index = args.index if args.index.is_absolute() else project.root / args.index
            output = args.output if args.output.is_absolute() else project.root / args.output
            print(
                generate_execution_slice(
                    project,
                    index_path=index,
                    operation_ref=args.operation,
                    destination=output,
                    slice_id=args.id,
                    title=args.title,
                    implementation_checkpoint=args.checkpoint,
                    mode=args.mode,
                    approval_status=args.approval,
                    approval_artifact=args.approval_artifact,
                )
            )
            return 0

        if args.command == "gate":
            result = run_gate(_project(args), args.name)
            sys.stdout.write(result.stdout)
            sys.stderr.write(result.stderr)
            return result.returncode
    except MBSwEError as error:
        print(f"ERROR {error}", file=sys.stderr)
        return 2
    parser.error("unhandled command")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
