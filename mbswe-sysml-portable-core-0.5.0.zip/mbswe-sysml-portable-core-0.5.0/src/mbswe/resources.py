"""Checksum-pinned official resource bootstrap and cache management."""

from __future__ import annotations

import json
import os
import platform
import re
import shutil
import subprocess
import tarfile
import tempfile
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

from .config import ProjectConfig, load_core_catalog
from .errors import MBSwEError
from .io import load_json, sha256_file

DOWNLOAD_TIMEOUT_SECONDS = 300


@dataclass(frozen=True)
class ResourcePaths:
    lane: str
    root: Path
    release_checkout: Path
    cookbook_checkout: Path | None
    validator_root: Path
    validator_jar: Path
    model_library: Path
    java: Path


def platform_key() -> str:
    machine = platform.machine().lower()
    aliases = {"aarch64": "arm64", "amd64": "x86_64", "x64": "x86_64"}
    machine = aliases.get(machine, machine)
    system = platform.system().lower()
    return f"{system}-{machine}"


def _run(arguments: list[str], *, cwd: Path | None = None) -> str:
    try:
        completed = subprocess.run(
            arguments,
            cwd=str(cwd) if cwd else None,
            check=False,
            text=True,
            capture_output=True,
        )
    except OSError as error:
        raise MBSwEError(f"cannot execute {arguments[0]!r}: {error}") from error
    if completed.returncode != 0:
        command = " ".join(arguments)
        detail = completed.stderr.strip() or completed.stdout.strip()
        raise MBSwEError(f"command failed ({command}): {detail}")
    return completed.stdout.strip()


def _download(url: str, expected_sha256: str, destination: Path) -> Path:
    if destination.is_file() and sha256_file(destination) == expected_sha256:
        return destination
    destination.parent.mkdir(parents=True, exist_ok=True)
    request = urllib.request.Request(url, headers={"User-Agent": "mbswe-portable-core/0.5"})
    with tempfile.NamedTemporaryFile(dir=destination.parent, delete=False) as temporary:
        staged = Path(temporary.name)
    try:
        with urllib.request.urlopen(request, timeout=DOWNLOAD_TIMEOUT_SECONDS) as response:  # noqa: S310
            with staged.open("wb") as stream:
                shutil.copyfileobj(response, stream)
        actual = sha256_file(staged)
        if actual != expected_sha256:
            raise MBSwEError(
                f"checksum mismatch for {url}: expected {expected_sha256}, found {actual}"
            )
        staged.replace(destination)
    except BaseException:
        staged.unlink(missing_ok=True)
        raise
    return destination


def _safe_member_path(root: Path, member: str) -> Path:
    target = (root / member).resolve()
    try:
        target.relative_to(root.resolve())
    except ValueError as error:
        raise MBSwEError(f"archive member escapes destination: {member}") from error
    return target


def _extract_zip(archive_path: Path, destination: Path) -> None:
    staged = destination.with_name(destination.name + ".partial")
    shutil.rmtree(staged, ignore_errors=True)
    staged.mkdir(parents=True)
    try:
        with zipfile.ZipFile(archive_path) as archive:
            for info in archive.infolist():
                _safe_member_path(staged, info.filename)
            archive.extractall(staged)
        shutil.rmtree(destination, ignore_errors=True)
        staged.replace(destination)
    except BaseException:
        shutil.rmtree(staged, ignore_errors=True)
        raise


def _extract_tar(archive_path: Path, destination: Path) -> None:
    staged = destination.with_name(destination.name + ".partial")
    shutil.rmtree(staged, ignore_errors=True)
    staged.mkdir(parents=True)
    try:
        with tarfile.open(archive_path) as archive:
            for member in archive.getmembers():
                _safe_member_path(staged, member.name)
            # Python's data filter blocks path traversal and unsafe link targets
            # while preserving legitimate runtime symlinks.
            archive.extractall(staged, filter="data")
        children = [path for path in staged.iterdir()]
        if len(children) == 1 and children[0].is_dir():
            unwrapped = staged.with_name(staged.name + ".unwrapped")
            shutil.rmtree(unwrapped, ignore_errors=True)
            children[0].replace(unwrapped)
            staged.rmdir()
            staged = unwrapped
        shutil.rmtree(destination, ignore_errors=True)
        staged.replace(destination)
    except BaseException:
        shutil.rmtree(staged, ignore_errors=True)
        raise


def _clone_tagged_sparse(
    repository: str,
    tag: str,
    commit: str,
    sparse_paths: Iterable[str],
    destination: Path,
) -> Path:
    if (destination / ".git").is_dir():
        try:
            if _run(["git", "rev-parse", "HEAD"], cwd=destination) == commit:
                return destination
        except MBSwEError:
            pass
        shutil.rmtree(destination)
    staged = destination.with_name(destination.name + ".partial")
    shutil.rmtree(staged, ignore_errors=True)
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        _run(
            [
                "git",
                "clone",
                "--depth",
                "1",
                "--branch",
                tag,
                "--filter=blob:none",
                "--sparse",
                "--quiet",
                repository,
                str(staged),
            ]
        )
        paths = list(sparse_paths)
        if paths:
            _run(["git", "sparse-checkout", "set", "--no-cone", *paths], cwd=staged)
        actual = _run(["git", "rev-parse", "HEAD"], cwd=staged)
        if actual != commit:
            raise MBSwEError(
                f"{repository} tag {tag} resolved to {actual}, expected locked commit {commit}"
            )
        staged.replace(destination)
    except BaseException:
        shutil.rmtree(staged, ignore_errors=True)
        raise
    return destination


def _clone_commit(repository: str, commit: str, destination: Path) -> Path:
    if (destination / ".git").is_dir():
        try:
            if _run(["git", "rev-parse", "HEAD"], cwd=destination) == commit:
                return destination
        except MBSwEError:
            pass
        shutil.rmtree(destination)
    staged = destination.with_name(destination.name + ".partial")
    shutil.rmtree(staged, ignore_errors=True)
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        _run(["git", "init", "--quiet", str(staged)])
        _run(["git", "remote", "add", "origin", repository], cwd=staged)
        _run(["git", "fetch", "--depth", "1", "origin", commit], cwd=staged)
        _run(["git", "checkout", "--quiet", "--detach", "FETCH_HEAD"], cwd=staged)
        actual = _run(["git", "rev-parse", "HEAD"], cwd=staged)
        if actual != commit:
            raise MBSwEError(
                f"{repository} fetched {actual}, expected locked commit {commit}"
            )
        staged.replace(destination)
    except BaseException:
        shutil.rmtree(staged, ignore_errors=True)
        raise
    return destination


def _java_version(java: Path) -> int | None:
    try:
        completed = subprocess.run(
            [str(java), "-version"], capture_output=True, text=True, check=False
        )
    except OSError:
        return None
    text = completed.stderr + completed.stdout
    match = re.search(r'version "(?P<major>\d+)', text)
    return int(match.group("major")) if match else None


def _system_java(minimum: int) -> Path | None:
    executable = shutil.which("java")
    if not executable:
        return None
    java = Path(executable).resolve()
    major = _java_version(java)
    return java if major is not None and major >= minimum else None


def _java_in_runtime(runtime: Path) -> Path | None:
    candidates = [
        runtime / "bin" / ("java.exe" if os.name == "nt" else "java"),
        runtime / "Contents" / "Home" / "bin" / "java",
    ]
    return next((candidate for candidate in candidates if candidate.is_file()), None)


def _ensure_java(lane_root: Path, runtime: dict[str, Any], *, prefer_system: bool) -> Path:
    minimum = int(runtime.get("minimum_major", 17))
    if prefer_system and (java := _system_java(minimum)) is not None:
        return java
    key = platform_key()
    artifact = runtime.get("platforms", {}).get(key)
    if not isinstance(artifact, dict):
        system = _system_java(minimum)
        if system is not None:
            return system
        raise MBSwEError(
            f"no bundled Java runtime for {key}; install Java {minimum}+ or extend resources/catalog.yaml"
        )
    archive = lane_root / "downloads" / f"java-{key}.tar.gz"
    _download(str(artifact["url"]), str(artifact["sha256"]), archive)
    destination = lane_root / f"java-{key}"
    java = _java_in_runtime(destination)
    if java is None:
        _extract_tar(archive, destination)
        java = _java_in_runtime(destination)
    if java is None:
        raise MBSwEError(f"bundled Java archive for {key} contained no java executable")
    return java


def _find_validator_assets(root: Path, version: str) -> tuple[Path, Path]:
    jars = sorted(root.rglob(f"*{version}*all.jar")) or sorted(root.rglob("*all.jar"))
    libraries = sorted(path for path in root.rglob("sysml.library") if path.is_dir())
    if not jars:
        raise MBSwEError(f"validator archive under {root} contained no executable *all.jar")
    if not libraries:
        raise MBSwEError(f"validator archive under {root} contained no sysml.library directory")
    return jars[0], libraries[0]


def lane_record(lane: str) -> dict[str, Any]:
    catalog = load_core_catalog()
    lanes = catalog.get("lanes")
    if not isinstance(lanes, dict) or lane not in lanes:
        known = ", ".join(sorted(lanes or {}))
        raise MBSwEError(f"unknown resource lane {lane!r}; available: {known}")
    value = lanes[lane]
    if not isinstance(value, dict):
        raise MBSwEError(f"invalid resource lane {lane!r}")
    return value


def verify_project_lock(project: ProjectConfig) -> dict[str, Any]:
    lock = load_json(project.resource_lock_path)
    if lock.get("lane") != project.lane:
        raise MBSwEError(
            f"{project.resource_lock_path}: lane {lock.get('lane')!r} does not match {project.lane!r}"
        )
    locked = lane_record(project.lane)
    if lock.get("catalog_digest") != locked.get("catalog_digest"):
        raise MBSwEError(
            f"{project.resource_lock_path}: resource metadata differs from this core; "
            "run 'mbswe project upgrade-resources' deliberately"
        )
    return lock


def sync_resources(
    project: ProjectConfig,
    *,
    cache_root: Path | None = None,
    prefer_system_java: bool = True,
) -> ResourcePaths:
    """Materialize the project's immutable official resource lane."""

    lock = verify_project_lock(project)
    lane = project.lane
    lane_root = (cache_root or project.resource_cache_root) / "lanes" / lane
    release = lock["release"]
    release_checkout = _clone_tagged_sparse(
        str(release["repository"]),
        str(release["tag"]),
        str(release["commit"]),
        [str(path) for path in release["sparse_paths"]],
        lane_root / "release",
    )

    cookbook_checkout: Path | None = None
    cookbook = lock.get("api_cookbook")
    if isinstance(cookbook, dict) and cookbook.get("enabled", True):
        cookbook_checkout = _clone_commit(
            str(cookbook["repository"]),
            str(cookbook["commit"]),
            lane_root / "api-cookbook",
        )

    validator = lock["validator"]
    archive = lane_root / "downloads" / f"validator-{validator['version']}.zip"
    _download(str(validator["url"]), str(validator["sha256"]), archive)
    validator_root = lane_root / f"validator-{validator['version']}"
    try:
        jar, library = _find_validator_assets(validator_root, str(validator["version"]))
    except MBSwEError:
        _extract_zip(archive, validator_root)
        jar, library = _find_validator_assets(validator_root, str(validator["version"]))

    java = _ensure_java(lane_root, lock["java"], prefer_system=prefer_system_java)
    metadata = {
        "lane": lane,
        "release_commit": release["commit"],
        "validator_sha256": validator["sha256"],
        "validator_jar": str(jar),
        "model_library": str(library),
        "java": str(java),
    }
    (lane_root / "resolved.json").write_text(
        json.dumps(metadata, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return ResourcePaths(
        lane=lane,
        root=lane_root,
        release_checkout=release_checkout,
        cookbook_checkout=cookbook_checkout,
        validator_root=validator_root,
        validator_jar=jar,
        model_library=library,
        java=java,
    )




def resource_status(project: ProjectConfig, *, cache_root: Path | None = None) -> dict[str, Any]:
    """Report lane resolution without treating an unsynchronized cache as an error."""

    root = (cache_root or project.resource_cache_root) / "lanes" / project.lane
    metadata_path = root / "resolved.json"
    status: dict[str, Any] = {
        "lane": project.lane,
        "root": str(root),
        "synchronized": False,
        "missing": [],
    }
    if not metadata_path.is_file():
        status["missing"] = ["resolved.json"]
        return status
    try:
        metadata = load_json(metadata_path)
    except (OSError, ValueError, TypeError) as error:
        status["error"] = f"invalid resolved metadata: {error}"
        return status
    release = root / "release"
    cookbook = root / "api-cookbook"
    raw_paths = {
        "release": str(release),
        "validator": str(metadata.get("validator_jar", "")),
        "library": str(metadata.get("model_library", "")),
        "java": str(metadata.get("java", "")),
    }
    candidates = {name: Path(value) for name, value in raw_paths.items()}
    missing = [
        name for name, path in candidates.items() if not raw_paths[name] or not path.exists()
    ]
    status.update(
        {
            "synchronized": not missing,
            "missing": missing,
            "release": str(release),
            "api_cookbook": str(cookbook) if cookbook.is_dir() else None,
            "validator": str(candidates["validator"]),
            "library": str(candidates["library"]),
            "java": str(candidates["java"]),
        }
    )
    return status


def resolved_resources(
    project: ProjectConfig, *, cache_root: Path | None = None
) -> ResourcePaths:
    root = (cache_root or project.resource_cache_root) / "lanes" / project.lane
    metadata_path = root / "resolved.json"
    if not metadata_path.is_file():
        raise MBSwEError("resources are not synchronized; run 'mbswe resources sync'")
    metadata = load_json(metadata_path)
    release = root / "release"
    cookbook = root / "api-cookbook"
    paths = ResourcePaths(
        lane=project.lane,
        root=root,
        release_checkout=release,
        cookbook_checkout=cookbook if cookbook.is_dir() else None,
        validator_root=Path(str(metadata["validator_jar"])).parent,
        validator_jar=Path(str(metadata["validator_jar"])),
        model_library=Path(str(metadata["model_library"])),
        java=Path(str(metadata["java"])),
    )
    missing = [
        path
        for path in (
            paths.release_checkout,
            paths.validator_jar,
            paths.model_library,
            paths.java,
        )
        if not path.exists()
    ]
    if missing:
        raise MBSwEError(
            "resource cache is incomplete; rerun 'mbswe resources sync': "
            + ", ".join(str(path) for path in missing)
        )
    return paths
