"""Validation for generated protocol artifacts."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import yaml
from jsonschema import Draft202012Validator, FormatChecker

from .errors import MBSwEError
from .paths import core_root

SCHEMA_BY_KIND = {
    "project": "project-manifest.schema.json",
    "resource-lock": "resource-lock.schema.json",
    "model-index": "model-index.schema.json",
    "execution-slice": "execution-slice.schema.json",
    "projection-request": "projection-request.schema.json",
    "projection-result": "projection-result.schema.json",
    "realization-result": "realization-result.schema.json",
    "model-feedback": "model-feedback.schema.json",
    "change-note": "change-note.schema.json",
    "domain-pack": "domain-pack.schema.json",
}


def load_artifact(path: Path) -> Any:
    text = path.read_text(encoding="utf-8")
    return json.loads(text) if path.suffix.lower() == ".json" else yaml.safe_load(text)


def schema_errors(value: Any, schema_path: Path) -> list[str]:
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    validator = Draft202012Validator(schema, format_checker=FormatChecker())
    return [
        f"{'/'.join(str(part) for part in error.absolute_path) or '<root>'}: {error.message}"
        for error in sorted(validator.iter_errors(value), key=lambda item: list(item.absolute_path))
    ]


def duplicate_ids(values: list[dict[str, Any]], label: str) -> list[str]:
    seen: set[str] = set()
    errors: list[str] = []
    for value in values:
        identifier = str(value.get("id", ""))
        if identifier in seen:
            errors.append(f"{label}: duplicate id {identifier!r}")
        seen.add(identifier)
    return errors


def semantic_model_index_errors(value: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    claims = value.get("claims", [])
    decisions = value.get("decisions", [])
    responsibilities = value.get("responsibilities", [])
    states = value.get("states", [])
    interactions = value.get("interactions", [])
    boundaries = value.get("boundaries", [])
    operations = value.get("operations", [])
    evidence = value.get("evidence", [])
    errors += duplicate_ids(claims, "claims")
    errors += duplicate_ids(decisions, "decisions")
    errors += duplicate_ids(evidence, "evidence")
    responsibility_refs = [str(item.get("ref", "")) for item in responsibilities]
    interaction_refs = [str(item.get("ref", "")) for item in interactions]
    if len(responsibility_refs) != len(set(responsibility_refs)):
        errors.append("responsibilities: duplicate ref")
    if len(interaction_refs) != len(set(interaction_refs)):
        errors.append("interactions: duplicate ref")
    evidence_by_id = {item["id"]: item for item in evidence}
    decision_by_id = {item["id"]: item for item in decisions}
    responsibility_by_ref = {item["ref"]: item for item in responsibilities}
    state_by_ref = {item["ref"]: item for item in states}
    interaction_by_ref = {item["ref"]: item for item in interactions}
    operation_by_ref = {item["ref"]: item for item in operations}

    for claim in claims:
        identifier = claim["id"]
        if claim["architecture_critical"] and claim["strength"] == "rationaleOnly":
            errors.append(f"claim {identifier}: architecture-critical authority cannot be rationaleOnly")
        if claim["strength"] == "proseWithEvidence":
            for field in ("residual_prose", "nearest_wrong_system", "waiver"):
                if not claim.get(field):
                    errors.append(f"claim {identifier}: proseWithEvidence requires {field}")
            refs = claim.get("evidence_refs", [])
            if not refs:
                errors.append(f"claim {identifier}: proseWithEvidence requires evidence_refs")
            missing = [ref for ref in refs if ref not in evidence_by_id]
            if missing:
                errors.append(f"claim {identifier}: unresolved evidence refs {missing}")
            wrong = str(claim.get("nearest_wrong_system", "")).strip()
            if wrong and not any(
                str(evidence_by_id.get(ref, {}).get("excludes", "")).strip() == wrong
                for ref in refs
            ):
                errors.append(
                    f"claim {identifier}: no referenced evidence excludes nearest_wrong_system"
                )

    for decision in decisions:
        identifier = decision["id"]
        if decision["impact"] == "consequential" and decision["disposition"] == "delegated":
            errors.append(f"decision {identifier}: consequential decisions cannot be delegated")
        if decision["impact"] == "consequential" and decision["disposition"] == "governed":
            if not decision.get("rationale_refs"):
                errors.append(f"decision {identifier}: governed consequential decision lacks rationale")
            if not decision.get("reconsider_when"):
                errors.append(
                    f"decision {identifier}: governed consequential decision lacks reconsider_when"
                )


    for responsibility in responsibilities:
        identifier = responsibility["ref"]
        parent = responsibility.get("parent_ref")
        if parent and parent not in responsibility_by_ref:
            errors.append(f"responsibility {identifier}: unresolved parent_ref {parent}")
        for dependency in responsibility.get("depends_on_refs", []):
            if dependency not in responsibility_by_ref:
                errors.append(
                    f"responsibility {identifier}: unresolved dependency {dependency}"
                )
        for state_ref in responsibility.get("owns_state_refs", []):
            state = state_by_ref.get(state_ref)
            if state is None:
                errors.append(f"responsibility {identifier}: unresolved owned state {state_ref}")
            elif identifier not in state.get("owner_refs", []):
                errors.append(
                    f"responsibility {identifier}: owns {state_ref} but state does not name it as owner"
                )
        for operation_ref in responsibility.get("performs_operation_refs", []):
            operation = operation_by_ref.get(operation_ref)
            if operation is None:
                errors.append(
                    f"responsibility {identifier}: unresolved performed operation {operation_ref}"
                )
            elif operation.get("owner_ref") != identifier:
                errors.append(
                    f"responsibility {identifier}: performs {operation_ref} but operation owner differs"
                )

    for interaction in interactions:
        identifier = interaction["ref"]
        for endpoint in ("source_ref", "target_ref"):
            target = interaction[endpoint]
            if target not in responsibility_by_ref:
                errors.append(f"interaction {identifier}: unresolved {endpoint} {target}")
        missing = [
            ref for ref in interaction.get("decision_refs", []) if ref not in decision_by_id
        ]
        if missing:
            errors.append(f"interaction {identifier}: unresolved decision refs {missing}")

    for state in states:
        unknown_owners = [
            ref
            for ref in state["owner_refs"]
            if ref not in responsibility_by_ref and ref not in operation_by_ref
        ]
        if unknown_owners:
            errors.append(f"state {state['ref']}: unresolved owner refs {unknown_owners}")
        if state["authoritative"] and len(state["owner_refs"]) != 1:
            errors.append(
                f"state {state['ref']}: authoritative state requires exactly one owner"
            )
        if state["authoritative"] and state["owner_refs"] and state["owner_refs"][0] not in responsibility_by_ref:
            errors.append(
                f"state {state['ref']}: authoritative state owner must be a modeled responsibility"
            )
        if state["persistent"] and state["representation"] != "canonical":
            decision_ref = state.get("decision_ref")
            if not decision_ref:
                errors.append(
                    f"state {state['ref']}: persistent noncanonical representation requires decision_ref"
                )
            elif decision_ref not in decision_by_id:
                errors.append(
                    f"state {state['ref']}: unresolved representation decision {decision_ref}"
                )

    for boundary in boundaries:
        if boundary["selected"] and not boundary["excludes"]:
            errors.append(f"boundary {boundary['ref']}: selected boundary rules out nothing")
        missing = [
            ref for ref in boundary.get("interaction_refs", []) if ref not in interaction_by_ref
        ]
        if missing:
            errors.append(f"boundary {boundary['ref']}: unresolved interaction refs {missing}")

    for operation in operations:
        identifier = operation["ref"]
        if operation["owner_ref"] not in responsibility_by_ref:
            errors.append(
                f"operation {identifier}: unresolved owner_ref {operation['owner_ref']}"
            )
        if operation["scope"] == "routine":
            if not operation["work_may_scale_with"]:
                errors.append(f"operation {identifier}: routine operation lacks permitted scale drivers")
            if not operation["work_must_not_scale_with"]:
                errors.append(f"operation {identifier}: routine operation lacks excluded scale drivers")
            if not operation["materialization_forbidden"]:
                errors.append(f"operation {identifier}: routine operation lacks materialization exclusions")
        missing = [ref for ref in operation.get("decision_refs", []) if ref not in decision_by_id]
        if missing:
            errors.append(f"operation {identifier}: unresolved decision refs {missing}")
        for transient in operation.get("transient_state", []):
            if transient["lifetime"] != "operation":
                decision_ref = transient.get("decision_ref")
                if not decision_ref:
                    errors.append(
                        f"operation {identifier}: longer-lived transient {transient['ref']} requires decision_ref"
                    )
                elif decision_ref not in decision_by_id:
                    errors.append(
                        f"operation {identifier}: unresolved lifetime decision {decision_ref}"
                    )
    return errors


def execution_slice_errors(value: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    decisions = value.get("architecture", {}).get("decisions", [])
    for decision in decisions:
        if decision.get("impact") == "consequential" and decision.get("disposition") == "delegated":
            errors.append(
                f"decision {decision.get('id')}: consequential decisions cannot be delegated"
            )
        if decision.get("disposition") == "deferred":
            errors.append(
                f"decision {decision.get('id')}: a required execution decision cannot remain deferred"
            )
    if value.get("slice", {}).get("mode") == "autonomous":
        if value.get("approval", {}).get("status") not in {"accepted", "not-required"}:
            errors.append("autonomous slice requires accepted or not-required approval")
        if not value.get("delegation", {}).get("stop_conditions"):
            errors.append("autonomous slice requires stop conditions")
    wrong = str(value.get("outcome", {}).get("nearest_wrong_system", "")).strip()
    if wrong and not any(
        str(item.get("excludes", "")).strip() == wrong for item in value.get("evidence", [])
    ):
        errors.append("an evidence entry must explicitly exclude the nearest wrong system")
    return errors


def validate_artifact(kind: str, path: Path) -> list[str]:
    if kind not in SCHEMA_BY_KIND:
        raise MBSwEError(f"unknown artifact kind {kind!r}")
    try:
        value = load_artifact(path)
    except Exception as error:
        return [f"cannot load {path}: {error}"]
    errors = schema_errors(value, core_root() / "schemas" / SCHEMA_BY_KIND[kind])
    if errors or not isinstance(value, dict):
        return errors
    if kind == "model-index":
        errors.extend(semantic_model_index_errors(value))
    elif kind == "execution-slice":
        errors.extend(execution_slice_errors(value))
    return errors
