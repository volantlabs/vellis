"""Portable SysML v2 model-based engineering core."""

from __future__ import annotations

__all__ = ["__version__"]

__version__ = "0.5.0"
