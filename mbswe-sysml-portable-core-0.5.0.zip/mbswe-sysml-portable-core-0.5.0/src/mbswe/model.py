"""Model baseline, source inventory, and project-level policy helpers."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from .config import ProjectConfig
from .io import sha256_file, sha256_paths

PACKAGE = re.compile(r"\b(?:standard\s+library\s+|library\s+)?package\s+(?P<name>'[^']+'|[A-Za-z_]\w*)")
DECLARATION = re.compile(
    r"^\s*(?P<abstract>abstract\s+)?(?P<kind>part|item|attribute|action|state|calc|constraint|"
    r"requirement|analysis|verification|use\s+case|view|viewpoint|metadata|connection|interface|port|"
    r"occurrence)\s+(?P<definition>def\s+)?(?P<name>'[^']+'|[A-Za-z_]\w*)",
    re.MULTILINE,
)
DOC = re.compile(r"doc\s*/\*(?P<body>.*?)\*/", re.DOTALL)


def model_digest(project: ProjectConfig) -> str:
    return "sha256:" + sha256_paths(project.root, project.model_files)


def source_inventory(project: ProjectConfig) -> dict[str, Any]:
    files: list[dict[str, Any]] = []
    packages: list[dict[str, Any]] = []
    declarations: list[dict[str, Any]] = []
    for path in project.model_files:
        source = path.read_text(encoding="utf-8")
        relative = path.relative_to(project.root).as_posix()
        files.append(
            {
                "path": relative,
                "sha256": sha256_file(path),
                "lines": len(source.splitlines()),
            }
        )
        package_names = [match.group("name") for match in PACKAGE.finditer(source)]
        for name in package_names:
            packages.append({"name": name, "path": relative})
        for match in DECLARATION.finditer(source):
            line = source.count("\n", 0, match.start()) + 1
            declarations.append(
                {
                    "kind": " ".join(match.group("kind").split()),
                    "name": match.group("name"),
                    "definition": bool(match.group("definition")),
                    "abstract": bool(match.group("abstract")),
                    "path": relative,
                    "line": line,
                }
            )
    return {
        "schema_version": "1.0",
        "project": project.project_id,
        "model_digest": model_digest(project),
        "language_lane": project.lane,
        "files": files,
        "packages": packages,
        "declarations": declarations,
        "warning": (
            "This is a lexical source inventory, not a semantic model index. "
            "Use the official validator and a model adapter for semantic claims."
        ),
    }
