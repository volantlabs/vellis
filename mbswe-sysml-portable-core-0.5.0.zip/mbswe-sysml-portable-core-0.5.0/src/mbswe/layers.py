"""Layer/profile resolution and independently bootstrappable subset export."""

from __future__ import annotations

import hashlib
import shutil
import tempfile
from pathlib import Path
from typing import Any

import yaml

from .config import load_layers
from .errors import MBSwEError
from .manifests import sync_provider_manifests
from .paths import core_root

RUNTIME_ALWAYS = {
    "src",
    "pyproject.toml",
    "bootstrap",
    "bootstrap.ps1",
    "justfile",
    "package.yaml",
    "layers.yaml",
    "skill-catalog.yaml",
    "README.md",
    "LICENSE",
    ".gitignore",
    ".claude-plugin",
    ".codex-plugin",
    ".github",
    "CONTRIBUTING.md",
    "SECURITY.md",
    "VALIDATION_RESULTS.txt",
}
BASE_SCHEMAS = {
    "package.schema.json",
    "layer-catalog.schema.json",
    "skill-catalog.schema.json",
    "resource-catalog.schema.json",
    "eval-suite.schema.json",
}
BASE_TEMPLATES = {
    "AGENTS.mbswe-snippet.md",
    "CLAUDE.mbswe-snippet.md",
}


def profile_record(profile: str) -> tuple[list[str], list[str]]:
    manifest = load_layers()
    profiles = manifest.get("profiles", {})
    if profile not in profiles:
        raise MBSwEError(
            f"unknown profile {profile!r}; available: {', '.join(sorted(profiles))}"
        )
    record = profiles[profile]
    return list(record.get("layers", [])), list(record.get("extras", []))


def _records(profile: str) -> list[dict[str, Any]]:
    manifest = load_layers()
    layer_names, extras = profile_record(profile)
    return [
        *(manifest["layers"][name] for name in layer_names),
        *(manifest["extras"][name] for name in extras),
    ]


def selected_skills(profile: str) -> list[str]:
    values = [item for record in _records(profile) for item in record.get("skills", [])]
    return list(dict.fromkeys(str(item) for item in values))


def selected_schemas(profile: str) -> list[str]:
    values = [item for record in _records(profile) for item in record.get("schemas", [])]
    return list(dict.fromkeys(str(item) for item in values))


def selected_templates(profile: str) -> list[str]:
    values = [item for record in _records(profile) for item in record.get("templates", [])]
    return list(dict.fromkeys(str(item) for item in values))


def includes_layer(profile: str, layer: str) -> bool:
    layers, _ = profile_record(profile)
    return layer in layers


EXPORT_IGNORE = shutil.ignore_patterns(
    ".git",
    ".venv",
    ".pytest_cache",
    "__pycache__",
    "*.pyc",
    "*.pyo",
    "*.egg-info",
    "build",
    "dist",
)


def _copy(source: Path, destination: Path) -> None:
    if source.is_dir():
        shutil.copytree(source, destination, ignore=EXPORT_IGNORE)
    else:
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)


def _filtered_layers(profile: str) -> dict[str, Any]:
    full = load_layers()
    layer_names, extra_names = profile_record(profile)
    filtered_profiles = {
        name: record
        for name, record in full["profiles"].items()
        if set(record["layers"]).issubset(layer_names)
        and set(record["extras"]).issubset(extra_names)
    }
    return {
        "schema_version": "2.0",
        "layers": {name: full["layers"][name] for name in layer_names},
        "extras": {name: full["extras"][name] for name in extra_names},
        "profiles": filtered_profiles,
    }




def _write_export_manifest(root: Path) -> Path:
    destination = root / "MANIFEST.sha256"
    lines: list[str] = []
    for path in sorted(item for item in root.rglob("*") if item.is_file()):
        if path == destination or any(
            part in {".git", ".venv", "__pycache__", ".pytest_cache"}
            for part in path.parts
        ):
            continue
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        lines.append(f"{digest}  {path.relative_to(root).as_posix()}")
    destination.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return destination


def export_profile(profile: str, destination: Path, *, force: bool = False) -> Path:
    """Create a standalone checkout containing exactly one cumulative profile."""

    root = core_root()
    profile_record(profile)
    destination = destination.expanduser().resolve()
    if destination.exists():
        if not force:
            raise MBSwEError(f"export destination already exists: {destination}")
        shutil.rmtree(destination)
    destination.mkdir(parents=True)

    for name in sorted(RUNTIME_ALWAYS):
        source = root / name
        if source.exists():
            _copy(source, destination / name)
    _copy(root / "resources", destination / "resources")

    chosen_skills = selected_skills(profile)
    skill_root = destination / "skills"
    skill_root.mkdir()
    for skill in chosen_skills:
        _copy(root / "skills" / skill, skill_root / skill)

    schemas = set(selected_schemas(profile)) | BASE_SCHEMAS
    schema_root = destination / "schemas"
    schema_root.mkdir()
    for schema in sorted(schemas):
        source = root / "schemas" / schema
        if source.is_file():
            shutil.copy2(source, schema_root / schema)

    templates = set(selected_templates(profile)) | BASE_TEMPLATES
    template_root = destination / "templates"
    template_root.mkdir()
    for template in sorted(templates):
        source = root / "templates" / template
        if source.is_file():
            shutil.copy2(source, template_root / template)

    if includes_layer(profile, "modeling"):
        _copy(root / "model-libraries", destination / "model-libraries")

    for directory in ("tests", "docs"):
        source = root / directory
        if source.is_dir():
            _copy(source, destination / directory)
    if includes_layer(profile, "realization"):
        source = root / "examples"
        if source.is_dir():
            _copy(source, destination / "examples")

    # Keep only evaluations belonging to installed skills.
    catalog = yaml.safe_load((root / "skill-catalog.yaml").read_text(encoding="utf-8"))
    selected_entries = [entry for entry in catalog["skills"] if entry["id"] in chosen_skills]
    eval_root = destination / "evals"
    eval_root.mkdir()
    for entry in selected_entries:
        source = root / entry["eval"]
        shutil.copy2(source, eval_root / source.name)
    if (root / "evals" / "README.md").is_file():
        shutil.copy2(root / "evals" / "README.md", eval_root / "README.md")
    (destination / "skill-catalog.yaml").write_text(
        yaml.safe_dump({"schema_version": "2.0", "skills": selected_entries}, sort_keys=False),
        encoding="utf-8",
    )
    (destination / "layers.yaml").write_text(
        yaml.safe_dump(_filtered_layers(profile), sort_keys=False, width=110), encoding="utf-8"
    )

    package = yaml.safe_load((root / "package.yaml").read_text(encoding="utf-8"))
    if profile != "full":
        package["name"] = f"mbswe-portable-core-{profile}"
        package["interface"]["display_name"] += f" — {profile.title()} Profile"
        package["description"] = (
            f"Standalone {profile} profile exported from the MBSwE portable core."
        )
    (destination / "package.yaml").write_text(
        yaml.safe_dump(package, sort_keys=False, width=110), encoding="utf-8"
    )
    (destination / "EXPORTED_PROFILE").write_text(profile + "\n", encoding="utf-8")
    profile_layers, profile_extras = profile_record(profile)
    (destination / "PROFILE.md").write_text(
        f"# Exported {profile} profile\n\n"
        "This is an independently bootstrappable cumulative export of the MBSwE portable core.\n\n"
        f"- Layers: {', '.join(profile_layers)}\n"
        f"- Extras: {', '.join(profile_extras) if profile_extras else 'none'}\n"
        f"- Skills: {', '.join(chosen_skills)}\n\n"
        "Run `./bootstrap`, then `mbswe project init <target>`. The CLI defaults to the highest "
        "profile available in this export.\n",
        encoding="utf-8",
    )
    sync_provider_manifests(destination)
    _write_export_manifest(destination)
    return destination


def archive_profile(profile: str, destination: Path, *, force: bool = False) -> Path:
    """Create a ZIP containing one independently bootstrappable profile repository."""

    destination = destination.expanduser().resolve()
    if destination.suffix.lower() != ".zip":
        destination = destination.with_suffix(".zip")
    if destination.exists():
        if not force:
            raise MBSwEError(f"archive already exists: {destination}")
        destination.unlink()
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="mbswe-export-") as temporary:
        repo = Path(temporary) / f"mbswe-portable-core-{profile}"
        export_profile(profile, repo)
        base = destination.with_suffix("")
        generated = Path(
            shutil.make_archive(str(base), "zip", root_dir=repo.parent, base_dir=repo.name)
        )
        if generated != destination:
            generated.replace(destination)
    return destination
