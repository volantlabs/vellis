"""Install and synchronize the portable model-engineering experience in repositories."""

from __future__ import annotations

import hashlib
import os
import re
import shutil
from pathlib import Path
from typing import Any

from packaging.specifiers import SpecifierSet
from packaging.version import Version

from . import __version__
from .artifacts import validate_artifact
from .config import load_project
from .errors import MBSwEError
from .io import dump_yaml, load_yaml, sha256_file
from .layers import export_profile, includes_layer, profile_record, selected_skills
from .paths import core_root
from .resources import verify_project_lock

AGENT_START = "<!-- mbswe:start -->"
AGENT_END = "<!-- mbswe:end -->"
GITIGNORE_START = "# mbswe:start"
GITIGNORE_END = "# mbswe:end"
MANAGED_MARKER = ".mbswe-managed"


def _slug(value: str) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9._-]+", "-", value.strip()).strip("-").lower()
    return cleaned or "project"


def _write_marker_block(path: Path, start: str, end: str, body: str) -> None:
    block = f"{start}\n{body.rstrip()}\n{end}\n"
    if path.exists():
        source = path.read_text(encoding="utf-8")
        if start in source and end in source:
            before, rest = source.split(start, 1)
            _, after = rest.split(end, 1)
            source = before.rstrip() + "\n\n" + block + after.lstrip("\n")
        else:
            source = source.rstrip() + "\n\n" + block
    else:
        source = block
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(source, encoding="utf-8")


def _remove_path(path: Path) -> None:
    if path.is_dir() and not path.is_symlink():
        shutil.rmtree(path)
    elif path.exists() or path.is_symlink():
        path.unlink()


def _tree_digest(root: Path, *, ignore_managed_marker: bool = True) -> str:
    digest = hashlib.sha256()
    for path in sorted(item for item in root.rglob("*") if item.is_file()):
        if ignore_managed_marker and path.name == MANAGED_MARKER:
            continue
        digest.update(path.relative_to(root).as_posix().encode("utf-8"))
        digest.update(b"\0")
        digest.update(path.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest()


def _is_managed_directory(path: Path) -> bool:
    return path.is_dir() and (path / MANAGED_MARKER).is_file()


def _copy_managed_directory(source: Path, target: Path, *, kind: str) -> None:
    if target.exists() or target.is_symlink():
        if not _is_managed_directory(target):
            raise MBSwEError(
                f"refusing to replace project-owned path with managed {kind}: {target}"
            )
        _remove_path(target)
    shutil.copytree(source, target)
    (target / MANAGED_MARKER).write_text(
        f"managed by mbswe {__version__}; kind={kind}\n", encoding="utf-8"
    )


def _is_managed_provider_exposure(path: Path, canonical: Path) -> bool:
    if path.is_symlink():
        try:
            path.resolve().relative_to(canonical.resolve())
            return True
        except (OSError, ValueError):
            return False
    return _is_managed_directory(path)


def _relative_symlink(source: Path, target: Path, canonical: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() or target.is_symlink():
        if not _is_managed_provider_exposure(target, canonical):
            raise MBSwEError(
                f"refusing to replace project-owned provider skill exposure: {target}"
            )
        _remove_path(target)
    relative = os.path.relpath(source, target.parent)
    try:
        target.symlink_to(relative, target_is_directory=True)
    except OSError:
        shutil.copytree(source, target)


def _all_core_skill_names() -> set[str]:
    return {
        path.name
        for path in (core_root() / "skills").iterdir()
        if path.is_dir() and (path / "SKILL.md").is_file()
    }




def _preflight_managed_paths(
    target: Path, profile: str, providers: list[str], install_mode: str
) -> None:
    """Reject namespace collisions before a synchronization starts mutating files."""

    canonical = target / ".agents" / "skills"
    selected = selected_skills(profile)
    for skill in selected:
        path = canonical / skill
        if (path.exists() or path.is_symlink()) and not _is_managed_directory(path):
            raise MBSwEError(
                f"refusing to replace project-owned path with managed portable-skill: {path}"
            )

    if includes_layer(profile, "modeling"):
        vendor = target / "model" / "vendor" / "mbswe"
        if (vendor.exists() or vendor.is_symlink()) and not _is_managed_directory(vendor):
            raise MBSwEError(
                f"refusing to replace project-owned path with managed model-library: {vendor}"
            )

    if "claude" in providers:
        claude = target / ".claude" / "skills"
        for skill in selected:
            path = claude / skill
            if (path.exists() or path.is_symlink()) and not _is_managed_provider_exposure(
                path, canonical
            ):
                raise MBSwEError(
                    f"refusing to replace project-owned provider skill exposure: {path}"
                )

    if install_mode == "vendored":
        vendored = target / ".mbswe" / "core"
        if (vendored.exists() or vendored.is_symlink()) and not (
            vendored / MANAGED_MARKER
        ).is_file():
            raise MBSwEError(f"refusing to replace project-owned vendored core: {vendored}")


def expose_providers(target: Path, providers: list[str], skills: list[str]) -> None:
    """Expose the canonical project skills without creating another authority copy.

    Codex discovers repository skills directly from ``.agents/skills``. Claude Code
    receives relative symlinks (or copies on filesystems without symlink support).
    """

    canonical = target / ".agents" / "skills"
    claude_root = target / ".claude" / "skills"
    all_core = _all_core_skill_names()
    if "claude" in providers:
        for skill in skills:
            _relative_symlink(canonical / skill, claude_root / skill, canonical)
    if claude_root.is_dir():
        for path in claude_root.iterdir():
            if path.name in all_core and ("claude" not in providers or path.name not in skills):
                if _is_managed_provider_exposure(path, canonical):
                    _remove_path(path)


def _starter_model(project_id: str) -> str:
    package = "".join(part.capitalize() for part in re.split(r"[-_.]+", project_id)) or "Project"
    return f"""package {package}System {{
    doc /*
     * Start with the system of interest, stakeholders, environment, observable
     * outcomes, and the first consequential decision. Refine only where the
     * project intends to govern a non-equivalent realization.
     */
}}
"""


def _manifest_for(
    project_id: str, profile: str, lane: str, providers: list[str], install_mode: str
) -> dict[str, Any]:
    template = load_yaml(core_root() / "templates" / "mbswe.project.yaml")
    template["project"]["id"] = project_id
    template["core"]["profile"] = profile
    template["core"]["install_mode"] = install_mode
    template["resources"]["lane"] = lane
    template["providers"]["expose"] = providers
    template["autonomy"]["require_execution_slice"] = includes_layer(
        profile, "realization"
    )
    if profile == "reference":
        template["model"]["entries"] = [{"path": "model/10-system.sysml", "role": "system"}]
        template["model"]["policy"] = None
    return template


def _copy_resource_lock(target: Path, lane: str) -> Path:
    source = core_root() / "resources" / "locks" / f"{lane}.json"
    if not source.is_file():
        raise MBSwEError(f"core has no locked resource lane {lane!r}")
    destination = target / "model" / "config" / "resource-lock.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    return destination


def _sync_skills(target: Path, profile: str, providers: list[str]) -> None:
    skills = selected_skills(profile)
    canonical = target / ".agents" / "skills"
    canonical.mkdir(parents=True, exist_ok=True)
    all_core = _all_core_skill_names()
    for path in list(canonical.iterdir()):
        if (
            path.name in all_core
            and path.name not in skills
            and (path / MANAGED_MARKER).is_file()
        ):
            _remove_path(path)
    for skill in skills:
        _copy_managed_directory(
            core_root() / "skills" / skill,
            canonical / skill,
            kind="portable-skill",
        )
    expose_providers(target, providers, skills)


def _sync_modeling_library(target: Path, profile: str) -> None:
    vendor = target / "model" / "vendor" / "mbswe"
    if includes_layer(profile, "modeling"):
        _copy_managed_directory(
            core_root() / "model-libraries" / "mbswe", vendor, kind="model-library"
        )
        policy = target / ".mbswe" / "model-policy.yaml"
        if not policy.exists():
            policy.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(core_root() / "templates" / "model-policy.yaml", policy)
    elif (vendor / MANAGED_MARKER).is_file():
        _remove_path(vendor)


def _sync_vendored_core(target: Path, profile: str, install_mode: str) -> None:
    core_target = target / ".mbswe" / "core"
    wrapper = target / ".mbswe" / "mbswe"
    wrapper_ps1 = target / ".mbswe" / "mbswe.ps1"
    if install_mode != "vendored":
        if (core_target / MANAGED_MARKER).is_file():
            _remove_path(core_target)
        for path in (wrapper, wrapper_ps1):
            if path.is_file() and "managed mbswe vendored wrapper" in path.read_text(
                encoding="utf-8", errors="ignore"
            ):
                path.unlink()
        return
    if core_target.exists() and not (core_target / MANAGED_MARKER).is_file():
        raise MBSwEError(f"refusing to replace project-owned vendored core: {core_target}")
    export_profile(profile, core_target, force=True)
    (core_target / MANAGED_MARKER).write_text(
        f"managed by mbswe {__version__}; kind=vendored-core\n", encoding="utf-8"
    )
    wrapper.parent.mkdir(parents=True, exist_ok=True)
    wrapper.write_text(
        "#!/bin/sh\n# managed mbswe vendored wrapper\nset -eu\n"
        "ROOT=$(CDPATH= cd -- \"$(dirname -- \"$0\")\" && pwd)\n"
        "if [ ! -x \"$ROOT/core/.venv/bin/mbswe\" ]; then\n"
        "  \"$ROOT/core/bootstrap\" >/dev/null\n"
        "fi\n"
        "cd \"$ROOT/..\"\n"
        "exec \"$ROOT/core/.venv/bin/mbswe\" \"$@\"\n",
        encoding="utf-8",
    )
    wrapper.chmod(0o755)
    wrapper_ps1.write_text(
        '# managed mbswe vendored wrapper\n'
        '$ErrorActionPreference = "Stop"\n'
        '$Root = Split-Path -Parent $MyInvocation.MyCommand.Path\n'
        '$Cli = Join-Path $Root "core/.venv/Scripts/mbswe.exe"\n'
        'if (-not (Test-Path $Cli)) { & (Join-Path $Root "core/bootstrap.ps1") | Out-Null }\n'
        'Push-Location (Join-Path $Root "..")\n'
        'try { & $Cli @args; exit $LASTEXITCODE } finally { Pop-Location }\n',
        encoding="utf-8",
    )


def _sync_guidance(target: Path) -> None:
    agent_body = (core_root() / "templates" / "AGENTS.mbswe-snippet.md").read_text(
        encoding="utf-8"
    )
    _write_marker_block(target / "AGENTS.md", AGENT_START, AGENT_END, agent_body)
    ignore_body = ".mbswe/venv/\n.mbswe/cache/\n"
    _write_marker_block(target / ".gitignore", GITIGNORE_START, GITIGNORE_END, ignore_body)


def sync_project(target: Path) -> Path:
    """Refresh only portable-core-managed assets; never alter project model authority."""

    project = load_project(target)
    profile_record(project.profile)
    providers = [str(item) for item in project.raw["providers"].get("expose", [])]
    install_mode = str(project.raw["core"].get("install_mode", "external"))
    _preflight_managed_paths(project.root, project.profile, providers, install_mode)
    _sync_skills(project.root, project.profile, providers)
    _sync_modeling_library(project.root, project.profile)
    _sync_vendored_core(project.root, project.profile, install_mode)
    _sync_guidance(project.root)
    for path in project.raw["artifacts"].values():
        (project.root / str(path)).mkdir(parents=True, exist_ok=True)
    return project.root


def init_project(
    target: Path,
    *,
    profile: str = "full",
    lane: str = "stable-2.0",
    project_id: str | None = None,
    providers: list[str] | None = None,
    install_mode: str = "external",
    force: bool = False,
) -> Path:
    """Initialize a project without overwriting existing product source or model files."""

    profile_record(profile)
    if not (core_root() / "resources" / "locks" / f"{lane}.json").is_file():
        raise MBSwEError(f"unknown resource lane {lane!r}")
    target = target.expanduser().resolve()
    target.mkdir(parents=True, exist_ok=True)
    providers = providers or ["claude", "codex"]
    unknown = set(providers) - {"claude", "codex"}
    if unknown:
        raise MBSwEError(f"unsupported provider exposure: {sorted(unknown)}")
    project_id = _slug(project_id or target.name)
    _preflight_managed_paths(target, profile, providers, install_mode)

    manifest_path = target / "mbswe.yaml"
    if manifest_path.exists() and not force:
        raise MBSwEError(
            f"{manifest_path} already exists; use 'mbswe project sync' for an existing integration"
        )
    manifest = _manifest_for(project_id, profile, lane, providers, install_mode)
    dump_yaml(manifest_path, manifest)
    _copy_resource_lock(target, lane)

    model_root = target / "model"
    model_root.mkdir(exist_ok=True)
    starter = model_root / "10-system.sysml"
    if not starter.exists():
        starter.write_text(_starter_model(project_id), encoding="utf-8")

    sync_project(target)
    return target


def upgrade_resources(target: Path, lane: str) -> Path:
    """Deliberately change the project's official resource lane and lock."""

    profile_record(load_project(target).profile)
    if not (core_root() / "resources" / "locks" / f"{lane}.json").is_file():
        raise MBSwEError(f"unknown resource lane {lane!r}")
    project = load_project(target)
    project.raw["resources"]["lane"] = lane
    dump_yaml(project.root / "mbswe.yaml", project.raw)
    return _copy_resource_lock(project.root, lane)


def project_errors(target: Path) -> list[str]:
    target = target.expanduser().resolve()
    errors: list[str] = []
    manifest = target / "mbswe.yaml"
    if not manifest.is_file():
        return [f"{manifest}: missing project manifest"]
    errors.extend(validate_artifact("project", manifest))
    if errors:
        return errors
    try:
        project = load_project(target)
    except MBSwEError as error:
        return [str(error)]
    try:
        requirement = SpecifierSet(str(project.raw["core"]["required_version"]))
        if Version(__version__) not in requirement:
            errors.append(
                f"portable core {__version__} does not satisfy {project.raw['core']['required_version']}"
            )
    except Exception as error:
        errors.append(f"invalid core.required_version: {error}")
    try:
        project.model_files
    except MBSwEError as error:
        errors.append(str(error))
    try:
        lock_errors = validate_artifact("resource-lock", project.resource_lock_path)
        errors.extend(f"{project.resource_lock_path}: {item}" for item in lock_errors)
        if not lock_errors:
            verify_project_lock(project)
    except MBSwEError as error:
        errors.append(str(error))

    status = project_status(target)
    if status["missing_skills"]:
        errors.append(f"missing managed skills: {status['missing_skills']}")
    for skill in selected_skills(project.profile):
        source_skill = core_root() / "skills" / skill
        target_skill = project.root / ".agents" / "skills" / skill
        if not target_skill.is_dir():
            continue
        if not (target_skill / MANAGED_MARKER).is_file():
            errors.append(f"portable skill path is not marked as managed: {target_skill}")
        elif _tree_digest(source_skill) != _tree_digest(target_skill):
            errors.append(f"managed portable skill is stale: {target_skill}")
    providers = [str(item) for item in project.raw["providers"].get("expose", [])]
    if "claude" in providers:
        canonical = project.root / ".agents" / "skills"
        for skill in selected_skills(project.profile):
            exposure = project.root / ".claude" / "skills" / skill
            if not (exposure.exists() or exposure.is_symlink()):
                errors.append(f"missing Claude skill exposure: {exposure}")
            elif not _is_managed_provider_exposure(exposure, canonical):
                errors.append(f"Claude skill exposure is not managed by the core: {exposure}")
            elif exposure.is_dir() and not exposure.is_symlink():
                if _tree_digest(canonical / skill) != _tree_digest(exposure):
                    errors.append(f"copied Claude skill exposure is stale: {exposure}")
    if str(project.raw["core"].get("install_mode", "external")) == "vendored":
        vendored = project.root / ".mbswe" / "core"
        if not (vendored / MANAGED_MARKER).is_file():
            errors.append(f"missing or unmanaged vendored core: {vendored}")
        if not (project.root / ".mbswe" / "mbswe").is_file():
            errors.append("missing vendored shell wrapper: .mbswe/mbswe")
        if not (project.root / ".mbswe" / "mbswe.ps1").is_file():
            errors.append("missing vendored PowerShell wrapper: .mbswe/mbswe.ps1")
    if includes_layer(project.profile, "modeling"):
        source = core_root() / "model-libraries" / "mbswe"
        target_library = project.root / "model" / "vendor" / "mbswe"
        for source_file in source.glob("*.sysml"):
            target_file = target_library / source_file.name
            if not target_file.is_file():
                errors.append(f"missing managed model library file: {target_file}")
            elif sha256_file(target_file) != sha256_file(source_file):
                errors.append(f"managed model library file is stale: {target_file}")
    return errors


def project_status(target: Path) -> dict[str, Any]:
    target = target.expanduser().resolve()
    manifest = load_yaml(target / "mbswe.yaml")
    profile = str(manifest["core"]["profile"])
    expected = set(selected_skills(profile))
    actual_root = target / ".agents" / "skills"
    actual = {
        path.name
        for path in actual_root.iterdir()
        if path.is_dir() and (path / "SKILL.md").is_file()
    } if actual_root.is_dir() else set()
    return {
        "project": manifest["project"]["id"],
        "profile": profile,
        "lane": manifest["resources"]["lane"],
        "core_required": manifest["core"]["required_version"],
        "core_current": __version__,
        "expected_skills": sorted(expected),
        "missing_skills": sorted(expected - actual),
        "extra_skills": sorted(actual - expected),
        "model_entries": manifest["model"]["entries"],
    }
