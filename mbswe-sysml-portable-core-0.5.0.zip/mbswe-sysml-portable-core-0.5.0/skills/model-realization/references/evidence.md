# Realization evidence

Evidence must fail when the nearest plausible wrong implementation is present.

## Evidence classes

- **behavioral** — observable nominal and alternate/failure outcomes;
- **non-effect** — state, outputs, or interactions that must remain unchanged;
- **architectural** — ownership, dependency, interface, allocation, or lifecycle conformance;
- **resource** — work, memory, materialization, concurrency, timing, or capacity;
- **integration** — external boundary and target-platform behavior;
- **recovery** — rollback, restart, retry, response loss, or restoration semantics;
- **inspection** — static or model-to-code mapping evidence where execution is not appropriate.

## Resource-sensitive evidence

For a supposedly local operation, vary unrelated population while holding the semantic change fixed.
Observe the metric closest to the architecture claim:

- identities or rows loaded;
- validation subjects visited;
- temporary entries retained;
- locks or coordination domains;
- peak materialization;
- external calls;
- elapsed work when a stable measurement is meaningful.

Do not invent numerical performance thresholds without representative evidence. A relational
independence or bounded-growth assertion can still be decisive.

## Completion

A slice is complete when every packet evidence entry names:

- the wrong behavior it excludes;
- a reproducible command, test, analysis, or inspection;
- the exact checkpoint on which it passed.

Passing general tests is not evidence that an architectural obligation was exercised.
