# Decision-complete slices

The execution packet is a generated navigation and control artifact, not authority.

## Readiness

A packet is valid for autonomous execution only when it identifies:

- exact accepted model and implementation baselines;
- observable outcome and nearest wrong system;
- complete qualified authority closure;
- owned and referenced state;
- participating responsibilities and allowed interactions;
- consequential decisions and their dispositions;
- delegated local choices;
- forbidden mechanisms and stop conditions;
- permitted and excluded scale drivers;
- permitted and forbidden materialization;
- expected source/evidence surface;
- discriminating evidence;
- human acceptance of changed meaning or selected architecture.

A schema-valid packet may still be semantically inadequate. Regenerate it after any relevant model
change.

## Model-gap report

When execution requires an undecided consequential choice, return:

```text
classification: model-gap | architecture-decision-gap
authority:
smallest failing scenario:
choice required:
plausible alternatives:
observable or architectural consequences:
work deliberately not performed:
```

Do not propose a large redesign unless asked. Preserve the smallest decision frame needed for the
modeling skill.

## Packet lifetime

Invalidate the packet when:

- the accepted model baseline changes;
- a cited authority element changes meaning;
- the implementation checkpoint or selected dependency changes materially;
- evidence no longer discriminates the same wrong system;
- an external platform constraint changes the selected realization.
