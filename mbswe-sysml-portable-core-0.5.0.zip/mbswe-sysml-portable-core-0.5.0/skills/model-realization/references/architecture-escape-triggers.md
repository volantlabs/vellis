# Architecture-escape triggers

Stop before making any of these changes unless the execution packet explicitly governs them:

- new mutable or authoritative state;
- new state owner or duplicate complete representation;
- new persistent relation, file format, event stream, or schema;
- new cache, queue, worker, scheduler, registry, retry subsystem, or background lifecycle;
- new public or cross-component interface;
- changed dependency direction or boundary bypass;
- changed transaction, locking, synchronization, or failure boundary;
- changed identity, equality, absence, or ordering semantics;
- complete-state copy, full scan, global lock, global quiescence, or unbounded intermediate;
- work, memory, validation, or coordination scaling with an excluded population;
- new deployment unit or external dependency;
- touched responsibility set materially larger than the packet predicts;
- an abstraction introduced mainly to reconcile two choices created during the same slice.

These are not automatically bad designs. They are evidence that the task has crossed from local
realization into consequential architecture.

## Rollback signals

Roll back to the last clean semantic checkpoint when:

- the second correction targets the same root premise;
- wrappers and adapters exist mainly to preserve a newly introduced choice;
- the executor repeatedly extends the touch set;
- tests pass only after adding exceptions around the selected architecture;
- the implementation becomes harder to explain than the model-derived causal path;
- a fresh review cannot identify one authoritative owner or transaction path.
