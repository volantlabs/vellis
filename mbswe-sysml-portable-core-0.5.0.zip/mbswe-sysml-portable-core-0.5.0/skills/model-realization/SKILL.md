---
name: model-realization
description: Produce a bounded real-world realization from an accepted, decision-complete SysML v2 execution slice. Use for software, tests, schemas, deployment assets, simulations, procedures, or other implementation artifacts. Choose only delegated local details and stop before introducing consequential unmodeled architecture.
---

# Model Realization

Realize accepted authority; do not design a different system during execution.

## Required inputs

- `mbswe.yaml` and exact resource lock;
- accepted model baseline named by the execution slice;
- validated decision-complete execution slice;
- named implementation and evidence surface;
- clean, recoverable implementation checkpoint.

Reject stale or unresolved inputs.

## Workflow

1. Resolve every authority reference and verify the model/resource/implementation baselines.
2. Recheck decision completeness. A consequential delegated or required deferred decision is a stop,
   not an implementation assumption.
3. Read only the governed responsibility closure and affected realization surface.
4. Plan one end-to-end outcome, tying each step to authority, expected artifact changes, evidence, and
   an exit condition.
5. Implement only local choices permitted by the slice.
6. Continuously run nominal, failure, boundary, nearest-wrong, architecture, and resource-sensitive
   evidence named by the slice.
7. Apply [architecture escape triggers](references/architecture-escape-triggers.md) before adding or
   changing a consequential mechanism.
8. Checkpoint a clean slice or roll back. When new complexity mainly compensates for an earlier
   choice, return to the last semantic checkpoint.
9. Emit a realization result and structured model feedback when blocked.

## Prohibited in realization mode

Do not change accepted model authority; add or move authoritative state; introduce a new subsystem,
interface, persistent representation, schema, transaction, synchronization domain, queue, cache,
worker, registry, lifecycle, global operation, or excluded scale dependency; or weaken evidence to
fit the implementation.

A local choice must remain inside one governed responsibility, be reversible without neighboring or
persistent change, be visible in a small diff, and be testable at the selected boundary.

Read [decision-complete slices](references/decision-complete-slices.md) and
[evidence](references/evidence.md) before unattended execution.
