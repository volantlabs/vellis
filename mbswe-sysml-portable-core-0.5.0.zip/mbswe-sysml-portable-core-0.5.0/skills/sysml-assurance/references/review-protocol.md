# Review protocol

## Semantic closure

- Can the model decide nominal, alternate/failed, boundary, and nearest-wrong cases?
- Are promised non-effects governed?
- Are all state and effects traceable to an owner and behavior?

## Native-semantic strength

- What remains if documentation bodies are removed?
- Are ownership, references, multiplicity, decomposition, interaction, ordering, state, allocation,
  and satisfaction represented natively where they matter?
- Does every prose-backed critical claim have a waiver and discriminating evidence?
- Does a rationale incorrectly carry authority?

## Decision completeness

- Are any consequential choices delegated?
- Does the slice require a deferred choice?
- Could an executor introduce new state, persistence, concurrency, materialization, or interfaces
  while claiming conformance?
- Is every forbidden mechanism tied to a positive architecture commitment or a verified boundary?

## Architecture conformance

- Does implementation preserve modeled ownership and boundary crossing?
- Are interactions realized through selected interfaces?
- Does any component span two modeled responsibilities or acquire independent authority accidentally?
- Are derived representations still derived?
- Do model-to-code mappings remain many-to-many only inside permitted boundaries?

## Proportionality

- What may work, memory, validation, and coordination scale with?
- What unrelated state is touched?
- Does a local semantic operation use a global mechanism?
- Does transient state survive beyond its modeled occurrence?

## Evidence

- Would the evidence fail for the nearest wrong implementation?
- Does it inspect the actual property claimed rather than a convenient proxy?
- Are acceptance and rejection/non-effect paths covered?
- Is a parser, hash, test count, or green gate being used to claim more than it proves?

## Cognitive tractability and subtraction

- Can the causal path be explained with the model's concepts?
- Which abstractions exist only to reconcile other abstractions?
- What could be removed without losing accepted meaning or evidence?
- Has complexity been redistributed to more files rather than reduced?

## Finding format

```yaml
classification:
severity:
authority:
artifact:
reproduction:
observed:
expected:
nearest_wrong_system:
root_cause:
recommended_route:
work_not_authorized:
```
