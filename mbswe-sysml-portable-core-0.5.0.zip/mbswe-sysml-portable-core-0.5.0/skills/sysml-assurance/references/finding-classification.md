# Finding classification

Classify every finding before changing model or source.

| Classification | Meaning | Route |
| --- | --- | --- |
| Language question | SysML/KerML syntax or semantics is uncertain | `sysml-reference` |
| Model gap | Accepted authority cannot decide a required system outcome | `sysml-modeling` |
| Architecture-decision gap | A consequential realization choice is required but not governed | `sysml-modeling` |
| Model defect | Accepted model expresses contradictory or unacceptable meaning | `sysml-modeling` with human acceptance |
| Implementation defect | Source contradicts sufficient accepted authority | `model-realization` |
| Evidence defect | Claimed evidence does not discriminate the governed wrong system | evidence correction |
| Target-platform defect | Realization violates a selected platform contract without changing system meaning | `model-realization` |
| Feasibility consequence | Measured platform/resource reality changes an observable promise or selected boundary | model decision |
| Stale baseline | Compared artifacts refer to different accepted states | refresh; no semantic conclusion |
| Process/tooling defect | Workflow or tooling is wrong but product authority is sufficient | project tooling |
| Out of scope | Reproducible issue is outside the accepted slice | record separately; do not widen work |

A class, module, table, lock, buffer, or framework preference is not itself a model gap. Translate it
into the unresolved ownership, behavior, interaction, lifecycle, resource, failure, or compatibility
distinction first.
