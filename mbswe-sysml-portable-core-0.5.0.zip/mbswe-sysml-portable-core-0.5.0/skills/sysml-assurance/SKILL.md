---
name: sysml-assurance
description: Independently review a SysML v2 model, generated model slice, or realization for semantic adequacy, native-semantic strength, decision completeness, architecture fitness, proportionality, conformance, and evidence quality. Use fresh context and report findings without repairing the artifact under review.
---

# SysML Assurance

Review accepted authority and artifacts independently of the trajectory that produced them.

## Inputs

Use the smallest complete review set:

- project binding and exact resource lane;
- accepted model baseline and affected semantic closure;
- model diff, generated packet, or realization diff;
- focused evidence and relevant project gates.

Do not load planner rhetoric, earlier reviewer conclusions, or implementation narration unless the
review concerns them.

## Lenses

1. **Semantic closure:** can nominal, failed, boundary, and invalid instances be decided?
2. **Native-semantic strength:** if documentation disappeared, would ownership, behavior,
   interactions, state, and selected architecture still be visible?
3. **Decision completeness:** is any consequential choice silently delegated or merely left vague?
4. **Architecture force:** does every selected boundary exclude a plausible unacceptable
   realization?
5. **Proportionality and globality:** are work, memory, validation, materialization, and coordination
   scoped to declared drivers?
6. **Realization conformance:** did implementation introduce an unapproved owner, dependency,
   interface, persistent representation, lifecycle, transaction, or global mechanism?
7. **Evidence discrimination:** would required evidence fail for the nearest wrong system?
8. **Subtraction and comprehension:** is complexity intrinsic, or compensating for an earlier choice?

## Finding discipline

A material finding identifies a reproducible model instance, implementation path, or required
counterexample. Classify it using [finding classification](references/finding-classification.md).
Group manifestations only when one correction addresses one root cause without widening authority.

Valid dispositions are: clean; model correction; realization correction; evidence correction;
rollback/replan; stale baseline; or out of scope.

Do not edit the reviewed model or implementation. Re-review the corrected checkpoint in fresh
context. See [review protocol](references/review-protocol.md).
