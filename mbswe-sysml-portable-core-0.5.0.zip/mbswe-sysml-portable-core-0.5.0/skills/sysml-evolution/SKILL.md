---
name: sysml-evolution
description: Preserve accepted decision continuity for a change spanning SysML authority, realization, compatibility, approval, or context loss. Invoke explicitly only when transient model slices and realization results are insufficient. Maintain one minimal change note; never create an implementation campaign engine.
---

# SysML Evolution

Use the lightest durable record that preserves a consequential cross-context change.

Record only the trigger, source baselines, affected authority, accepted decision, approval artifact,
compatibility consequence, resulting checkpoints, discriminating evidence, and final disposition.

Do not store task queues, worker state, token budgets, copied model prose, review-loop state,
recomputable repository observations, or a second implementation plan.

## Workflow

1. Reproduce and classify the trigger with `$sysml-assurance`.
2. Change authority through `$sysml-modeling` and obtain human acceptance when required.
3. Generate new decision-complete execution slices through `$model-projection`.
4. Realize slices independently through `$model-realization`.
5. Record only accepted decision continuity and final evidence.
6. Close when model, realizations, compatibility, evidence, and public claims agree.

A whole-system build remains a sequence of meaningful slices, not one growing campaign record.
