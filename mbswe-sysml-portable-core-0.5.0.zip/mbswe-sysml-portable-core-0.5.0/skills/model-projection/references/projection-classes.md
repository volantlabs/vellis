# Projection classes

- **View:** stakeholder-, altitude-, responsibility-, or concern-specific selection from one model.
- **Navigation artifact:** source map, package inventory, qualified-reference index, or model brief.
- **Decision artifact:** accepted decisions, rationale, alternatives, and reconsideration triggers.
- **Assurance artifact:** conformance matrix, semantic-strength report, or verification obligation.
- **Boundary artifact:** IDL, schema, protocol surface, or architecture policy explicitly selected by
  the model.
- **Execution artifact:** a decision-complete slice authorizing bounded realization.

A projection does not become authoritative merely because another tool consumes it.
