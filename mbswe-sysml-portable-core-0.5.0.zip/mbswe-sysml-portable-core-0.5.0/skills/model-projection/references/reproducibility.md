# Reproducibility

Record projector identity, model digest, resource-lane identity, selection parameters, output path,
and warnings. Generated content must be replaceable atomically and should be checked for freshness.
When nondeterministic formatting is used, compare the result against a deterministic semantic
selection and reject invented facts.
