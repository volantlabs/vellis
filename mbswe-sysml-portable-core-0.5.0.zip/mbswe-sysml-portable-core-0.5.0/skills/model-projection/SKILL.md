---
name: model-projection
description: Produce reproducible, disposable artifacts from an accepted SysML v2 model without making new design decisions. Use for views, briefs, inventories, decision reports, execution-slice inputs, traceability, interface projections, verification obligations, and other model-derived artifacts.
---

# Model Projection

Project accepted authority; never extend it.

## Projection contract

A projection must:

- identify the exact model digest and resource lane;
- state the model selection or viewpoint used;
- be reproducible from the same inputs;
- make no consequential design choice;
- carry generated status and source references;
- be replaceable rather than manually synchronized.

## Workflow

1. Verify the accepted model baseline.
2. Select the smallest complete semantic closure or declared view needed by the consumer.
3. Use a deterministic projector when one exists. If an LLM formats the result, constrain it to the
   selected facts and verify semantic equivalence.
4. Validate the output contract and source references.
5. Replace prior generated output atomically.
6. Stop and return a model gap when the requested artifact requires a decision the model does not
   contain.

## Boundaries

Do not:

- add architecture, requirements, interfaces, values, or defaults;
- infer implementation shape from familiar language conventions;
- turn a generated artifact into independent authority;
- repair model gaps inside the projection;
- claim semantic precision from a lexical source inventory.

Read [projection classes](references/projection-classes.md) and
[reproducibility](references/reproducibility.md).
