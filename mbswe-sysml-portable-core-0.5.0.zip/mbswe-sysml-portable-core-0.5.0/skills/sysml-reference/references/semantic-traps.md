# High-risk semantic distinctions

Always consult the active official evidence before deciding these.

## Ownership versus reference

A composite usage and a `ref` usage make different claims about occurrence ownership, sharing, and
lifetime. Similar payload or navigation needs do not make them interchangeable.

## Specialization, subsetting, redefinition, and binding

- specialization constrains a type or feature by another;
- subsetting constrains membership;
- redefinition replaces an inherited feature in a more specific context;
- binding requires equality/identity according to the bound feature semantics;
- a default value is not a binding.

Do not select among these from naming similarity.

## Multiplicity

Omitted multiplicity may inherit or imply meaning that differs from an explicit bound. Multiplicity
states permitted cardinality; it does not express a guard, trigger, schedule, or product option.

## Definitions and usages

A definition supplies reusable meaning. A usage places or references meaning in a context. Do not
invent definitions solely to make every name globally addressable.

## Parts, items, attributes, and occurrences

Select the construct by identity, ownership, flow, and value semantics—not by target-language
analogy such as class, object, record, or field.

## Requirements, satisfaction, and verification

A requirement states an obligation. A satisfaction relationship is a model claim. A verification
case describes evidence. None of these proves the others automatically.

## Metadata

Metadata annotates model elements; it does not replace the native ownership, behavior, interaction,
state, or requirement semantics that the annotation describes.

## SysML v1/UML displacement

Parse-valid SysML v2 text can still preserve the wrong v1 intuition. Treat block/property,
association, stereotype/profile, diagram-kind, port, and value-type translations as semantic
migration work, not token substitution.
