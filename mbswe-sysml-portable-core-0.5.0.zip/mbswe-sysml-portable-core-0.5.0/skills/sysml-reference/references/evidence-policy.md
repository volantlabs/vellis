# Evidence policy

## Precedence

For language questions, use this order:

1. active normative specification;
2. inherited KerML semantics;
3. release-matched standard library;
4. official issue resolution incorporated in the active lane;
5. configured implementation behavior;
6. official examples;
7. project convention;
8. inference.

A parser result cannot override normative meaning. An example cannot override either.

## Baseline identity

Every consequential answer should identify enough information to reproduce it:

- language/API version;
- release tag or immutable commit;
- artifact identity;
- clause, declaration, or example path;
- configured validator version when a probe was used.

## Conflicts

When the normative text, model library, and validator differ:

- preserve the normative conclusion;
- report the implementation divergence;
- avoid authoring a model that depends on the disputed behavior unless the project explicitly
  accepts a tool-specific constraint;
- record an upgrade or compatibility issue rather than hiding the difference.

## Quotes and summaries

Quote only the minimum necessary text. Prefer a concise semantic paraphrase plus the exact source
location. Keep explanatory reasoning separate from source-derived claims.
