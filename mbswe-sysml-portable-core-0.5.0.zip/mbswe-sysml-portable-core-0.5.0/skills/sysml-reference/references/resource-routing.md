# Resource routing

Use one corpus family at a time unless the question genuinely spans them.

| Question | Primary corpus | Secondary corpus | Exclude by default |
| --- | --- | --- | --- |
| What does a construct mean? | SysML/KerML language specification | release-matched library | examples, release notes |
| What reusable definition exists? | release-matched library | language specification | unrelated examples |
| Is this textual form accepted? | BNF/grammar and isolated parser probe | language notation clause | examples as authority |
| What does valid use look like? | official examples/training | already-established specification meaning | community snippets |
| How does the official implementation test a language form? | official validation models | grammar and validator probe | treating the test model as normative design |
| How do I migrate v1/UML notation? | official transformation specification | v1 displacement guide and parser hints | ordinary authoring corpus |
| How do I query or update a model repository? | Systems Modeling API specification | official API cookbook | language examples |
| What changed between baselines? | official change/delta material | both pinned specifications | current semantic search |
| How should this project model the system? | project model and modeling method | language evidence as needed | reference skill selecting design |

Do not mix stable and laboratory lanes in ordinary answers. Upgrade analysis may compare them
explicitly and must label both.
