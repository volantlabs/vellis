---
name: sysml-reference
description: Resolve consequential SysML v2, KerML, standard-library, textual-notation, migration, or Systems Modeling API questions from the project's checksum-pinned official resource lane. Use before making a model choice whose language meaning is uncertain. Never use this skill to select project architecture.
---

# SysML Reference

Establish what the language and official ecosystem mean; do not decide what the project should build.

## Required posture

1. Read `mbswe.yaml` and its resource lock.
2. Identify the active lane exactly. Never blend stable and laboratory lanes in an ordinary answer.
3. Classify the question before searching:
   - language semantics;
   - standard-library declaration;
   - textual syntax;
   - worked notation;
   - v1-to-v2 migration;
   - Systems Modeling API;
   - release upgrade.
4. Route to the matching corpus. See [resource routing](references/resource-routing.md).
5. For a consequential choice, inspect the normative clause and inherited KerML semantics. Use the
   model library to establish what reusable definitions exist. Use examples only after meaning is
   settled. Use a fresh `mbswe model probe` for textual syntax.
6. Report the active lane, conclusion, evidence class, source location, validator-specific behavior,
   and anything still inferred.

## Evidence classes

- Normative language or API specification defines semantics.
- Release-matched standard library defines reusable model elements and specializations.
- Grammar defines accepted textual form, not engineering intent.
- Official examples demonstrate notation, not universal meaning.
- The pinned validator proves only the selected implementation's behavior.
- Project convention and engineering inference must be labeled as such.

## Non-negotiable boundaries

- Never infer project structure from an official example.
- Never treat parser acceptance as model adequacy.
- Never answer from remembered SysML v1 or UML notation when official evidence is available.
- Never mutate project model or implementation.
- Stop on an unidentified lane, conflicting official revisions, or a tool extension absent from the
  resource lock.

Read [evidence policy](references/evidence-policy.md) and [semantic traps](references/semantic-traps.md)
before ownership, reference, subsetting, redefinition, binding, multiplicity, metadata, or migration
questions.
