---
name: sysml-modeling
description: Create, revise, deepen, or simplify one cohesive textual SysML v2 model of product meaning, system construction, selected architecture, engineering judgment, requirements, and verification intent. Refine recursively until every remaining realization choice required by the intended work is local, reversible, and observable.
---

# SysML Modeling

Construct accepted model authority. Do not produce a prose specification wearing SysML syntax.

## Before editing

- Read `mbswe.yaml`, the accepted baseline, affected semantic closure, and current model diff.
- Recover accepted decisions, deliberate deferrals, rejected alternatives, and historical
  counterexamples.
- State one stakeholder or engineering outcome, the observable distinction, and the nearest
  plausible wrong system.
- Use `$sysml-reference` for every consequential language uncertainty.
- Do not derive intended architecture from source layout, frameworks, tests, or predecessor code.

## Native-semantic-first workflow

1. Establish breadth: actors, system boundary, environment, outcomes, domain identity, black-box
   behavior, failure behavior, and required non-effects.
2. Apply the decision-depth test in [decision depth](references/decision-depth.md). A decision belongs
   in accepted authority when a behaviorally conforming alternative would still be rejected or when
   reversal would cause nonlocal rework.
3. Refine along the dimensions that carry the decision—not structure alone:
   - ownership and reference;
   - behavior, control, and state;
   - interactions and flows;
   - quantities, timing, resources, and failure;
   - logical and selected realization responsibilities;
   - requirements, analysis, and verification.
4. Use the strongest economical carrier described in
   [semantic carriers](references/semantic-carriers.md): native semantics, then formal expressions,
   then prose with discriminating evidence. Rationale alone is never authority.
5. Capture judgment: selected alternative, rationale, rejected alternatives, reconsideration
   condition, delegation disposition, and historical counterexample. See
   [judgment and delegation](references/judgment-and-delegation.md).
6. Exercise nominal, alternate/failed, boundary, and nearest-wrong instances. For every selected
   boundary, state what unacceptable implementation it excludes.
7. Run official validation, semantic-index policy, and an independent `$sysml-assurance` review.
8. Obtain human acceptance for changed product meaning or consequential selected architecture.

## Decision completeness

A slice is ready for unattended realization only when:

- every required consequential choice is governed or forbidden;
- no required choice remains deferred;
- every delegated choice is local, reversible, and visible in a small diff;
- authoritative state ownership is unambiguous;
- consequential interaction, lifecycle, transaction, concurrency, persistence, materialization,
  failure, compatibility, and scale behavior is decided;
- architecture-critical prose has a waiver and evidence;
- the nearest wrong implementation is rejected by semantics or evidence;
- the slice can be reconstructed without conversation history.

## Stopping rule

Stop refining when all remaining choices can change inside one governed responsibility without
moving authoritative state, crossing a selected boundary, changing persistent meaning, widening a
transaction or lifecycle, altering resource scale drivers, or forcing nonlocal rework.

Read [review lenses](references/review-lenses.md) before declaring the model adequate.
