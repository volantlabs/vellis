# Modeling review lenses

Run these as separate questions. Do not let one clean lens imply the others are clean.

## Semantic closure

- Can nominal, alternate/failed, boundary, and nearest-wrong instances be decided?
- Are identity, ownership, multiplicity, absence, equality, state, interaction, and non-effects clear?
- Can every output or effect be traced to a stimulus, behavior, decision, or requirement?

## Architecture fitness

- Does every selected part or boundary rule out a plausible unacceptable realization?
- Is authoritative state uniquely owned?
- Are interactions and dependencies explicit where bypass would matter?
- Are derived representations prevented from becoming independent authority?
- Are transaction, concurrency, failure, and lifecycle responsibilities located?

## Proportionality and globality

For each ordinary operation:

- what may work, memory, validation, and coordination scale with?
- what unrelated population must not affect it?
- what may be retained or materialized?
- which operations are legitimately global?
- does a local semantic change require a global mechanism?

## Semantic strength

- Remove documentation mentally: does meaningful architecture remain?
- Which critical claims exist only in prose?
- Does every prose waiver identify evidence and a reconsideration trigger?
- Are parser acceptance and model adequacy being confused?

## Subtraction

- What claim becomes false or unverifiable if this element is removed?
- Is this the least committal native carrier?
- Is a part, interface, action, requirement, or variant present only for symmetry, future-proofing,
  source transcription, or framework familiarity?

## Decision completeness

- Are any consequential decisions marked delegated?
- Does the slice require a deferred choice?
- Could an executor introduce a new owner, lifecycle, persistence mechanism, global operation, or
  interface while still claiming conformance?
- Can the execution packet be generated without hidden conversational assumptions?
