# Semantic carriers

For every material claim identify its carrier and residual prose.

## Strength order

1. **Native semantics** — ownership/reference, multiplicity, specialization, subsetting,
   redefinition, binding, parts/items/attributes, actions, states, ports, interfaces, connections,
   flows, allocations, satisfaction, verification, views.
2. **Formal constraint or calculation** — a complete expression with defined inputs, units, and
   result semantics where applicable.
3. **Prose-backed authority with evidence** — a requirement or other authoritative element with a
   subject, a precise natural-language obligation, and verification that rejects the nearest wrong
   system.
4. **Rationale or documentation** — explains a decision but does not itself constrain valid system
   instances.

Use the strongest level justified by current knowledge and value. Stronger is not automatically
better when it encodes false precision.

## Architecture-critical claims

These should not rely only on unclassified prose:

- ownership and independent existence;
- identity and equality;
- multiplicity and completeness;
- decomposition and boundary crossing;
- allowed interaction and dependency;
- lifecycle and state transition;
- ordering and concurrency;
- transaction and failure non-effects;
- authoritative versus derived information;
- persistence and materialization;
- resource scaling and globality;
- allocation from logical responsibility to selected realization.

When native semantics cannot economically express the complete claim, annotate the residual prose
with a semantic-strength waiver that names:

- why native or formal semantics are insufficient;
- the constrained subject;
- the nearest wrong system;
- the evidence that discriminates it;
- the trigger for revisiting stronger representation.

## Semantic-carrier ledger

For each material decision, be able to produce:

| Claim | Carrier | Residual prose | Wrong instance excluded | Evidence |
| --- | --- | --- | --- | --- |

The ledger is generated from model metadata and relationships. It is not a separately maintained
specification.
