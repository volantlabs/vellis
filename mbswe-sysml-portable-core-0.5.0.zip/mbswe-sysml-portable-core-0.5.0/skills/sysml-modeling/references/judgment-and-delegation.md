# Judgment and delegation

The model must preserve enough architectural judgment that execution does not depend on the original
conversation.

## Decision dispositions

- **governed** — the accepted model selects the choice;
- **delegated** — implementation may choose within the modeled boundary;
- **deferred** — the project intentionally postpones selection; work requiring it is not ready;
- **forbidden** — the choice is outside the permitted realization.

Do not represent an unresolved engineering choice as runtime variability unless the system itself
must expose that variability.

## What to retain

Retain a decision when it is consequential and one or more plausible alternatives remain:

- selected alternative;
- rejected alternatives that are likely to recur;
- rationale and quality priorities;
- evidence or trade analysis;
- reconsideration trigger;
- implementation freedom intentionally preserved.

Use native model alternatives and analysis where useful. Use the release-matched
`ModelingMetadata::Rationale` or the portable governance metadata for concise rationale. Do not
preserve every brainstorming option.

## Counterexamples

A historical failure should normally become:

1. a positive architectural commitment;
2. a nearest-wrong verification case;
3. optional rationale explaining why the commitment exists.

Examples:

- whole-state replacement for a local mutation becomes bounded change, affected-closure validation,
  single state ownership, and unrelated-population independence;
- a retained complete derived view becomes explicit derived evaluation and bounded lifetime;
- hidden witnesses multiplying answers becomes answer identity, projection, and bound-before-
  hydration semantics.

## Human acceptance

Use the project's accepted model baseline as the approval artifact. Avoid duplicating approval state
on every element unless the modeled system itself needs that state. A generated execution packet must
bind to the accepted baseline digest.
