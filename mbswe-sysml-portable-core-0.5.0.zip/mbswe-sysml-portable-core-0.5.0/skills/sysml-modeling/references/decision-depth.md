# Decision depth

Use implementation fears to locate missing positive commitments, not to grow a prohibition list.

## Consequential-decision indicators

A decision is consequential when any of these are true:

- a behaviorally conforming implementation could make the choice differently and still be rejected;
- reversing it would affect several components, persistent state, public contracts, or future slices;
- it creates, moves, duplicates, or derives authoritative state;
- it establishes identity, lifecycle, transaction, concurrency, failure, safety, or security
  responsibility;
- it changes dependency direction or permits a boundary bypass;
- it introduces persistence, a cache, queue, worker, registry, snapshot, secondary representation,
  background lifecycle, or deployment unit;
- it changes work from local to population-wide or changes permitted materialization;
- it cannot be evaluated confidently from a small local change.

Consequential decisions must be governed, forbidden, or explicitly deferred for later human
selection.

## Local-decision indicators

A choice may be delegated when it is:

- private to one governed responsibility;
- inexpensive to reverse;
- independently testable;
- visible in a small diff;
- unable to change state ownership, dependencies, persistence, concurrency, or public behavior;
- replaceable without forcing changes in neighboring slices.

## Refinement test

At each altitude ask:

1. What unacceptable implementation remains possible?
2. Which positive ownership, behavior, interaction, state, resource, or realization commitment would
   exclude it?
3. Which native SysML relationship carries that commitment?
4. What acceptable implementation freedom remains?

Do not add another subpart merely to increase structural detail. A deeper part tree without
ownership, behavior, interaction, or constraints may rule out nothing.
