# Decision-complete local change example

This example captures the class of failure that motivated the architecture controls: an ordinary local mutation must not be realized by copying complete state, validating the whole population, globally quiescing activity, and swapping the replacement.

The files are copied from the portable templates and illustrate two generated projections:

- `model-index.yaml` — normalized claims, decisions, state ownership, boundaries, operations, resource scope, and evidence;
- `execution-slice.yaml` — the exact-baseline packet supplied to a realization agent.

They are not independent specifications. In a real project both are generated from accepted SysML through a semantic adapter, validated, and bound to actual digests/checkpoints.

Validate them from this repository:

```sh
mbswe artifact validate model-index examples/decision-complete-change/model-index.yaml
mbswe slice validate examples/decision-complete-change/execution-slice.yaml
```
