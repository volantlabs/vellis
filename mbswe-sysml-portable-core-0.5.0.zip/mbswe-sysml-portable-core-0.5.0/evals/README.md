# Behavioral evaluations

The portable core must be evaluated as agent behavior, not only as file/schema validity.

Run each scenario with a fresh context and the relevant skill available. Do not disclose the expected
answer. Preserve only:

- scenario identifier;
- model/tool baseline;
- output;
- scored criteria;
- disposition.

Do not commit raw reasoning transcripts.

## Evaluation axes

- **routing** — the correct skill activates and irrelevant skills do not;
- **official evidence** — authority classes are labeled correctly;
- **semantic construction** — native semantics are selected instead of prose laundering;
- **decision depth** — the model deepens only where a consequential choice remains;
- **stop behavior** — realization stops rather than inventing architecture;
- **classification** — assurance distinguishes model, implementation, evidence, platform, and process
  defects;
- **negative cases** — rules fire only where intended;
- **stability** — repeat across at least two model families or effort settings when practical.

The YAML files contain expected observable criteria, not exact wording.
