from __future__ import annotations

import json
import os
import subprocess
import sys
import zipfile
from copy import deepcopy
from pathlib import Path

import pytest
import yaml

from mbswe.artifacts import (
    execution_slice_errors,
    semantic_model_index_errors,
    validate_artifact,
)
from mbswe.config import load_layers, load_project
from mbswe.corecheck import core_errors
from mbswe.errors import MBSwEError
from mbswe.layers import archive_profile, export_profile
from mbswe.manifests import sync_provider_manifests
from mbswe.model import model_digest
from mbswe.project import init_project, project_errors, project_status, sync_project
from mbswe.projection import projection_result
from mbswe.reference import _classify_release_file
from mbswe.resources import resource_status
from mbswe.slices import generate_execution_slice

ROOT = Path(__file__).resolve().parents[1]


def highest_profile() -> str:
    return next(reversed(load_layers()["profiles"]))


def require_realization_profile() -> str:
    if not (ROOT / "schemas" / "execution-slice.schema.json").is_file():
        pytest.skip("realization layer is not present in this exported profile")
    return highest_profile()


def load_yaml(path: Path):
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def test_portable_core_self_check_is_non_vacuous() -> None:
    assert list((ROOT / "skills").glob("*/SKILL.md"))
    assert list((ROOT / "schemas").glob("*.json"))
    assert core_errors() == []


def test_provider_manifests_are_generated_from_package() -> None:
    assert sync_provider_manifests(ROOT, check=True) == []


def test_available_profiles_export_as_standalone_repositories(tmp_path: Path) -> None:
    for profile in load_layers()["profiles"]:
        destination = tmp_path / profile
        export_profile(profile, destination)
        assert (destination / "EXPORTED_PROFILE").read_text().strip() == profile
        assert (destination / "bootstrap").is_file()
        assert (destination / "skills").is_dir()
        assert (destination / "PROFILE.md").is_file()
        assert (destination / "MANIFEST.sha256").is_file()


def test_available_profiles_archive_with_single_repository_root(tmp_path: Path) -> None:
    profile = next(iter(load_layers()["profiles"]))
    archive = archive_profile(profile, tmp_path / "profile.zip")
    with zipfile.ZipFile(archive) as value:
        names = value.namelist()
        roots = {name.split("/", 1)[0] for name in names if name}
        assert roots == {f"mbswe-portable-core-{profile}"}
        assert f"mbswe-portable-core-{profile}/bootstrap" in names
        forbidden = {".git", ".venv", ".pytest_cache", "__pycache__"}
        assert not any(forbidden & set(Path(name).parts) for name in names)
        assert not any(name.endswith((".pyc", ".pyo")) for name in names)


def test_project_init_and_sync_preserve_project_owned_model(tmp_path: Path) -> None:
    profile = highest_profile()
    target = tmp_path / "project"
    init_project(target, profile=profile, project_id="sample")
    model = target / "model" / "10-system.sysml"
    model.write_text("package SampleSystem { part def Kept; }\n", encoding="utf-8")
    extra = target / ".agents" / "skills" / "project-local"
    extra.mkdir(parents=True)
    (extra / "SKILL.md").write_text(
        "---\nname: project-local\ndescription: Project-only skill.\n---\n# Project\n",
        encoding="utf-8",
    )

    sync_project(target)

    assert "part def Kept" in model.read_text(encoding="utf-8")
    assert extra.is_dir()
    assert project_errors(target) == []
    status = project_status(target)
    assert status["missing_skills"] == []


def test_resource_status_reports_unsynchronized_cache_without_error(tmp_path: Path) -> None:
    target = tmp_path / "resource-status-project"
    init_project(target, profile="reference")
    project = load_project(target)
    status = resource_status(project)
    assert status["lane"] == project.lane
    assert status["synchronized"] is False
    assert status["missing"] == ["resolved.json"]


def test_project_resource_cache_mode_is_respected(tmp_path: Path) -> None:
    target = tmp_path / "project-cache"
    init_project(target, profile="reference")
    manifest = load_yaml(target / "mbswe.yaml")
    manifest["resources"]["cache"] = "project"
    (target / "mbswe.yaml").write_text(yaml.safe_dump(manifest, sort_keys=False), encoding="utf-8")
    project = load_project(target)
    assert project.resource_cache_root == target / ".mbswe" / "cache"


def test_project_manifest_enables_execution_slices_only_with_realization_layer(
    tmp_path: Path,
) -> None:
    reference = tmp_path / "reference"
    init_project(reference, profile="reference")
    assert load_yaml(reference / "mbswe.yaml")["autonomy"]["require_execution_slice"] is False
    if (ROOT / "schemas" / "execution-slice.schema.json").is_file():
        realization = tmp_path / "realization"
        init_project(realization, profile=highest_profile())
        assert (
            load_yaml(realization / "mbswe.yaml")["autonomy"]["require_execution_slice"]
            is True
        )


def test_reference_profile_does_not_install_modeling_library(tmp_path: Path) -> None:
    if "reference" not in load_layers()["profiles"]:
        return
    target = tmp_path / "reference-project"
    init_project(target, profile="reference")
    assert not (target / "model" / "vendor" / "mbswe").exists()
    assert load_project(target).raw["model"]["policy"] is None


def test_projection_is_deterministic_and_baseline_bound(tmp_path: Path) -> None:
    profile = highest_profile()
    target = tmp_path / "project"
    init_project(target, profile=profile)
    project = load_project(target)
    projection_root = project.artifact_root("projections")
    first_path = projection_root / "first.json"
    second_path = projection_root / "second.json"
    first = projection_result(
        project, projector="source-inventory", destination=first_path
    )
    second = projection_result(
        project, projector="source-inventory", destination=second_path
    )
    assert first_path.read_bytes() == second_path.read_bytes()
    assert first["projection"]["model_digest"] == second["projection"]["model_digest"]
    assert first["projection"]["output_sha256"] == second["projection"]["output_sha256"]


def test_projection_refuses_output_outside_generated_projection_root(tmp_path: Path) -> None:
    profile = require_realization_profile()
    target = tmp_path / "project"
    init_project(target, profile=profile)
    project = load_project(target)
    try:
        projection_result(
            project,
            projector="source-inventory",
            destination=target / "model" / "overwritten.sysml",
        )
    except MBSwEError as error:
        assert "projection output must be under" in str(error)
    else:
        raise AssertionError("projection escaped its configured generated root")


def test_decision_report_rejects_stale_model_index(tmp_path: Path) -> None:
    profile = require_realization_profile()
    target = tmp_path / "project"
    init_project(target, profile=profile)
    project = load_project(target)
    index = project.generated_root / "model-index.yaml"
    index.parent.mkdir(parents=True, exist_ok=True)
    value = load_yaml(ROOT / "templates" / "model-index.example.yaml")
    value["baseline"]["model_digest"] = "sha256:" + "0" * 64
    index.write_text(yaml.safe_dump(value, sort_keys=False), encoding="utf-8")
    try:
        projection_result(
            project,
            projector="decision-report",
            destination=project.artifact_root("projections") / "decisions.md",
            index=index,
        )
    except MBSwEError as error:
        assert "model index is stale" in str(error)
    else:
        raise AssertionError("stale semantic model index was accepted")


def test_present_artifact_templates_are_valid() -> None:
    kinds = {
        "project": "mbswe.project.yaml",
        "model-index": "model-index.example.yaml",
        "execution-slice": "execution-slice.yaml",
        "projection-request": "projection-request.yaml",
        "projection-result": "projection-result.yaml",
        "realization-result": "realization-result.yaml",
        "model-feedback": "model-feedback.yaml",
        "change-note": "change-note.yaml",
        "domain-pack": "domain-pack.yaml",
    }
    for kind, filename in kinds.items():
        path = ROOT / "templates" / filename
        if path.is_file():
            assert validate_artifact(kind, path) == []


def test_consequential_decision_cannot_be_delegated() -> None:
    path = ROOT / "templates" / "model-index.example.yaml"
    if not path.is_file():
        return
    value = load_yaml(path)
    value["decisions"][0]["disposition"] = "delegated"
    assert any(
        "consequential decisions cannot be delegated" in error
        for error in semantic_model_index_errors(value)
    )


def test_prose_claim_requires_waiver_and_discriminating_evidence() -> None:
    path = ROOT / "templates" / "model-index.example.yaml"
    if not path.is_file():
        return
    value = load_yaml(path)
    claim = value["claims"][0]
    claim.pop("waiver")
    claim["evidence_refs"] = []
    errors = semantic_model_index_errors(value)
    assert any("requires waiver" in error for error in errors)
    assert any("requires evidence_refs" in error for error in errors)


def test_authoritative_state_requires_one_owner() -> None:
    path = ROOT / "templates" / "model-index.example.yaml"
    if not path.is_file():
        return
    value = load_yaml(path)
    value["states"][0]["owner_refs"].append("ProjectArchitecture::SecondOwner")
    assert any(
        "requires exactly one owner" in error for error in semantic_model_index_errors(value)
    )


def test_deferred_decision_is_rejected_from_execution_packet() -> None:
    path = ROOT / "templates" / "execution-slice.yaml"
    if not path.is_file():
        return
    value = deepcopy(load_yaml(path))
    value["architecture"]["decisions"][0]["disposition"] = "deferred"
    assert any("cannot remain deferred" in error for error in execution_slice_errors(value))

def test_reference_classification_preserves_official_evidence_classes() -> None:
    assert _classify_release_file("sysml/src/training/42. Views/example.sysml") == "examples"
    assert _classify_release_file("sysml/src/validation/11-View/test.sysml") == "validation-models"
    assert _classify_release_file("sysml/src/other/model.sysml") == "official-models"
    assert _classify_release_file("sysml.library/Systems Library/Views.sysml") == "library"


def test_generated_slice_carries_responsibility_and_interaction_closure(tmp_path: Path) -> None:
    profile = require_realization_profile()
    target = tmp_path / "slice-project"
    init_project(target, profile=profile)
    project = load_project(target)
    index = project.generated_root / "model-index.yaml"
    index.parent.mkdir(parents=True, exist_ok=True)
    index_value = load_yaml(ROOT / "templates" / "model-index.example.yaml")
    index_value["baseline"]["model_digest"] = model_digest(project)
    index_value["baseline"]["language_lane"] = project.lane
    index.write_text(yaml.safe_dump(index_value, sort_keys=False), encoding="utf-8")
    output = project.artifact_root("slices") / "slice.yaml"
    generate_execution_slice(
        project,
        index_path=index,
        operation_ref="ProjectArchitecture::ApplyLocalChange",
        destination=output,
        slice_id="TEST-001",
        title="Test one local change",
        implementation_checkpoint="git:HEAD",
        mode="autonomous",
        approval_status="accepted",
        approval_artifact="git:MODEL-ACCEPTANCE",
    )
    value = load_yaml(output)
    responsibility_refs = {item["ref"] for item in value["architecture"]["responsibilities"]}
    assert responsibility_refs == {
        "ProjectArchitecture::CanonicalRepository",
        "ProjectArchitecture::ChangeCoordinator",
    }
    assert value["architecture"]["interactions"] == [
        {
            "source_ref": "ProjectArchitecture::ChangeCoordinator",
            "target_ref": "ProjectArchitecture::CanonicalRepository",
            "interface_ref": "ProjectArchitecture::ChangePublicationInterface",
            "meaning": "Publish only governed changed and retired identities inside the selected transaction boundary.",
        }
    ]
    assert {item["id"] for item in value["evidence"]} == {"EV-LOCALITY", "EV-OWNER"}
    assert validate_artifact("execution-slice", output) == []


def test_execution_slice_refuses_unmanaged_input_or_output_paths(tmp_path: Path) -> None:
    profile = require_realization_profile()
    target = tmp_path / "slice-boundary-project"
    init_project(target, profile=profile)
    project = load_project(target)
    unmanaged_index = target / "index.yaml"
    unmanaged_index.write_text(
        (ROOT / "templates" / "model-index.example.yaml").read_text(encoding="utf-8"),
        encoding="utf-8",
    )
    try:
        generate_execution_slice(
            project,
            index_path=unmanaged_index,
            operation_ref="ProjectArchitecture::ApplyLocalChange",
            destination=project.artifact_root("slices") / "slice.yaml",
            slice_id="TEST-BOUNDARY",
            title="Reject unmanaged input",
            implementation_checkpoint="git:HEAD",
            mode="copilot",
            approval_status="pending",
            approval_artifact=None,
        )
    except MBSwEError as error:
        assert "semantic model index must be under" in str(error)
    else:
        raise AssertionError("execution slice accepted an unmanaged model-index path")


def test_execution_slice_rejects_stale_model_index(tmp_path: Path) -> None:
    profile = require_realization_profile()
    target = tmp_path / "stale-slice-project"
    init_project(target, profile=profile)
    project = load_project(target)
    index = project.generated_root / "model-index.yaml"
    index.parent.mkdir(parents=True, exist_ok=True)
    value = load_yaml(ROOT / "templates" / "model-index.example.yaml")
    value["baseline"]["model_digest"] = "sha256:" + "0" * 64
    index.write_text(yaml.safe_dump(value, sort_keys=False), encoding="utf-8")
    try:
        generate_execution_slice(
            project,
            index_path=index,
            operation_ref="ProjectArchitecture::ApplyLocalChange",
            destination=project.artifact_root("slices") / "slice.yaml",
            slice_id="TEST-STALE",
            title="Reject stale index",
            implementation_checkpoint="git:HEAD",
            mode="copilot",
            approval_status="pending",
            approval_artifact=None,
        )
    except MBSwEError as error:
        assert "model index is stale" in str(error)
    else:
        raise AssertionError("execution slice accepted a stale model index")


def test_pending_copilot_slice_is_valid_but_pending_autonomous_slice_is_not() -> None:
    require_realization_profile()
    value = deepcopy(load_yaml(ROOT / "templates" / "execution-slice.yaml"))
    value["slice"]["mode"] = "copilot"
    value["approval"] = {"status": "pending", "artifact": None}
    temp = ROOT / ".mbswe-work-test-pending.yaml"
    try:
        temp.write_text(yaml.safe_dump(value, sort_keys=False), encoding="utf-8")
        assert validate_artifact("execution-slice", temp) == []
        value["slice"]["mode"] = "autonomous"
        temp.write_text(yaml.safe_dump(value, sort_keys=False), encoding="utf-8")
        assert any("autonomous slice requires" in error for error in validate_artifact("execution-slice", temp))
    finally:
        temp.unlink(missing_ok=True)

def test_project_sync_refuses_to_replace_project_owned_core_skill_name(tmp_path: Path) -> None:
    target = tmp_path / "collision-project"
    target.mkdir()
    skill = target / ".agents" / "skills" / "sysml-reference"
    skill.mkdir(parents=True)
    (skill / "SKILL.md").write_text(
        "---\nname: sysml-reference\ndescription: Project-owned collision.\n---\n# Local\n",
        encoding="utf-8",
    )
    try:
        init_project(target, profile="reference")
    except Exception as error:
        assert "refusing to replace project-owned path" in str(error)
    else:
        raise AssertionError("project-owned skill collision was overwritten")
    assert "Project-owned collision" in (skill / "SKILL.md").read_text(encoding="utf-8")
    assert not (target / "mbswe.yaml").exists()


def test_project_check_detects_stale_managed_skill(tmp_path: Path) -> None:
    target = tmp_path / "stale-skill-project"
    init_project(target, profile="reference")
    skill = target / ".agents" / "skills" / "sysml-reference" / "SKILL.md"
    skill.write_text(skill.read_text(encoding="utf-8") + "\nLocal stale edit.\n", encoding="utf-8")
    assert any("managed portable skill is stale" in error for error in project_errors(target))

def test_exported_reference_cli_hides_realization_only_commands(tmp_path: Path) -> None:
    exported = tmp_path / "reference"
    export_profile("reference", exported)
    env = os.environ.copy()
    env["PYTHONPATH"] = str(exported / "src")
    completed = subprocess.run(
        [sys.executable, "-m", "mbswe", "--help"],
        cwd=exported,
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )
    assert completed.returncode == 0, completed.stderr
    assert "\n    projection " not in completed.stdout
    assert "\n    slice " not in completed.stdout


def test_exported_profile_cli_defaults_to_highest_available_profile(tmp_path: Path) -> None:
    profile = next(iter(load_layers()["profiles"]))
    exported = tmp_path / "exported"
    export_profile(profile, exported)
    target = tmp_path / "target"
    env = os.environ.copy()
    env["PYTHONPATH"] = str(exported / "src")
    completed = subprocess.run(
        [sys.executable, "-m", "mbswe", "project", "init", str(target)],
        cwd=exported,
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )
    assert completed.returncode == 0, completed.stderr
    assert load_yaml(target / "mbswe.yaml")["core"]["profile"] == profile

