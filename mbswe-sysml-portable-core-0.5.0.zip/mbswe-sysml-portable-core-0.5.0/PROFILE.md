# Exported full profile

This is an independently bootstrappable cumulative export of the MBSwE portable core.

- Layers: reference, modeling, realization
- Extras: evolution
- Skills: sysml-reference, sysml-modeling, sysml-assurance, model-projection, model-realization, sysml-evolution

Run `./bootstrap`, then `mbswe project init <target>`. The CLI defaults to the highest profile available in this export.
