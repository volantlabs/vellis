# MBSwE Portable Core

A self-bootstrapping, provider-neutral repository for using **textual SysML v2 as durable system and selected-architecture authority**.

The core is organized as three cumulative layers:

1. **SysML Language Foundation** — checksum-pinned official SysML, KerML, model-library, grammar, migration, Systems Modeling API, example, and validator resources; local source-labelled search; isolated syntax probes; formal model validation.
2. **Model Engineering** — native-semantic systems modeling, recursively selected architecture, decision and rationale capture, model assurance, semantic-strength policy, multi-altitude views, and readiness for delegated work.
3. **Model Utilization and Realization** — deterministic projections and bounded real-world realization from accepted, decision-complete model slices.

An optional explicit-only evolution skill preserves consequential decisions across long context or approval boundaries without creating a campaign engine.

## Why this exists

A behavioral specification can admit implementations that are technically conforming but architecturally unacceptable. Long-running agents can then turn an early design choice into repository state, build later decisions around it, and make repair increasingly expensive.

This core controls that failure mode by allocating authority:

- the **accepted SysML model** owns product meaning, system construction, selected architecture, engineering judgment, requirements, and verification intent;
- the **implementation** owns executable realization and only those local choices the model deliberately delegates;
- **evidence** establishes conformance;
- generated views, reports, plans, and packets are disposable projections, not independently edited specifications.

The central modeling rule is:

> Refine until every remaining choice required by the intended work is local, reversible, observable in a small diff, and incapable of silently redefining the architecture.

## Bootstrap this repository

macOS/Linux:

```sh
./bootstrap
```

PowerShell:

```powershell
./bootstrap.ps1
```

Bootstrap creates `.venv`, installs the CLI, runs the portable-core self-check, and runs the tests. Official SysML resources are fetched only when a target project asks for them.

After bootstrap:

```sh
.venv/bin/mbswe --help
.venv/bin/mbswe layer list
```

## Export the layer you need

Each profile is a standalone, self-bootstrapping repository. Profiles are cumulative.

```sh
# Folder exports
.venv/bin/mbswe layer export reference   /tmp/mbswe-reference
.venv/bin/mbswe layer export modeling    /tmp/mbswe-modeling
.venv/bin/mbswe layer export realization /tmp/mbswe-realization
.venv/bin/mbswe layer export full        /tmp/mbswe-full

# ZIP exports
.venv/bin/mbswe layer archive reference   dist/mbswe-reference.zip
.venv/bin/mbswe layer archive modeling    dist/mbswe-modeling.zip
.venv/bin/mbswe layer archive realization dist/mbswe-realization.zip
.venv/bin/mbswe layer archive full        dist/mbswe-full.zip
```

Profiles:

| Profile | Included capability |
| --- | --- |
| `reference` | Layer 1 only |
| `modeling` | Layers 1–2 |
| `realization` | Layers 1–3 |
| `full` | Layers 1–3 plus explicit evolution continuity |

## Integrate a fresh or existing project

With this core installed externally:

```sh
MBSWE=/path/to/portable-core/.venv/bin/mbswe
$MBSWE project init /path/to/repo --profile full
$MBSWE project check --project /path/to/repo
```

To place a profile inside the target repository instead:

```sh
mbswe project init /path/to/repo --profile full --install-mode vendored
/path/to/repo/.mbswe/mbswe project check
```

`project init` and `project sync` manage only marked portable assets. They do not overwrite project-owned SysML, implementation source, tests, or project-local skills.

Next, synchronize the selected official resource lane:

```sh
mbswe resources sync
mbswe reference build
mbswe model validate --self-test
```

The default `stable-2.0` lane targets final KerML 1.0, SysML 2.0, and Systems Modeling API 1.0 material from the official release repository. A separate laboratory lane is available for post-adoption SysML 2.1/KerML 1.1 revisions. Resource upgrades are explicit:

```sh
mbswe project upgrade-resources lab-2.1-beta2
mbswe resources sync
mbswe reference build --force
mbswe model validate --self-test
```

## Normal workflow

### Work with the language

```sh
mbswe reference search "composite versus reference usage"
mbswe reference search "rationale metadata" --corpus library --corpus examples
printf '%s\n' 'package Probe { part def A; }' | mbswe model probe
```

The reference layer separates normative specification, standard library, grammar, examples, migration, API, API cookbook, validator behavior, and release changes. Examples and parser acceptance are never treated as normative design evidence.

### Engineer the model

Use the project-installed skills:

- `$sysml-reference` for language evidence;
- `$sysml-modeling` to create or revise accepted authority;
- `$sysml-assurance` for independent review.

Then run:

```sh
mbswe model validate --self-test
mbswe model digest
mbswe model inventory
mbswe project check
```

`model inventory` is intentionally lexical. A true semantic model index must come from a conforming semantic adapter—eventually the Systems Modeling API or another model repository—not from pretending that source regexes understand SysML.

### Project artifacts from the model

Deterministic projections make no design decisions:

```sh
mbswe projection create source-inventory .mbswe/generated/projections/source-inventory.json
mbswe projection create model-brief .mbswe/generated/projections/model-brief.md
mbswe projection create decision-report .mbswe/generated/projections/decisions.md \
  --index .mbswe/generated/model-index.yaml
```

A decision-complete execution slice authorizes bounded realization:

```sh
mbswe slice from-index \
  --index .mbswe/generated/model-index.yaml \
  --operation ProjectArchitecture::ApplyLocalChange \
  --id CHANGE-001 \
  --title "Apply one local semantic change" \
  --checkpoint git:HEAD \
  --mode autonomous \
  --approval accepted \
  --approval-artifact git:MODEL_ACCEPTANCE_COMMIT \
  --output .mbswe/slices/change-001.yaml

mbswe slice validate .mbswe/slices/change-001.yaml
```

The realization agent may choose only delegated local details. New state owners, subsystem boundaries, interfaces, persistent representations, schemas, transactions, synchronization domains, queues, caches, workers, registries, lifecycles, global operations, or excluded scale dependencies require a model proposal or stop.

## Repository map

```text
.
├── bootstrap / bootstrap.ps1       self-bootstrap and verification
├── src/mbswe/                      CLI and portable runtime
├── skills/                         canonical provider-neutral agent skills
├── model-libraries/mbswe/          optional doctrine/metadata/viewpoint library
├── resources/                      immutable official-resource lane catalog and locks
├── schemas/                        generated-artifact and configuration contracts
├── templates/                      project, model-index, slice, feedback, and result examples
├── evals/                          behavioral skill evaluations
├── examples/                       worked decision-complete example
├── docs/                           architecture, method, curation, migration, and limitations
├── layers.yaml                     cumulative profile definition
├── skill-catalog.yaml              canonical role and mutation-boundary catalog
├── package.yaml                    provider-neutral package authority
└── tests/                          offline portable-core regression suite
```

## Design boundaries

- A skill never mutates both accepted model authority and implementation in the same trajectory.
- `model-projection` creates reproducible views; `model-realization` performs bounded synthesis. They are intentionally different capabilities.
- The accepted SysML model is the only system/architecture authority. Execution packets and model indexes identify their source baseline and are regenerable.
- Architecture-critical natural language is allowed only when native semantics or formal expressions are not economical, and must be paired with a waiver plus evidence for the nearest wrong system.
- The official validator proves language conformance, not engineering adequacy.
- A stop caused by an ungoverned consequential decision is a successful autonomous result.

## Documentation

- [Architecture](docs/architecture.md)
- [Quick start](docs/quickstart.md)
- [Three layers and profiles](docs/layers.md)
- [Authority and artifact lifecycle](docs/authority-and-artifacts.md)
- [Model-engineering method](docs/modeling-method.md)
- [Projection and realization](docs/projection-and-realization.md)
- [Official-resource curation](docs/resource-curation.md)
- [Skill curation and evaluation](docs/skill-curation.md)
- [Tool and adapter contracts](docs/tool-contracts.md)
- [Domain packs](docs/domain-packs.md)
- [Adoption plan](docs/adoption.md)
- [Migration from Vellis v2](docs/migration-from-vellis-v2.md)
- [Validation](docs/validation.md)
- [Release-candidate validation results](VALIDATION_RESULTS.txt)
- [Known limitations](docs/limitations.md)

## Status

The Python runtime, schemas, manifests, profile exports, project integration, managed-asset synchronization, deterministic projections, execution-slice policy, and offline tests are implemented. The packaged semantic-index contract is real, but a full semantic SysML adapter is deliberately not faked; the built-in source inventory remains lexical until a Systems Modeling API or equivalent adapter is connected.
