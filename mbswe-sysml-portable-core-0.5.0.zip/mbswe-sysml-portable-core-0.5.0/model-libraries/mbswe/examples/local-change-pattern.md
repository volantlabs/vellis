# Local-change modeling pattern

This is a modeling prompt, not authoritative SysML text.

For a local mutation, model enough native semantics to decide:

## Structure and ownership

- one repository responsibility compositionally owns canonical state;
- the coordinator references that owner rather than owning another complete state;
- closure analysis and validation have no publishing interaction;
- publication alone may update canonical state;
- temporary validation work is owned by the operation occurrence.

## Behavior

```text
request
→ resolve current state
→ compose bounded proposed delta
→ derive affected closure
→ validate closure
→ publish changed/retired identities atomically
→ append observation
→ return result
```

Represent ordering, inputs, outputs, and interactions with actions, successions, item/message flows,
ports/interfaces, and references where the active model needs them.

## Resource meaning

State or verify:

- ordinary work may scale with the request and affected closure;
- ordinary work may not scale with unrelated population;
- complete-state copies and global quiescence are absent;
- global audit, import, restore, or backup may have different selected scope.

## Counterexample

Retain the historical wrong system as verification evidence:

```text
clone complete state → apply one field delta → validate all state
→ queue unrelated activity → replace live state
```

The model is adequate when this system conflicts with positive ownership, flow, materialization, or
resource commitments—not merely because a prose sentence says “do not copy the database.”
