# MBSwE model library

`00-MBSwEMetadata.sysml` supplies a small amount of metadata needed to make judgment and delegation
queryable:

- decision kind, impact, and disposition;
- semantic strength and prose waivers;
- model altitude;
- historical counterexample identity.

It is intentionally small. Do not create a custom shadow metamodel for ordinary SysML semantics.

`10-MBSwEDoctrine.sysml` supplies reusable high-level engineering obligations. These definitions are
necessarily broad and partly textual. A project that applies them must still:

- establish a compatible subject;
- represent the project-specific ownership, behavior, interaction, state, or realization natively;
- select a satisfier where applicable;
- define analysis or verification that excludes the nearest wrong system.

The doctrine package does not make a project decision complete by import alone.

`20-MBSwEViewpoints.sysml` supplies concerns and viewpoints for model authority, altitude coherence,
autonomous readiness, architecture fitness, proportionality, and discriminating evidence. Projects
should define views that expose their own qualified model content against these concerns rather than
copying the model into review documents.

## Recommended use

Use release-matched `ModelingMetadata::Rationale` for ordinary rationale and formal analysis
explanations. Use `MBSwEMetadata::DecisionBoundary` only when the implementation agent needs to know
whether a consequential choice is governed, delegated, deferred, or forbidden.

Example annotation pattern:

```sysml
metadata publicationDecision : DecisionBoundary about changeCoordinator {
    decisionId = "ARC-007";
    kind = DecisionKind::'transaction';
    disposition = DecisionDisposition::'governed';
    impact = DecisionImpact::'consequential';
    summary = "Local changes publish bounded version deltas in one transaction.";
    reconsiderWhen = "The selected persistence layer cannot atomically publish the governed effect.";
}

metadata publicationRationale : ModelingMetadata::Rationale about changeCoordinator {
    text = "The operation is semantically local; whole-state staging would create unrelated-population dependency and global coordination.";
}
```

Probe every adopted pattern with the project's pinned validator. The files in this proposal were
written against the public SysML v2 textual patterns visible in the official release artifacts, but
the target repository remains responsible for validation against its exact active lane.
