# Official resource lanes

`catalog.yaml` is the portable-core catalog of reviewed resource lanes. Each lane has one exact
project-copyable lock under `locks/`.

A target repository records only the selected lock in `model/config/resource-lock.json`. Resource
content is fetched on demand into a user-shared or project-local ignored cache and is never copied
into the portable repository.

Treat lane additions and changes as reviewed engineering work: verify immutable commits and binary
digests, rebuild the source-labelled reference index, validate the model and negative self-test, run
retrieval evaluations, and inspect release changes before upgrading target projects.
