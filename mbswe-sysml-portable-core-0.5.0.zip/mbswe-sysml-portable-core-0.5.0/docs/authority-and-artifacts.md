# Authority and artifact lifecycle

## One authority per claim

A single source of truth does not require one file or one artifact type. It requires that each claim have one canonical owner.

| Claim | Authority |
| --- | --- |
| Stakeholder outcome, domain meaning, system behavior | accepted SysML model |
| Selected subsystem and software architecture | accepted SysML model |
| Rationale and rejected alternatives | model-attached rationale/decision metadata |
| Executable target-language mechanics | implementation |
| Conformance observation | tests, analyses, simulations, inspections |
| Current bounded task context | generated execution slice |
| Explanatory view | generated projection |
| Cross-context accepted change | optional minimal change note |

Tests do not become requirements merely because they pass. Code does not become model authority merely because it exists. Generated packets do not become another specification merely because an agent consumed them.

## Durable

- accepted textual SysML/KerML;
- implementation source;
- executable evidence;
- immutable official-resource lock;
- exceptional accepted change continuity.

## Generated and replaceable

- semantic model index;
- model digest and inventory;
- diagrams and stakeholder views;
- model briefs;
- decision reports;
- architecture manifests;
- traceability tables;
- execution slices;
- realization maps;
- provider manifests and managed skill copies.

Every generated artifact should identify its source baseline and be reproducible or verifiably equivalent.

## Ephemeral

- exploratory plans;
- chain-of-thought and agent narration;
- intermediate reviewer discussions;
- transient work queues;
- implementation campaign state;
- scratch trade studies not accepted into the model.

Extract durable decisions into the model, implementation, or evidence, then discard the rest.

## Managed assets

Portable skills and the optional MBSwE model library are copied with `.mbswe-managed` markers. `mbswe project sync` may replace only marked core assets. Project-owned files are never inferred from matching names and never overwritten.
