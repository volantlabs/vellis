# Vellis v2 retrospective

The Vellis v2-reset work established the foundation for this core through a sequence of productive failures.

## What worked

- textual SysML became the intended system authority;
- official resources and validator were pinned and searchable;
- system meaning was separated from implementation vocabulary;
- model gaps, realization decisions, feasibility consequences, and implementation defects were distinguished;
- semantic slices and nearest-wrong evidence replaced declaration-by-declaration generation;
- fresh reviewers reduced trajectory anchoring;
- domain method was separated from portable method.

## What failed or overgrew

- the first system model stopped before consequential software-architecture decisions;
- behaviorally conforming implementation space still included unacceptable designs;
- long runs let early choices acquire dependents before human review;
- review and correction often fixed forward rather than rolling back ancestral premises;
- prose carried more architecture than native SysML semantics;
- implementation campaign machinery accumulated schemas, duplicated doctrine, state, checks, and restamping work;
- documentation synchronization existed because claims were manually repeated;
- source policy detected empty requirement shells but could not establish semantic strength.

## Decisive correction

The branch eventually adopted two rules:

1. model at any depth the project intends to govern; and
2. what the model decomposes binds implementation, while unmodeled space remains deliberately free.

This core extends that correction by adding:

- decision-completeness;
- explicit governed/delegated/deferred/forbidden disposition;
- native-semantic strength and prose waivers;
- generated semantic index;
- deterministic projection versus bounded realization;
- architecture escape triggers;
- disposable execution slices;
- minimal explicit-only evolution continuity;
- manifest-driven resource, skill, provider, and project integration.

## First-principles diagnosis

The failure was not simply insufficient requirements. It was a mismatch among:

```text
remaining design freedom
× semantic blast radius
× feedback latency
× verification gap
```

The remediation is to make high-blast-radius decisions visible and human-selected before implementation, reduce semantic batch size, verify architectural fitness as well as behavior, and roll back when new machinery mainly compensates for an earlier premise.
