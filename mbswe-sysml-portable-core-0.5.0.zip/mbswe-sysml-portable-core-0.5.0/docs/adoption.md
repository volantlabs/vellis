# Adoption plan

## Stage 1 — Language foundation

Install the `reference` profile in one repository. Confirm that fresh agents:

- identify the active lane;
- cite the correct evidence class;
- distinguish language semantics, library declarations, examples, grammar, and validator behavior;
- probe uncertain syntax;
- do not choose project architecture from official examples.

## Stage 2 — Human-led model engineering

Install `modeling`. Use SysML for one existing design path while implementation remains human/copilot-led. Measure:

- time to model;
- number of material modeling corrections;
- prose-only critical claims;
- ability of a fresh reviewer to reconstruct ownership, behavior, interaction, and decisions;
- value of generated views.

## Stage 3 — Decision-complete projection

Connect or implement a semantic model-index adapter. Generate execution slices but do not run unattended implementation. Review whether each packet contains the judgment you would otherwise supply live.

Use historical failures as adversarial cases:

- complete-state copy for a local change;
- whole-proposal materialization;
- second state authority;
- unbounded query intermediates;
- retained operation-scoped work;
- subset-only audit rather than exact equivalence.

## Stage 4 — Bounded autonomous pilot

Choose one vertical slice with a selected architecture and strong evidence. Compare:

- human/copilot;
- constrained moderate executor;
- frontier/high-reasoning executor.

Measure human time to accepted result, architecture escapes, correct stops, false stops, rework after first green, rollback depth, comprehension recovery, and model-maintenance cost.

## Stage 5 — Expand by proven decision class

Do not expand autonomy because a run completed. Expand only when the same class of decision has:

- accepted model representation;
- reliable slice generation;
- deterministic or strong conformance evidence;
- acceptable false-stop rate;
- lower total lifecycle cost.

## Stage 6 — Resource and method upgrades

Upgrade official lanes, method library, or core version as explicit changes. Validate old models, regenerate projections, compare semantic indexes, rerun evaluations, and only then update target repositories.
