# Official-resource curation

## Principle

A language copilot is only as trustworthy as its evidence routing. SysML v1, UML, blog examples, standard libraries, grammar, normative language semantics, and validator behavior answer different questions and must not be blended.

## Resource namespaces

| Corpus | Answers |
| --- | --- |
| `language` | normative SysML/KerML meaning |
| `library` | release-matched reusable declarations and specialization |
| `grammar` | textual notation form |
| `examples` | official training and worked notation after meaning is settled |
| `validation-models` | release-matched positive/negative language cases; informative, not normative |
| `official-models` | other release-matched model source not classified as training or validation |
| `migration` | SysML v1-to-v2 transformation |
| `api` | normative Systems Modeling API semantics |
| `api-cookbook` | informative API navigation/query recipes |
| `changes` | release comparison and upgrade impact |
| `validator` | behavior of the selected implementation |

Project and domain-pack models are separate authority namespaces, not additions to official language evidence.

## Immutable lanes

A lane contains exact identities for:

- release repository/tag/commit;
- selected sparse paths;
- official documents;
- validator asset and digest;
- Java runtime policy and optional pinned fallbacks;
- API cookbook commit;
- lane metadata digest.

The default stable lane is `stable-2.0`. `lab-2.1-beta2` is deliberately separate. Ordinary questions use one lane only. Upgrades compare lanes explicitly and then replace the project lock.

## Cache policy

`resources.cache: user` shares immutable content-addressed lane material across repositories. `resources.cache: project` stores it under ignored `.mbswe/cache` in the project. Neither cache is authority; the checked-in lock is.

## Retrieval policy

1. Classify the question.
2. Search the matching corpus.
3. Inspect the normative clause and inherited semantics when consequential.
4. Consult the standard library for declarations.
5. Consult examples for notation only.
6. Probe isolated syntax with the pinned validator.
7. report evidence class, lane, source location, and remaining inference.

## Upgrade policy

A resource upgrade is an engineering change:

1. update the lane catalog in the portable core;
2. verify commits and binary hashes;
3. rebuild the reference index;
4. run retrieval evaluations;
5. validate the model and negative self-test;
6. inspect official release changes;
7. update a target project only through `mbswe project upgrade-resources`;
8. rerun model and project gates.
