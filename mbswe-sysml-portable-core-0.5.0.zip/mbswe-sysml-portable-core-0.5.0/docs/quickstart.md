# Quick start

## 1. Bootstrap the portable repository

```sh
git clone <your-portable-core-repository>
cd <your-portable-core-repository>
./bootstrap
```

The bootstrap is idempotent in intent: it recreates `.venv`, installs the editable package, runs `mbswe core check`, and executes the tests.

## 2. Inspect or export profiles

```sh
.venv/bin/mbswe layer list
.venv/bin/mbswe layer archive full dist/mbswe-full.zip
```

Every exported profile contains its own bootstrap, runtime, relevant skills, schemas, resource catalog, tests, and documentation.

## 3. Initialize a project

```sh
MBSWE="$PWD/.venv/bin/mbswe"
$MBSWE project init ../my-system --profile full --id my-system
$MBSWE project check --project ../my-system
```

For a vendored installation:

```sh
/path/to/core/.venv/bin/mbswe project init . --profile full --install-mode vendored
./.mbswe/mbswe project check
```

Initialization creates or manages:

- `mbswe.yaml`;
- `model/config/resource-lock.json`;
- a starter `model/10-system.sysml` if absent;
- selected skills under `.agents/skills`;
- Claude exposure under `.claude/skills` when selected;
- the optional MBSwE model library;
- `.mbswe` artifact directories;
- marked guidance in `AGENTS.md` and `.gitignore`.

It does not overwrite an existing project model, implementation, tests, or project-local skill.

## 4. Synchronize official resources

```sh
mbswe resources sync
mbswe reference build
mbswe model validate --self-test
```

`resources sync` is the first command that requires network access. Use `resources.cache: project` in `mbswe.yaml` for a repository-local ignored cache; the default `user` mode shares immutable lane material among repositories.

## 5. Model one consequential slice

Use `$sysml-modeling` with `$sysml-reference` and an independent `$sysml-assurance` pass. Prefer native semantics for ownership, references, multiplicity, behavior, state, interaction, and selected architecture. Attach rationale rather than substituting rationale for authority.

Run:

```sh
mbswe model validate --self-test
mbswe model digest
mbswe project check
```

## 6. Generate model-derived artifacts

```sh
mbswe projection create source-inventory .mbswe/generated/projections/source-inventory.json
```

When a semantic adapter produces a model index:

```sh
mbswe artifact validate model-index .mbswe/generated/model-index.yaml
mbswe projection create decision-report .mbswe/generated/projections/decisions.md \
  --index .mbswe/generated/model-index.yaml
```

## 7. Authorize bounded realization

```sh
mbswe slice from-index \
  --index .mbswe/generated/model-index.yaml \
  --operation MyArchitecture::MyOperation \
  --id SLICE-001 \
  --title "Realize one governed outcome" \
  --checkpoint git:HEAD \
  --mode autonomous \
  --approval accepted \
  --approval-artifact git:MODEL_ACCEPTANCE \
  --output .mbswe/slices/slice-001.yaml

mbswe slice validate .mbswe/slices/slice-001.yaml
```

Then invoke `$model-realization`. A model gap or stop is an acceptable result; silently invented architecture is not.
