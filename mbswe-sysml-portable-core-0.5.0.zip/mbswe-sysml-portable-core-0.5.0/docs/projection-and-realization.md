# Projection and realization

## Why they are separate

“Create an artifact from the model” hides two fundamentally different activities.

### Projection

A projection selects, formats, or translates accepted facts. It must be deterministic or independently checked for semantic equivalence. It has no design authority.

Examples:

- view and diagram rendering;
- source/model inventory;
- model brief;
- decision report;
- traceability matrix;
- interface/schema projection;
- architecture policy;
- verification-obligation list;
- execution slice.

A projection stops when its requested output requires a decision absent from the model.

### Realization

A realization constructs a real artifact satisfying accepted authority. It is allowed to synthesize only within explicit delegation.

Examples:

- software implementation;
- tests and analyses;
- simulation assets;
- database/platform realization;
- deployment configuration;
- operational procedure;
- physical or organizational work product.

## Decision-complete execution slice

An unattended slice must identify:

- exact model/resource/implementation baselines;
- outcome and required non-effects;
- nearest wrong system;
- qualified authority and coverage;
- responsibilities, state owners, and interactions;
- governed/delegated/forbidden decisions;
- permitted local choices;
- forbidden changes and stop conditions;
- work/memory/materialization/coordination scale drivers;
- expected source and evidence surface;
- evidence that discriminates the wrong implementation;
- human acceptance when required.

Schema validation proves shape plus portable policy, not model adequacy. Model engineering and assurance remain responsible for truth.

## Architecture escape triggers

Realization must stop before:

- adding or moving an authoritative state owner;
- adding a subsystem or cross-boundary interface;
- adding a persistent representation or schema;
- creating a transaction, synchronization domain, queue, cache, worker, registry, lifecycle, or global operation;
- making routine work depend on excluded population or history;
- expanding beyond the governed responsibility closure;
- weakening evidence to accommodate implementation;
- introducing compensatory architecture to defend an earlier choice.

## Feedback

A stop returns a reproducible distinction:

```text
observed implementation need
→ translated system/architecture question
→ current qualified authority
→ differing consequences
→ required decision or model gap
```

The modeling layer resolves it. Realization resumes only from a new accepted baseline and regenerated slice.
