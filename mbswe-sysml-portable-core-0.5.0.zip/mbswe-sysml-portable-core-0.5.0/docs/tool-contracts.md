# Tool and adapter contracts

The CLI includes a working textual-source and official-validator adapter. The contracts below keep skills independent of a specific editor, model repository, programming language, or implementation platform.

## Resource adapter

Required capabilities:

```text
resources sync/status
reference build/search/corpora
model probe
```

Must preserve evidence classes and one active immutable lane.

## Model adapter

Current capabilities:

```text
model validate
model probe
model resolve
model digest
model inventory   # lexical, intentionally not semantic
```

Required semantic-adapter capabilities for full use:

```text
model index
model resolve <qualified-ref>
model closure <qualified-ref>
model decisions <qualified-ref>
model render-view <view-ref>
```

A conforming model index emits `schemas/model-index.schema.json` and is bound to the accepted model digest. The long-term seam is the Systems Modeling API; other conforming model repositories may implement the same adapter.

Do not infer full SysML meaning with regex and call it a semantic index.

## Projection adapter

```text
projection create <projector> <output>
```

A projector must identify its inputs, model digest, output digest, deterministic status, and source references. It stops on an unresolved decision.

Built-in projectors:

- `source-inventory`;
- `model-brief`;
- `decision-report`.

## Slice generator

```text
slice from-index
slice validate
```

Generation fails when a required consequential decision is delegated/deferred/missing, authoritative ownership is ambiguous, or nearest-wrong evidence is absent.

## Realization/conformance adapter

Target-language or domain-specific adapters should expose:

```text
implementation map
architecture check
evidence run
project gate
```

Their output should identify implementation units, boundary crossings, owned mutable/persistent state, interfaces, persistent schemas, caches/queues/workers, transaction and synchronization boundaries, and evidence. This output is evidence—not model authority.

## Project gates

`mbswe.yaml` declares commands as argument arrays. The portable core never invents build, test, deployment, safety, or packaging commands for a project.
