# Known limitations

## Full semantic model adapter

The package validates textual SysML with the official pilot implementation and can resolve exact qualified references, digest model source, and produce a lexical inventory. It does not yet expose a complete semantic graph through `model index`, `model closure`, or `model render-view`.

The model-index schema is therefore an adapter contract, not a claim that source tokenization understands ownership, inheritance, binding, implied relationships, satisfaction, or verification. The intended long-term implementation is the standardized Systems Modeling API or another conforming model repository.

## Tool ecosystem maturity

The official specifications are stable enough to target, but validator implementations and post-adoption revisions continue to evolve. Keep one pinned lane, test upgrades, and avoid depending on undocumented validator behavior.

## Generated target bindings

The core does not provide universal Python/Rust/Java/Haskell/Julia code generation. Target adapters should initially remain thin: interfaces, value contracts, architecture policies, and evidence obligations. Operation bodies remain realization work.

## Project architecture conformance

The portable contracts identify what a realization checker should report, but language-specific dependency/state/schema/concurrency analysis requires project or target adapters.

## Human judgment

No model captures every future principal-engineering judgment. The target is not fully autonomous architecture invention. The target is bounded autonomous execution plus correct stops on consequential decisions absent from accepted authority.

## Model-library validation

The bundled MBSwE metadata/doctrine/viewpoint library must be validated against the selected official lane before production adoption. `mbswe model validate --self-test` performs this once the library is included in a target project and official resources are synchronized.

## Python dependency lock

The portable repository uses bounded direct dependency ranges so it can bootstrap on supported Python versions, but this archive does not include a newly resolved `uv.lock` because the build environment had no package-index access. Before publishing a long-lived upstream repository, resolve and commit a lock in a connected CI/release environment and keep the editable bootstrap path as the fallback for exported profiles.
