# Migration from the Vellis v2 portable core

## Preserve

- pinned official resources;
- differentiated specification/library/example evidence;
- official validator and isolated probe;
- semantic-slice modeling and implementation;
- model-gap versus implementation-defect classification;
- fresh-context assurance;
- modeling at any depth the project intends to govern;
- binding effect of modeled decomposition;
- domain-extension separation.

## Replace

| Vellis v2 asset | Portable-core replacement |
| --- | --- |
| `model_layout.py` | `mbswe.yaml` and package/resource manifests |
| `sysml_reference.py` / `sysml_validator.py` | packaged `mbswe` resource, reference, and validator modules |
| `sysml-reference` | Layer 1 skill, retained and narrowed |
| `sysml-modeling` | Layer 2 skill with decision-completeness and judgment capture |
| `sysml-implementation` | `model-realization`, consuming a generated execution slice |
| generic review embedded in several skills | read-only `sysml-assurance` |
| implementation campaign | remove |
| large evolution record | optional minimal change note |
| `model_policy.py` | preliminary source hygiene plus generated semantic-index policy |
| `documentation-sync` | generated views/guidance and managed-asset sync |
| `rtg-schema-design` | separate RTG domain pack |
| provider symlink scripts | package-generated provider manifests and project sync |

## Migration order

1. Create a separate portable-core repository from this bundle and bootstrap it.
2. Integrate Vellis with `project init` or create an equivalent `mbswe.yaml` manually.
3. Select the stable resource lane initially; upgrade separately.
4. Preserve existing SysML authority; do not remodel and migrate tooling in one change.
5. Install managed skills and model library.
6. Validate the current model with the portable validator adapter.
7. Treat existing model policy as source hygiene only.
8. Introduce semantic decision annotations on one historically dangerous path.
9. Generate a model index through a semantic adapter.
10. Generate and review execution slices before permitting realization.
11. Retire stale campaign/evolution machinery only after equivalent accepted decisions and evidence are preserved.

## Historical lesson

The critical Vellis correction was not a particular file layout. It was recognizing that leaving internal decomposition unmodeled transferred architectural authority to context-isolated implementers. The portable method therefore treats selected architecture as model authority and unmodeled space as deliberate delegation—not as automatically safe freedom.
