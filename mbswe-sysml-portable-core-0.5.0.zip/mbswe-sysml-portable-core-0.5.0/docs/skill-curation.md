# Skill curation and evaluation

## Canonical skill set

| Skill | Layer | Mutation scope |
| --- | --- | --- |
| `sysml-reference` | language foundation | none |
| `sysml-modeling` | model engineering | model authority only |
| `sysml-assurance` | model engineering / cross-cutting | none |
| `model-projection` | utilization | generated artifacts only |
| `model-realization` | realization | implementation and evidence only |
| `sysml-evolution` | explicit cross-cutting | minimal change note only |

The mutation boundary is more important than the skill name. No skill is allowed to modify both accepted model authority and implementation.

## Skill design

Keep `SKILL.md` concise enough to load as operational policy. Put detailed distinctions, examples, checklists, and counterexamples in `references/`. Put machine contracts in `schemas/`, reusable model semantics in `model-libraries/`, and executable behavior in the CLI.

A skill should state:

- activation conditions;
- required inputs and baselines;
- exact authority/mutation boundary;
- workflow;
- stop conditions;
- outputs;
- referenced detail;
- evaluation suite.

It should not copy complete SysML language summaries, project-specific paths, domain contracts, provider configuration, or another skill’s procedure.

## Provider exposure

`skills/` is canonical in the portable repository. Target projects receive managed copies under `.agents/skills`. Claude exposure uses relative links under `.claude/skills`; Codex uses repository skills directly. Provider manifests in the portable repository are generated from `package.yaml`.

## Behavioral evaluation

Do not evaluate skills only by inspecting prose. Each suite should cover:

- direct activation;
- indirect activation;
- non-activation;
- missing or stale inputs;
- correct stop behavior;
- refusal to cross mutation authority;
- successful output contract;
- nearest-wrong counterexample;
- false-stop control where a local choice is genuinely delegated.

Layer-specific priorities:

- reference: source routing and evidence classification;
- modeling: native semantics, depth selection, decision completeness, prose overuse;
- assurance: independent reproduction and root-cause classification;
- projection: reproducibility and zero new decisions;
- realization: architecture escape, correct stop, false stop, conformance, rollback;
- evolution: minimality and rejection of campaign state.

## Domain packs

A domain skill routes accepted reusable domain semantics; it must not restate the complete domain model in prose. See [Domain packs](domain-packs.md).
