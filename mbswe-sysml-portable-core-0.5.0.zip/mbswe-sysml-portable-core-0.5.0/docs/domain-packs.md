# Domain packs

A domain pack adds accepted reusable domain meaning without contaminating the portable core.

## Contents

```text
domain-pack.yaml
model/             reusable accepted SysML/KerML packages
skills/            vocabulary and evidence routing, not duplicate authority
resources/         pinned external domain authorities
counterexamples/   known invalid domain instances and tempting wrong designs
evals/             domain-skill behavioral evaluations
```

## Rules

- The domain model is authority; the domain skill does not restate it completely in prose.
- The pack may depend on the language foundation and model-engineering method, but the portable core never depends on a product domain.
- External standards, ontologies, or datasets are independently pinned and classified.
- Counterexamples should be translated into positive domain commitments and verification intent rather than accumulated as implementation prohibitions.
- A domain pack does not prescribe target storage, framework, transport, or programming language unless those are deliberately selected domain/realization commitments.

## Recommended skill behavior

A domain skill should:

- translate user vocabulary into qualified model elements;
- retrieve the relevant semantic closure;
- surface identity, ownership, equality, lifecycle, and relationship distinctions;
- identify common false analogies from neighboring domains;
- select historical counterexamples;
- report insufficient domain authority;
- defer SysML language questions to `$sysml-reference`;
- route accepted model changes through `$sysml-modeling`.

The included domain-pack schema and template are intentionally small. A sophisticated domain may add its own schemas and tooling while retaining this authority boundary.
