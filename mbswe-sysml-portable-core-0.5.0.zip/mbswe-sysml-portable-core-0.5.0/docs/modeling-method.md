# Model-engineering method

## Goal

Build one cohesive model that carries product meaning, system construction, selected architecture, engineering judgment, and verification intent strongly enough that implementation agents do not have to invent consequential decisions.

## Depth heuristic

Model a decision when either condition is true:

1. a behaviorally conforming implementation could choose differently and you would reject it; or
2. reversing the choice would cause nonlocal rework, move authoritative state, alter persistent meaning, change dependency direction, introduce a lifecycle/transaction/concurrency boundary, or convert local work into population-wide work.

Do not equate depth with part-tree depth. Refine along the dimensions that carry the decision:

- identity, ownership, and reference;
- values, quantities, units, equality, and collections;
- behavior, control, calculation, and state;
- interactions, interfaces, messages, and flows;
- responsibilities and selected decomposition;
- time, concurrency, resources, failure, safety, and security;
- requirements, analysis, satisfaction, and verification.

## Native-semantic-first sequence

1. Frame one stakeholder or engineering outcome and the observable distinction.
2. Identify the nearest plausible wrong system.
3. Establish actors, boundary, environment, domain identity, black-box behavior, failures, and non-effects.
4. Decide which non-equivalent alternatives the project intends to rule out.
5. Construct the native semantic skeleton: definitions/usages, ownership/reference, multiplicity, specialization, subsetting/redefinition, parts/items/attributes, actions/states, ports/interfaces/connections/flows, requirements/analysis/verification.
6. Add formal constraints or calculations when useful and trustworthy.
7. Add residual natural language only for meaning not economical to encode natively.
8. Attach rationale, alternatives, delegation disposition, reconsideration condition, and historical counterexamples.
9. Exercise nominal, alternate/failed, boundary, and nearest-wrong instances.
10. Validate, assure independently, and obtain human acceptance for changed consequential authority.

## Semantic strength

From strongest to weakest:

1. native SysML/KerML semantics;
2. complete formal expression or analysis;
3. natural-language obligation with a named subject, waiver, nearest wrong system, and discriminating evidence;
4. rationale or explanatory documentation.

Rationale explains a decision; it does not create the decision.

## Decision dispositions

- `governed` — accepted authority selects the answer;
- `delegated` — executor may choose locally within named boundaries;
- `deferred` — outside the current decision frame; execution stops if it becomes necessary;
- `forbidden` — implementation may not introduce it.

A consequential decision cannot be delegated. It may be governed, forbidden, or deliberately deferred to future model work.

## Stopping rule

Stop refining when every remaining required choice:

- stays within one governed responsibility;
- is cheap to reverse;
- is visible in a small diff;
- cannot create/move authoritative state;
- cannot cross a selected boundary;
- cannot change persistent meaning or a public contract;
- cannot widen transaction, synchronization, lifecycle, or deployment;
- cannot introduce an excluded scale dependency;
- can be checked at the selected boundary.

## Avoiding prose in formal clothing

Ask: if all `doc` bodies disappeared, would the model still reveal what exists, what owns what, what references what, how behavior is ordered, how parts interact, what state changes, what boundaries are selected, and how important requirements are verified?

Architecture-critical prose is not banned. It must be explicitly classified, justified, and paired with evidence that fails for the nearest wrong realization.
