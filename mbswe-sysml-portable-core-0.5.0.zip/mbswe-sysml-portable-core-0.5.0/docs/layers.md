# Layers and profiles

## Layer 1 — SysML Language Foundation

Purpose: make agents competent with the selected official SysML/KerML ecosystem without relying on remembered UML or SysML v1 patterns.

Included:

- immutable resource lanes and locks;
- specification, model-library, grammar, example, migration, API, cookbook, and change corpora;
- checksum verification and local cache;
- source-labelled search;
- official validator setup;
- isolated snippet probes;
- whole-model validation and negative self-test;
- `$sysml-reference`.

Not included: project architecture selection or model-authoring method.

## Layer 2 — Model Engineering

Purpose: help humans and agents create one accepted, multi-altitude semantic and architectural model.

Included:

- `$sysml-modeling`;
- `$sysml-assurance`;
- MBSwE metadata, doctrine, and viewpoint library;
- model-index, policy, feedback, and domain-pack contracts;
- decision-depth, semantic-carrier, judgment, delegation, assurance, and readiness method.

A team can stop here and use the model for human-led engineering, review, communication, and verification.

## Layer 3 — Model Utilization and Realization

Purpose: use accepted authority to produce artifacts and real-world results.

Internally split into:

### Projection

Deterministic or tightly verified transformation. It makes no consequential design decision. Examples include views, briefs, inventories, reports, architecture policies, interface projections, verification obligations, and execution packets.

### Realization

Bounded synthesis from an accepted execution slice. It may decide only delegated local details. Examples include software, tests, schemas, deployment assets, procedures, simulations, and configuration.

Included skills:

- `$model-projection`;
- `$model-realization`.

## Optional evolution continuity

`$sysml-evolution` exists only for an accepted consequential change that must cross context, approval, or compatibility boundaries. It records the trigger, source baselines, accepted decision, approval artifact, affected slices, evidence, and final disposition. It does not manage workers, budgets, or task queues.

## Cumulative profiles

| Profile | Layers | Typical use |
| --- | --- | --- |
| `reference` | 1 | language questions, model review, validation |
| `modeling` | 1–2 | MBSE/MBSwE copilot without generated implementation |
| `realization` | 1–3 | model-derived artifacts and bounded implementation |
| `full` | 1–3 + evolution | long-lived repository with cross-context changes |

Use `mbswe layer export` or `mbswe layer archive` to produce a standalone profile repository.
