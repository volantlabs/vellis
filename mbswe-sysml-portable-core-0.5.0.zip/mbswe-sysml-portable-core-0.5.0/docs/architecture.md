# Architecture

## Objective

The portable core externalizes enough language knowledge, system authority, architectural judgment, and delegation policy for an agent to perform bounded work without requiring a principal engineer to supervise every implementation turn.

It does not attempt to encode every future judgment or generate arbitrary systems from requirements. Its control objective is narrower:

> When accepted authority decides a consequential issue, preserve it. When authority does not decide one, stop before code silently decides it.

## Three cumulative layers

```text
official SysML/KerML/API resources
                │
                ▼
      1. Language Foundation
                │
                ▼
        2. Model Engineering
                │ accepted model
                ▼
  3a. Deterministic Model Projection
                │ execution/model views
                ▼
     3b. Bounded Model Realization
                │
                ▼
implementation, evidence, procedures,
configuration, simulations, other artifacts

Realization feedback ────────────────┐
                                    ▼
                           Model Engineering
```

Assurance is read-only and cross-cutting. Evolution is an explicit continuity protocol, not a fourth authority plane.

## Authority planes

| Plane | Question | May mutate |
| --- | --- | --- |
| Language foundation | What do SysML, KerML, libraries, grammar, API, and validator mean? | Resource cache only |
| Model engineering | What system and selected architecture have humans accepted? | SysML authority only |
| Projection | What reproducible view follows from accepted authority? | Generated artifacts only |
| Realization | What real artifact satisfies a decision-complete slice? | Implementation/evidence only |
| Assurance | Is authority or realization adequate and conforming? | Nothing |
| Evolution | What accepted cross-context decision must persist? | Minimal change note only |

No role may select architecture, encode it into authority, implement it, and review it in one continuous trajectory.

## Core information flow

### Resource lock

A project chooses one immutable official-resource lane. The lock identifies release repository, exact commit, sparse paths, source documents, official validator binary, Java runtime options, and optional API cookbook commit. A new upstream release has no effect until the project explicitly changes lanes.

### Accepted model

The textual SysML/KerML files named by `mbswe.yaml` are product, system, and selected architecture authority. The model may be split into many packages and files; “single source of truth” means one connected semantic graph with one authority for each claim, not one giant file.

### Generated model index

A semantic adapter can project the accepted model into `model-index.schema.json`. The index normalizes claims, decisions, state owners, boundaries, operations, scale drivers, materialization limits, and evidence for deterministic policy and task generation. It is generated and baseline-bound, never hand-edited authority.

The built-in `model inventory` command is intentionally lexical and may not be relabelled as the semantic index.

### Execution slice

An execution slice is a disposable, exact-baseline packet for one outcome. It carries only the required semantic closure, governed architecture, allowed delegation, forbidden changes, stop conditions, resource bounds, change surface, and discriminating evidence.

A slice is decision-complete only when all required consequential decisions are governed or forbidden and every delegated decision is local.

### Realization result and feedback

The realization result records produced artifacts, mappings, local decisions, evidence, and checkpoint. An ungoverned consequential issue returns as structured model feedback. It is not resolved by implementation assumption.

## Why the execution process is not durable authority

Vellis showed that persisting a detailed campaign state can itself create schemas, workflows, duplicated doctrine, restamping work, and a second system to maintain. This core keeps durable:

- accepted system/model decisions;
- implementation and evidence;
- exceptional accepted change continuity.

It keeps generated or ephemeral:

- task packets;
- plans;
- reviewer narration;
- model briefs;
- traceability tables;
- diagrams;
- transient execution state.

## Package versus target repository

The portable repository owns reusable runtime, skills, schemas, model library, resource lanes, and tests. A target repository should normally hand-maintain only:

```text
mbswe.yaml
model/**/*.sysml
model/config/resource-lock.json
implementation source
evidence
```

Managed skills and optional model-library files are synchronized from the core and marked. Generated views and packets live under `.mbswe/`.
