# Validation

## Portable-core checks

```sh
mbswe core check
python -m pytest
```

`core check` verifies:

- required package files;
- JSON Schema validity;
- package, layer, skill, resource, and evaluation manifests;
- non-vacuous layer and skill inventories;
- layer dependencies and profile closure;
- exact resource-lock/catalog agreement;
- package-version agreement;
- skill metadata and local links;
- provider-manifest freshness;
- template contract validity;
- generated portable-core manifest.

The tests exercise profile exports/archives, project init/sync preservation, project-local skill preservation, reference-profile boundaries, deterministic projection, artifact templates, resource-cache selection, state ownership, prose waiver/evidence, consequential delegation, and deferred-decision rejection.

## Profile validation

Every exported profile should independently run:

```sh
./bootstrap
```

The adaptive test suite skips only contracts and templates deliberately absent from a lower profile.

## Project validation

```sh
mbswe project check
mbswe resources status
mbswe model validate --self-test
mbswe gate architecture
mbswe gate implementation
mbswe gate project
```

Only configured non-empty gates run. The portable core does not guess project commands.

## Model validation layers

1. resource-lock integrity;
2. official parser/model validation;
3. negative validator self-test;
4. semantic index contract and policy;
5. independent model assurance;
6. execution-slice policy;
7. implementation/evidence conformance.

A green parser is not a green architecture.

## Release checklist

Before publishing this portable repository:

```sh
./bootstrap
.venv/bin/mbswe core sync
.venv/bin/mbswe core check
.venv/bin/python -m pytest
.venv/bin/mbswe core manifest
```

Then export and bootstrap all four profiles, inspect archive root layout, remove local caches and `.venv` from release ZIPs, and publish the ZIP digest.

The exact checks exercised for this archive are recorded in [`VALIDATION_RESULTS.txt`](../VALIDATION_RESULTS.txt).
